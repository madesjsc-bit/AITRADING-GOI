# -*- coding: utf-8 -*-
"""Chay trong PHIEN CUA NGUOI DUNG (cung user voi MT5 thu 3) bang python cua venv co MetaTrader5.
probe: dang nhap bang thu vien chinh thuc, ghi ket qua + LOI THAT ra data\\mt5_probe.json (khong ghi mat khau)."""
import sys, os, json, time
BASE = os.environ.get("AI_BASE") or r"C:\AITRADING"
OUT = os.path.join(BASE, "data", "mt5_probe.json")


def khoa():
    c = {}
    try:
        for ln in open(os.path.join(BASE, "KHOA.txt"), encoding="utf-8-sig"):
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                c[k.strip().upper()] = v.strip()
    except OSError:
        pass
    return c


def probe():
    out = {"t": time.strftime("%Y-%m-%d %H:%M:%S"), "py": sys.version.split()[0], "user": os.environ.get("USERNAME", "")}
    try:
        import MetaTrader5 as mt5
        out["lib"] = getattr(mt5, "__version__", "?")
        c = khoa()
        kw = dict(path=os.path.join(BASE, "MT5", "terminal64.exe"), portable=True, timeout=90000)
        if c.get("MT5_LOGIN") and c.get("MT5_PASS") and c.get("MT5_SERVER"):
            kw.update(login=int(c["MT5_LOGIN"]), password=c["MT5_PASS"], server=c["MT5_SERVER"])
        out["init"] = bool(mt5.initialize(**kw))
        out["last_error"] = list(mt5.last_error())
        if out["init"]:
            ti = mt5.terminal_info()
            out["connected"] = bool(ti.connected)
            out["company"] = ti.company
            ai = mt5.account_info()
            if ai:
                out["account"] = {"login": ai.login, "server": ai.server, "mode": ai.trade_mode, "balance": ai.balance, "currency": ai.currency}
            xs = [s.name for s in (mt5.symbols_get() or []) if "XAU" in s.name.upper() or "GOLD" in s.name.upper()]
            out["xau"] = xs[:10]
            if xs:
                mt5.symbol_select(xs[0], True)
                r = mt5.copy_rates_from_pos(xs[0], mt5.TIMEFRAME_M1, 1, 3)
                out["m1"] = [[int(x["time"]), float(x["close"])] for x in r] if r is not None else None
                out["m1_err"] = list(mt5.last_error())
            mt5.shutdown()
    except Exception as e:
        out["exception"] = "%s: %s" % (type(e).__name__, e)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    probe()
