# -*- coding: utf-8 -*-
"""CONG CU TOI UU bam-la-xong (giong /why /name /report cua MAG + nut hoc lai):
- moi push AI co id + anh chup (snapshot) -> /why_<id> giai thich diem tung tieu chi
- nut ✅ Chuan / ❌ Sai -> hoi ly do bang nut -> ghi vao hoclai.json (AI 'nho' bai hoc, Claude doc tu NHATKY de chinh luat)
- /report: thong ke push + phan hoi + ty le; /hoclai: xem bai hoc gan nhat
Moi thu chi GHI NHO + THONG KE; khong tu doi luat (doi luat can tac gia duyet)."""
import os, json, csv, time

LY_DO = ["Dây chưa mở đủ", "Râu dài", "Đi ngang / sideway", "Vào muộn", "Điểm sai", "Khác"]
TC_TEN = {"TC1": ("Chuỗi ít râu chạm dải", 0.5), "TC2": ("close A vs EMA50 2 khung lớn", 0.5), "TC3": ("Nến đệm xanh", 1.0),
          "TC4": ("close A → SL", 0.7), "TC5": ("Râu trên A", 0.9), "TC6": ("Xu hướng EMA50", 2.2),
          "TC7": ("Nhánh", 2.5), "TC8": ("close A vs dải MA9 khung lớn", 1.7)}

NAME_DANGTAO = """📖 PUSH "ĐANG TẠO" của AI – đọc thế nào
Ví dụ: AI A▲ ĐANG TẠO · M1 · BUY · 4.8đ · THUẬN · >> thiếu 0.2đ

• AI: tin do bot AI gửi (cú pháp giống bot MAG).
• A▲ ĐANG TẠO: nến hiện tại CHƯA ĐÓNG nhưng đang có dáng cây A (Đ1 – giao cắt): sau chuỗi nến đi ngược, giá vừa cắt ngược lại dải MA9 (đã vượt ma9-3). Nến đóng không đạt thì tín hiệu bỏ. (A = Đ1, ▲ = BUY, ▼ = SELL)
• M1: khung đang xét. Vàng không ghi mã; BTC có chữ BTC (vd M1 BTC).
• BUY: chiều lệnh nếu tín hiệu thành.
• 4.8đ: điểm (thang 10) theo bảng chấm 8 tiêu chí của MAG.
• THUẬN / NGƯỢC / CẮT: vị trí nến A so với EMA50.
• >> thiếu 0.2đ: còn thiếu điểm so với ngưỡng (5.0) – chỉ báo, tự quyết. Các cảnh báo >> khác: >> SL (SL vượt mức).

Xem điểm từng tiêu chí: bấm 👉 /why. Báo cáo: /report. Bấm ✅ Chuẩn / ❌ Sai dưới tin để AI học lại."""


def tao_id(ten, kh, t, sg):
    lt = time.gmtime(t + 7 * 3600)   # gio VN
    return "%s_%s_%s_a_%s_%s" % ("b" if ten == "BTC" else "x", kh.lower(), time.strftime("%H%M", lt),
                                 "buy" if sg > 0 else "sell", time.strftime("%d%m", lt))


def luu_snap(data_dir, sid, snap):
    d = os.path.join(data_dir, "ai_snap")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, sid + ".json"), "w", encoding="utf-8") as f:
        json.dump(snap, f, ensure_ascii=False)
    fs = sorted(os.listdir(d))
    for old in fs[:-600]:           # giu 600 anh chup gan nhat
        try:
            os.remove(os.path.join(d, old))
        except OSError:
            pass


def doc_snap(data_dir, sid):
    try:
        with open(os.path.join(data_dir, "ai_snap", sid + ".json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def chan_tin(sid):
    return "\n\n👉 /why_%s\n💬 /name_dangtao" % sid


def ban_phim(sid):
    return {"inline_keyboard": [[{"text": "✅ Chuẩn", "callback_data": "fb|%s|ok" % sid},
                                 {"text": "❌ Sai – học lại", "callback_data": "fb|%s|bad" % sid}],
                                [{"text": "📊 Báo cáo", "callback_data": "rp|-|-"}]]}


def ban_phim_ly_do(sid):
    rows = [[{"text": x, "callback_data": "fr|%s|%d" % (sid, i)}] for i, x in enumerate(LY_DO)]
    return {"inline_keyboard": rows}


def giai_thich(snap):
    d = snap
    out = ["🔎 /why · %s %s · %s %s · %s" % (d["ten"], d["kh"], "A▲ BUY" if d["sg"] > 0 else "A▼ SELL", d["kind"], d["nhanh"]),
           "Điểm: %.1fđ / 10 (ngưỡng %.1f)" % (d["score"], 5.0)]
    for k in ("TC1", "TC2", "TC3", "TC4", "TC5", "TC6", "TC7", "TC8"):
        ten, mx = TC_TEN[k]
        out.append("%s %s: %.2f / %.2f" % (k, ten, d["tc"].get(k, 0), mx))
    out.append("Chuỗi %d nến · đệm %d · độ sâu %.2f · dải 5 đường cuối chuỗi %.2f giá" % (d["len"], d["nb"], d["depth"], d["a8"]))
    out.append("SL gợi ý %.2f (cách %.2f giá)%s" % (d["sl"], d["sld"], " ⚠ SL lớn" if d.get("sl_lon") else ""))
    if d.get("fb"):
        out.append("Phản hồi của anh: " + d["fb"])
    return "\n".join(out)


def ghi_phan_hoi(data_dir, sid, nhan, ly_do=""):
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "phanhoi.csv"), "a", encoding="utf-8", newline="") as f:
        csv.writer(f).writerow([int(time.time()), sid, nhan, ly_do])
    snap = doc_snap(data_dir, sid)
    if snap is not None:
        snap["fb"] = nhan + ((" – " + ly_do) if ly_do else "")
        luu_snap(data_dir, sid, snap)
    if nhan == "sai":                                  # bai hoc de AI/Claude hoc lai
        p = os.path.join(data_dir, "hoclai.json")
        try:
            ds = json.load(open(p, encoding="utf-8"))
        except Exception:
            ds = []
        ds.append({"t": int(time.time()), "id": sid, "ly_do": ly_do, "snap": snap})
        json.dump(ds[-300:], open(p, "w", encoding="utf-8"), ensure_ascii=False)


def bao_cao(data_dir, gio=24):
    now = time.time(); out = ["📊 /report AI – %d giờ qua" % gio]
    rows = []
    try:
        with open(os.path.join(data_dir, "ai_phathien.csv"), encoding="utf-8") as f:
            rows = [r for r in csv.reader(f) if len(r) >= 8 and r[3] == "A_dangtao" and now - int(r[0]) <= gio * 3600]
    except (OSError, ValueError):
        pass
    if not rows:
        out.append("Chưa có push A ĐANG TẠO trong khoảng này.")
    else:
        tong = len(rows); dat = sum(1 for r in rows if float(r[7]) >= 5.0)
        out.append("Push A ĐANG TẠO: %d (đủ điểm ≥ 5.0: %d · thiếu: %d)" % (tong, dat, tong - dat))
        theo = {}
        for r in rows:
            k = "%s %s %s" % (r[1], r[2], "BUY" if r[4] == "1" else "SELL"); theo.setdefault(k, []).append(float(r[7]))
        for k, v in sorted(theo.items()):
            out.append("• %s: %d tin, điểm TB %.1f" % (k, len(v), sum(v) / len(v)))
    ok = bad = 0; ly = {}
    try:
        with open(os.path.join(data_dir, "phanhoi.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) >= 3 and now - int(r[0]) <= gio * 3600:
                    if r[2] == "ok":
                        ok += 1
                    elif r[2] == "sai":
                        bad += 1; ly[r[3]] = ly.get(r[3], 0) + 1
    except (OSError, ValueError):
        pass
    out.append("Phản hồi của anh: ✅ %d · ❌ %d" % (ok, bad))
    if ly:
        out.append("Lý do sai: " + " · ".join("%s ×%d" % kv for kv in sorted(ly.items(), key=lambda x: -x[1])))
    out.append("Bài học đã ghi nhớ: %d (xem /hoclai)" % len(_ds(data_dir)))
    return "\n".join(out)


def _ds(data_dir):
    try:
        return json.load(open(os.path.join(data_dir, "hoclai.json"), encoding="utf-8"))
    except Exception:
        return []


def xem_hoclai(data_dir, n=5):
    ds = _ds(data_dir)[-n:]
    if not ds:
        return "Chưa có bài học nào. Bấm ❌ Sai – học lại dưới tin push để AI ghi nhớ."
    return "🧠 Bài học gần nhất:\n" + "\n".join("• %s – %s" % (x["id"], x.get("ly_do") or "(không ghi lý do)") for x in ds)
