# -*- coding: utf-8 -*-
"""HOC 'DAU NEN' (tac gia 28/11): voi lenh BUY ky vong nen vao lenh la nen XANH -> hoc cach nen xanh tao RAU DUOI (dau nen duoi) va DUNG LAI ra sao,
de bat dung luc 'rau da tao xong' (gia tuong tu: rau tren cua nen do cho SELL).
1) trich dac trung rau tu gia tung giay; 2) tim thong so bat (d,b,w) tot nhat bang kiem thu tren du lieu QUA KHU roi thu tren du lieu SAU (walk-forward).
Bo bat: gia da xuong duoi open >= d, da bat len khoi day >= b, day khong bi pha trong w giay -> 'rau xong' -> VAO. Chi nghien cuu/gia lap."""
import json, os, statistics, time
import ai_tick

LUOI_D = (0.0, 0.15, 0.3, 0.5)     # do sau duoi open, theo don vi u (u = rau/bien do M1 trung vi)
LUOI_B = (0.05, 0.1, 0.2, 0.3)     # do bat khoi day, theo u
LUOI_W = (0, 2, 5, 10)             # giay day khong bi pha


def nen_theo_giay(ticks, sec=60, toi_thieu=40):
    """-> [(t0, [(dt,bid)...])] cac nen co du tick."""
    out = {}
    for ts, bid in ticks:
        out.setdefault(ts - ts % sec, []).append((ts % sec, bid))
    return [(t, p) for t, p in sorted(out.items()) if len(p) >= toi_thieu]


def trich(path, sg):
    """Dac trung rau cua 1 nen (sg=+1: rau DUOI cua nen xanh; sg=-1: rau TREN cua nen do). path = [(dt,bid)]."""
    p = [(dt, sg * b) for dt, b in path]                      # quy ve khung BUY
    o = p[0][1]; c = p[-1][1]
    low = min(b for _, b in p); i_low = min(range(len(p)), key=lambda i: p[i][1]); t_low = p[i_low][0]
    wick = min(o, c) - low
    if wick <= 0:
        return None
    rec = next((dt - t_low for dt, b in p[i_low:] if b >= low + 0.5 * wick), None)
    truoc = [b for dt, b in p if t_low - 5 <= dt <= t_low]; sau = [b for dt, b in p if t_low <= dt <= t_low + 5]
    retest = sum(1 for dt, b in p[i_low + 1:] if b <= low + 0.15 * wick)
    return {"rau": wick, "than": abs(c - o), "mau_dung": c > o, "t_day": t_low, "hoi50_s": rec, "retest": retest,
            "toc_do_truoc": (truoc[-1] - truoc[0]) / max(1, len(truoc)) if len(truoc) > 1 else 0.0,
            "toc_do_sau": (sau[-1] - sau[0]) / max(1, len(sau)) if len(sau) > 1 else 0.0, "n": len(p)}


def mo_phong_bat(path, sg, d, b, w):
    """-> (vao_gia, ket_qua) hoac None. ket_qua = (dong - vao, bi_pha_day_sau_vao)."""
    p = [(dt, sg * x) for dt, x in path]; o = p[0][1]; low = None; t_low = 0
    for i, (dt, x) in enumerate(p):
        if low is None or x < low:
            low = x; t_low = dt
        if low <= o - d and x - low >= b and dt - t_low >= w:
            lows_after = min(y for _, y in p[i:])
            return x, (p[-1][1] - x, lows_after < low)
    return None


def hoc(ticks, sg, G, min_mau=30):
    """-> dict ket qua hoc (None neu chua du du lieu)."""
    nen = nen_theo_giay(ticks)
    if len(nen) < 120:
        return None
    rng = [max(b for _, b in p) - min(b for _, b in p) for _, p in nen]
    u = statistics.median(rng) or G
    cut = int(len(nen) * 0.7); train, test = nen[:cut], nen[cut:]
    feats = [f for f in (trich(p, sg) for _, p in nen) if f]
    def diem(ds, d, b, w):
        ks = [mo_phong_bat(p, sg, d * u, b * u, w) for _, p in ds]
        ks = [k for k in ks if k]
        if len(ks) < min_mau:
            return None
        pnl = [k[1][0] / G for k in ks]; pha = sum(1 for k in ks if k[1][1]) / len(ks)
        return {"n": len(ks), "pnl_tb": sum(pnl) / len(pnl), "ti_le_thang": sum(1 for x in pnl if x > 0) / len(pnl), "ti_le_pha_day": pha}
    best = None
    for d in LUOI_D:
        for b in LUOI_B:
            for w in LUOI_W:
                s = diem(train, d, b, w)
                if s and (best is None or s["pnl_tb"] > best[1]["pnl_tb"]):
                    best = ((d, b, w), s)
    if not best:
        return {"u": u, "nen": len(nen), "ly_do": "chua du mau trigger (>= %d)" % min_mau}
    (d, b, w), s_tr = best
    return {"u": u, "nen": len(nen), "d": d, "b": b, "w": w, "train": s_tr, "test": diem(test, d, b, w),
            "rau_trung_vi": statistics.median([f["rau"] for f in feats]) / G if feats else 0,
            "t_day_trung_vi": statistics.median([f["t_day"] for f in feats]) if feats else 0,
            "ti_le_xanh_co_rau": sum(1 for f in feats if f["mau_dung"]) / max(1, len(feats))}


def chay_hoc(data_dir, ten, G):
    """Hoc cho ca BUY va SELL tu tick da luu, ghi data/dau_nen_hoc_<ten>.json."""
    ticks = ai_tick.doc_het(data_dir, ten)
    out = {"t": int(time.time()), "ticks": len(ticks)}
    for sg, nm in ((1, "BUY"), (-1, "SELL")):
        out[nm] = hoc(ticks, sg, G)
    with open(os.path.join(data_dir, "dau_nen_hoc_%s.json" % ten), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    return out


def bao_cao(data_dir, ten):
    try:
        d = json.load(open(os.path.join(data_dir, "dau_nen_hoc_%s.json" % ten), encoding="utf-8"))
    except Exception:
        return "Chưa có dữ liệu học dấu nến cho %s (cần vài giờ giá từng giây)." % ten
    o = ["🕯 Học DẤU NẾN %s – %d giá từng giây đã lưu" % (ten, d["ticks"])]
    for nm in ("BUY", "SELL"):
        h = d.get(nm)
        if not h:
            o.append("%s: chưa đủ nến (cần ≥120 nến có giá đủ)" % nm); continue
        if "d" not in h:
            o.append("%s: %s" % (nm, h.get("ly_do", ""))); continue
        t = h["test"]
        o.append("%s: râu trung vị %.2f giá, đáy hình thành ~giây %d, %.0f%% nến có râu là nến đúng màu" % (
            nm, h["rau_trung_vi"], h["t_day_trung_vi"], h["ti_le_xanh_co_rau"] * 100))
        o.append("   Bộ bắt tốt nhất: xuống ≥%.2fu dưới open · bật ≥%.2fu khỏi đáy · đáy không bị phá %ds" % (h["d"], h["b"], h["w"]))
        o.append("   Học (quá khứ): %d lệnh, lãi TB %+.2f giá, thắng %.0f%%, bị phá đáy %.0f%%" % (
            h["train"]["n"], h["train"]["pnl_tb"], h["train"]["ti_le_thang"] * 100, h["train"]["ti_le_pha_day"] * 100))
        o.append("   Thử (dữ liệu sau): %s" % (("%d lệnh, lãi TB %+.2f giá, thắng %.0f%%, bị phá đáy %.0f%%" % (
            t["n"], t["pnl_tb"], t["ti_le_thang"] * 100, t["ti_le_pha_day"] * 100)) if t else "chưa đủ mẫu"))
    return "\n".join(o)
