# -*- coding: utf-8 -*-
"""QUAN GIA AITRADING - chay tren VPS (Python 3.8+, chi thu vien chuan).
Viec: (1) 5 phut kiem AITRADING-GOI: goi moi AI_<ngay>[_n].zip -> tu cai;
(2) doc lenh goi/lenh/*.json (danh sach viec cho phep); (3) day nhat ky len AITRADING-NHATKY;
(4) bao Telegram. KHONG doc/sua gi cua MAG, khong chay lenh tuy y."""
import os, sys, json, time, re, io, zipfile, shutil, socket, base64, hashlib, platform
import subprocess
import threading
import urllib.request, urllib.error, urllib.parse
import ssl
import ranh_gioi
import ai_bot
import ai_feed
from datetime import datetime

VERSION = "0.5.1"
BASE = os.environ.get("AI_BASE") or (r"C:\AITRADING" if os.name == "nt" else os.path.expanduser("~/AITRADING"))
APP = os.path.join(BASE, "app")
DATA = os.path.join(BASE, "data")
TMP = os.path.join(BASE, "tmp")
KHOA = os.path.join(BASE, "KHOA.txt")
STATE = os.path.join(DATA, "state.json")
LOG = os.path.join(DATA, "quangia_log.txt")
POLL = 300
NHATKY_EVERY = 3 * 3600
MT5_DIR = os.path.join(BASE, "MT5")
MAG_COPY = os.path.join(DATA, "mag_copy")
AI_FILES = os.path.join(MT5_DIR, "MQL5", "Files", "AI")
FEED = os.path.join(DATA, "feed")
FLAG_TAT = os.path.join(DATA, "TAT_AI")
KHOA_KEYS = ("MT5_USER", "MT5_LOGIN", "MT5_SERVER", "MT5_PASS", "MT5_SYMBOL", "MAG_COMMON")
PKG_RE = re.compile(r"^AI_(\d{4}-\d{2}-\d{2})(?:_(\d+))?\.zip$")
CFG = {}
START = time.time()


# ---------- tien ich ----------
def redact(s):
    for k, v in CFG.items():
        if (k.endswith("TOKEN") or k == "MT5_PASS") and v and len(v) > 4:
            s = s.replace(v, "***")
    s = re.sub(r"\b\d{6,}:[A-Za-z0-9_-]{30,}", "***", s)
    s = re.sub(r"github_pat_\w+|gh[pousr]_\w{20,}", "***", s)
    return s


def log(msg):
    line = "%s %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), redact(str(msg)))
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        os.makedirs(DATA, exist_ok=True)
        if os.path.exists(LOG) and os.path.getsize(LOG) > 1000000:
            os.replace(LOG, LOG + ".old")
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_cfg():
    c = {}
    try:
        with open(KHOA, encoding="utf-8-sig") as f:
            for ln in f:
                ln = ln.strip()
                if not ln or ln.startswith("#") or "=" not in ln:
                    continue
                k, v = ln.split("=", 1)
                c[k.strip().upper()] = v.strip()
    except Exception:
        pass
    c.setdefault("CHU", "madesjsc-bit")
    for k, d in (("KHO_GOI", "AITRADING-GOI"), ("KHO_NHATKY", "AITRADING-NHATKY"), ("NHANH", "main")):
        if not c.get(k):
            c[k] = d
    if not c.get("TEN_MAY"):
        c["TEN_MAY"] = socket.gethostname()
    CFG.clear()
    CFG.update(c)
    return CFG


def load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    os.makedirs(DATA, exist_ok=True)
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STATE)


# ---------- mang ----------
def make_ssl():
    """Windows cu thuong thieu chung chi goc -> dung bo cacert.pem di kem (cung cach bot centre MAG)."""
    ctx = ssl.create_default_context()
    ca = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cacert.pem")
    try:
        ctx.load_verify_locations(cafile=ca)
    except Exception as e:
        log("Khong nap duoc cacert.pem: %s" % e)
    return ctx


SSL_CTX = None


def http(method, url, headers=None, body=None, timeout=60):
    global SSL_CTX
    if SSL_CTX is None:
        SSL_CTX = make_ssl()
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def _gh_url(kind, path, with_ref):
    repo = CFG["KHO_GOI"] if kind == "goi" else CFG["KHO_NHATKY"]
    url = "https://api.github.com/repos/%s/%s/contents/%s" % (CFG["CHU"], repo, urllib.parse.quote(path))
    ref = CFG["NHANH"] if kind == "goi" else CFG.get("NHANH_NHATKY", "")
    if with_ref and ref:
        url += "?ref=" + urllib.parse.quote(ref)
    return url


def _gh_headers(kind, raw=False):
    tok = CFG.get("GOI_TOKEN" if kind == "goi" else "NHATKY_TOKEN", "")
    h = {"Authorization": "Bearer " + tok, "User-Agent": "aitrading-quangia",
         "X-GitHub-Api-Version": "2022-11-28"}
    h["Accept"] = "application/vnd.github.raw" if raw else "application/vnd.github+json"
    return h


def gh_list(kind, path):
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind))
    if s == 404:
        return []
    if s != 200:
        raise RuntimeError("GitHub list %s HTTP %s" % (path, s))
    d = json.loads(b.decode("utf-8"))
    return d if isinstance(d, list) else []


def gh_raw(kind, path):
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind, True), timeout=300)
    if s != 200:
        raise RuntimeError("GitHub tai %s HTTP %s" % (path, s))
    return b


def gh_put(kind, path, data, msg):
    sha = None
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind))
    if s == 200:
        try:
            sha = json.loads(b.decode("utf-8")).get("sha")
        except Exception:
            sha = None
    body = {"message": msg, "content": base64.b64encode(data).decode("ascii")}
    if sha:
        body["sha"] = sha
    ref = CFG["NHANH"] if kind == "goi" else CFG.get("NHANH_NHATKY", "")
    if ref:
        body["branch"] = ref
    h = _gh_headers(kind)
    h["Content-Type"] = "application/json"
    s, b = http("PUT", _gh_url(kind, path, False), h, json.dumps(body).encode("utf-8"), timeout=120)
    if s not in (200, 201):
        raise RuntimeError("GitHub ghi %s HTTP %s" % (path, s))
    return True


def tim_chat(st):
    """Tim chat cua anh: nguoi vua nhan tin / bam Start bot AI. Tra ve chat id hoac ''."""
    tok = CFG.get("TELEGRAM_TOKEN", "")
    if not tok:
        return ""
    try:
        s, b = http("GET", "https://api.telegram.org/bot%s/getUpdates" % tok, timeout=30)
        if s != 200:
            log("Telegram getUpdates HTTP %s (token sai? bot dang dung webhook/ben khac doc?)" % s)
            return ""
        for u in reversed(json.loads(b.decode("utf-8")).get("result", [])):
            m = u.get("message") or u.get("edited_message") or {}
            if m.get("chat", {}).get("id"):
                st["chat"] = str(m["chat"]["id"])
                save_state(st)
                return st["chat"]
    except Exception as e:
        log("Telegram tim chat loi: %s" % e)
    return ""


def tg(text):
    tok = CFG.get("TELEGRAM_TOKEN", "")
    if not tok:
        return False
    st = load_state()
    chat = CFG.get("TELEGRAM_CHAT") or st.get("chat", "") or tim_chat(st)
    if not chat:
        log("Telegram: chua co chat (anh nhan 1 tin bat ky cho bot AI)")
        return False
    try:
        body = urllib.parse.urlencode({"chat_id": chat, "text": text[:4000]}).encode("utf-8")
        s, _ = http("POST", "https://api.telegram.org/bot%s/sendMessage" % tok,
                    {"Content-Type": "application/x-www-form-urlencoded"}, body, 30)
        if s != 200:
            log("Telegram sendMessage HTTP %s" % s)
        return s == 200
    except Exception as e:
        log("Telegram loi: %s" % e)
        return False


# ---------- nhat ky ----------
def tom_tat(st):
    try:
        free = shutil.disk_usage(BASE).free / 1073741824.0
    except Exception:
        free = -1
    return "\n".join([
        "TEN MAY: " + CFG.get("TEN_MAY", ""),
        "THOI GIAN: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "QUAN GIA: " + VERSION,
        "GOI DANG CAI: " + str(st.get("goi", "(chua)")),
        "CHAY DUOC: %d phut" % int((time.time() - START) / 60),
        "O DIA TRONG: %.1f GB" % free,
        "PYTHON: " + platform.python_version() + " / " + platform.platform(),
        "LOI GAN NHAT: " + str(st.get("loi", "(khong)")),
    ]) + "\n"


def push_nhatky(st, reason=""):
    if not CFG.get("NHATKY_TOKEN"):
        return False
    ten = CFG["TEN_MAY"]
    files = {"TOM_TAT.txt": redact(tom_tat(st)).encode("utf-8")}
    try:
        with open(LOG, encoding="utf-8", errors="replace") as f:
            files["quangia_log.txt"] = redact("".join(f.readlines()[-300:])).encode("utf-8")
    except Exception:
        pass
    cache = st.setdefault("pushed", {})
    ok = True
    for n, data in files.items():
        h = hashlib.sha1(data).hexdigest()
        if n != "TOM_TAT.txt" and cache.get(n) == h:
            continue
        try:
            gh_put("nhatky", "nhatky/%s/%s" % (ten, n), data, "nhat ky %s %s" % (ten, reason))
            cache[n] = h
        except Exception as e:
            log("Day nhat ky loi: %s" % e)
            ok = False
    save_state(st)
    return ok


# ---------- cap nhat + lenh ----------
def install_zip(data, name):
    os.makedirs(TMP, exist_ok=True)
    z = zipfile.ZipFile(io.BytesIO(data))
    if z.testzip() is not None:
        raise RuntimeError("zip hong")
    names = z.namelist()
    if "quangia.py" not in names:
        raise RuntimeError("goi khong co quangia.py")
    newdir = os.path.join(BASE, "app_new")
    shutil.rmtree(newdir, ignore_errors=True)
    z.extractall(newdir)
    shutil.copytree(newdir, APP, dirs_exist_ok=True)
    shutil.rmtree(newdir, ignore_errors=True)
    log("Da cai goi %s" % name)


def poll_update(st):
    best = None
    for f in gh_list("goi", "goi"):
        m = PKG_RE.match(f.get("name", ""))
        if m:
            key = (m.group(1), int(m.group(2) or 0))
            if best is None or key > best[0]:
                best = (key, f["name"])
    if not best or best[1] == st.get("goi"):
        return False
    name = best[1]
    if st.get("goi") is None and os.path.exists(os.path.join(APP, "PACKAGE")):
        with open(os.path.join(APP, "PACKAGE"), encoding="utf-8") as f:
            if f.read().strip() == name:  # goi dau da nam trong bo cai lan dau
                st["goi"] = name
                save_state(st)
                return False
    install_zip(gh_raw("goi", "goi/" + name), name)
    st["goi"] = name
    save_state(st)
    tg("✅ AITRADING: đã cài gói %s (quản gia %s)" % (name, VERSION))
    return True


def _don(st):
    n = 0
    shutil.rmtree(os.path.join(BASE, "app_new"), ignore_errors=True)
    if os.path.isdir(TMP):
        for f in os.listdir(TMP):
            p = os.path.join(TMP, f)
            try:
                if time.time() - os.path.getmtime(p) > 86400:
                    shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
                    n += 1
            except Exception:
                pass
    return "da don %d muc" % n


def run_cmd(viec, cmd, st):
    """Danh sach viec CHO PHEP. Tra (ket_qua, hanh_dong)."""
    if viec == "ping":
        tg("🏓 pong từ %s" % CFG["TEN_MAY"])
        return "ok", None
    if viec == "trangthai" or viec == "nhatky":
        push_nhatky(st, "lenh")
        return "ok", None
    if viec == "khoidong_lai":
        return "ok - se khoi dong lai", "restart"
    if viec == "don":
        return _don(st), None
    if viec == "cai_mt5":
        return cai_mt5(cmd), None
    if viec == "mt5_tat":
        mt5_stop()
        for t in ("AITRADING_MT5", "AITRADING_PROBE"):
            subprocess.run(["schtasks", "/delete", "/tn", t, "/f"], capture_output=True)
        return "MT5 thu 3 da tat, tac vu da xoa (AI dung gia tu file FD14_PRICE cua MAG)", None
    if viec == "py_cai":
        return py_cai(), None
    if viec == "mt5_probe":
        return mt5_probe(cmd), None
    if viec == "dang_nhap":
        return dang_nhap(cmd), None
    if viec == "cai_data":
        return cai_data(cmd), None
    if viec == "ai_thu":
        return ai_bot.mo_ta(FEED, DATA), None
    if viec == "luat":
        ok, msg = ai_bot.sua_luat(DATA, {k: str(v) for k, v in cmd.items() if k != "viec"})
        return ("ok: " if ok else "tu choi: ") + msg, None
    if viec == "mt5_chay":
        if mt5_dang_chay():
            return "MT5 thu 3 dang chay san", None
        ok = mt5_start(None)
        time.sleep(30)
        return "MT5 thu 3: %s" % ("DANG CHAY" if ok and mt5_dang_chay() else "chua chay - xem lai"), None
    if viec == "chuandoan":
        return chuan_doan(), None
    if viec == "mt5_trangthai":
        return "MT5 thu 3 %s" % ("DANG CHAY" if mt5_dang_chay() else "khong chay"), None
    if viec == "tat_ai":
        open(FLAG_TAT, "w").write("tat")
        tg("⛔ AI đã TẮT khẩn (quản gia vẫn chạy)")
        return "da tat AI", None
    if viec == "bat_ai":
        try:
            os.remove(FLAG_TAT)
        except OSError:
            pass
        return "da bat AI", None
    if viec == "gui_tin":
        return ("ok" if tg(str(cmd.get("text", ""))[:1000]) else "khong gui duoc"), None
    return "viec khong nam trong danh sach cho phep: %s" % viec, None


def poll_commands(st):
    files = [f for f in gh_list("goi", "lenh") if f.get("name", "").endswith(".json")]
    if "lenh_done" not in st:  # lan dau: chi ghi nhan, khong chay lenh cu
        st["lenh_done"] = [f["name"][:-5] for f in files]
        save_state(st)
        return None
    action = None
    for f in sorted(files, key=lambda x: x["name"]):
        cid = f["name"][:-5]
        if cid in st["lenh_done"]:
            continue
        try:
            cmd = json.loads(gh_raw("goi", "lenh/" + f["name"]).decode("utf-8-sig"))
            res, act = run_cmd(str(cmd.get("viec", "")), cmd, st)
        except Exception as e:
            res, act = "loi: %s" % e, None
        st["lenh_done"] = (st["lenh_done"] + [cid])[-300:]
        save_state(st)
        log("Lenh %s -> %s" % (cid, res))
        if CFG.get("NHATKY_TOKEN"):
            try:
                gh_put("nhatky", "nhatky/%s/ketqua/%s.txt" % (CFG["TEN_MAY"], cid), redact(res).encode("utf-8"), "ket qua " + cid)
            except Exception as e:
                log("Ghi ket qua loi: %s" % e)
        if act:
            action = act
    return action



def khoa_chuan_hoa():
    """KHOA.txt phai xuong dong kieu Windows (CRLF) de Notepad cu hien dung."""
    try:
        with open(KHOA, "rb") as f:
            b = f.read()
        if b"\n" in b and b.replace(b"\r\n", b"").count(b"\n"):
            with open(KHOA, "wb") as f:
                f.write(b.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
    except Exception as e:
        log("khoa_chuan_hoa: %s" % e)


def ensure_khoa_keys():
    """Them (chi them, khong ghi de) cac khoa con thieu vao KHOA.txt de anh dien."""
    try:
        with open(KHOA, encoding="utf-8-sig") as f:
            have = {ln.split("=", 1)[0].strip().upper() for ln in f if "=" in ln and not ln.strip().startswith("#")}
        miss = [k for k in KHOA_KEYS if k not in have]
        if miss:
            with open(KHOA, "a", encoding="utf-8", newline="") as f:
                f.write("\r\n" + "\r\n".join(k + "=" for k in miss) + "\r\n")
    except Exception as e:
        log("ensure_khoa_keys: %s" % e)


def thu_mag(st):
    """Thu thap (chi doc) vai file nhat ky FD14 cua MAG -> data/mag_copy. CHUA dung de huan luyen."""
    os.makedirs(MAG_COPY, exist_ok=True)
    cache = st.setdefault("mag_sha", {})
    n = 0
    for ten in ranh_gioi.liet_ke(CFG):
        data = ranh_gioi.doc(CFG, ten)
        if data is None:
            continue
        h = hashlib.sha1(data).hexdigest()
        if cache.get(ten) == h:
            continue
        with open(os.path.join(MAG_COPY, ten), "wb") as f:
            f.write(data)
        cache[ten] = h
        n += 1
    return n


def mt5_dang_chay():
    if os.name != "nt":
        return False
    try:
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
              "Where-Object { $_.ExecutablePath -like '%s*' } | Measure-Object | Select -Expand Count" % (MT5_DIR + "\\"))
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60)
        return r.stdout.strip() not in ("", "0")
    except Exception:
        return False


def chuan_doan():
    """Chi DOC: tinh trang MT5 thu 3 (khong sua gi)."""
    o = ["exe MT5 thu 3: %s" % os.path.exists(os.path.join(MT5_DIR, "terminal64.exe")),
         "ini con sot (phai KHONG): %s" % os.path.exists(os.path.join(MT5_DIR, "ai_first.ini"))]
    try:
        tot = 0
        for r, _, fs in os.walk(MT5_DIR):
            for f in fs:
                try:
                    tot += os.path.getsize(os.path.join(r, f))
                except OSError:
                    pass
        o.append("dung luong MT5 thu 3: %.0f MB" % (tot / 1048576.0))
        o.append("o dia trong: %.2f GB" % (shutil.disk_usage(BASE).free / 1073741824.0))
    except Exception as e:
        o.append("loi do dung luong: %s" % e)
    if os.name == "nt":
        try:
            ps = ("whoami; Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
                  "Select ProcessId,SessionId,ExecutablePath | Format-List | Out-String -Width 200")
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=90)
            o.append("--- tien trinh ---\n" + (r.stdout or r.stderr).strip())
        except Exception as e:
            o.append("loi liet ke tien trinh: %s" % e)
    for d in (os.path.join(MT5_DIR, "logs"), os.path.join(MT5_DIR, "MQL5", "Logs")):
        try:
            fs = sorted(f for f in os.listdir(d) if re.match(r"^\d{8}\.log$", f))
            if not fs:
                continue
            p = os.path.join(d, fs[-1])
            size = os.path.getsize(p)
            off = max(0, size - 60000)
            off += off % 2  # can le UTF-16
            with open(p, "rb") as f:
                f.seek(off)
                raw = f.read()
            txt = (raw.decode("utf-16-le", "ignore") if raw.count(b"\x00") > len(raw) // 4 else raw.decode("utf-8", "ignore")).replace("\ufeff", "")
            ls = [l.strip() for l in txt.splitlines() if l.strip()]
            kw = re.compile(r"authoriz|login|account|network|invalid|fail|connect|exness|server|symbol|expert|AI_DATA|loaded|removed|chart|initial|error|cannot|startup", re.I)
            sel = [l for l in ls if kw.search(l)][-30:]
            o.append("--- %s/%s: dong khoa ---\n%s" % (os.path.basename(d), fs[-1], "\n".join(sel)))
            o.append("--- %s cuoi ---\n%s" % (fs[-1], "\n".join(ls[-8:])))
            o.append("--- %s dau ngay (20 dong) ---\n%s" % (fs[-1], "\n".join(l[:200] for l in ls[:20])))
        except OSError:
            pass
    for d in (AI_FILES, os.path.join(MT5_DIR, "MQL5", "Experts")):
        try:
            o.append("--- thu muc %s ---\n%s" % (os.path.relpath(d, MT5_DIR), ", ".join(
                "%s(%d)" % (f, os.path.getsize(os.path.join(d, f))) for f in sorted(os.listdir(d)) if not os.path.isdir(os.path.join(d, f)))[:600]))
        except OSError:
            o.append("--- thu muc %s: chua co ---" % os.path.relpath(d, MT5_DIR))
    try:
        with open(os.path.join(MT5_DIR, "config", "common.ini"), "rb") as f:
            raw = f.read()
        txt = raw.decode("utf-16", "ignore") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else raw.decode("utf-8", "ignore")
        keep = [l.strip() for l in txt.splitlines() if l.strip() and not re.search(r"pass|key|token", l, re.I)]
        o.append("--- config/common.ini (khong mat khau) ---\n" + "\n".join(keep[:40]))
    except OSError:
        o.append("config/common.ini: chua co")
    return "\n".join(o)[:8000]


def mt5_start(ini=None):
    """Khoi dong MT5 thu 3 trong PHIEN CUA NGUOI DUNG dang dang nhap (nhu 2 MT5 cua MAG),
    vi tac vu SYSTEM khong co man hinh -> MT5 tu thoat. Dung tac vu lich 'Interactive' (khong can mat khau)."""
    exe = os.path.join(MT5_DIR, "terminal64.exe")
    user = CFG.get("MT5_USER") or "Administrator"
    arg = "/portable" + (' /config:"%s"' % ini if ini else "")
    ps = ("$a=New-ScheduledTaskAction -Execute '%s' -Argument '%s' -WorkingDirectory '%s';"
          "$p=New-ScheduledTaskPrincipal -UserId \"$env:COMPUTERNAME\\%s\" -LogonType Interactive -RunLevel Limited;"
          "$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries "
          "-ExecutionTimeLimit ([TimeSpan]::Zero) -Priority 8;"
          "Register-ScheduledTask -TaskName AITRADING_MT5 -Action $a -Principal $p -Settings $s -Force | Out-Null;"
          "Start-ScheduledTask -TaskName AITRADING_MT5") % (exe, arg.replace("'", "''"), MT5_DIR, user)
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=120)
    if r.returncode:
        log("mt5_start loi: %s" % (r.stderr or r.stdout).strip()[:300])
    return r.returncode == 0


def mt5_stop():
    """Chi tat MT5 THU 3 (duong dan nam duoi C:\\AITRADING\\MT5). Khong bao gio dung toi MT5 cua MAG."""
    pre = (MT5_DIR + "\\").replace("'", "''")
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
          "Where-Object { $_.ExecutablePath -like '%s*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }") % pre
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=90)


def tim_ma_vang(cmd):
    sym = str(cmd.get("symbol") or CFG.get("MT5_SYMBOL", ""))
    if sym:
        return sym
    try:
        b = os.path.join(MT5_DIR, "bases")
        for srv in os.listdir(b):
            h = os.path.join(b, srv, "history")
            if os.path.isdir(h):
                for d in os.listdir(h):
                    if re.search(r"XAU|GOLD", d, re.I):
                        return d
    except OSError:
        pass
    return "XAUUSD"


def cai_data(cmd):
    """Chep AI_DATA.mq5 vao MT5 thu 3, bien dich, khoi dong lai MT5 thu 3 voi EA gan vao chart (CHI XUAT NEN)."""
    if os.name != "nt":
        return "chi chay tren Windows"
    exp = os.path.join(MT5_DIR, "MQL5", "Experts")
    if not os.path.isdir(exp):
        return "MT5 thu 3 chua san sang (chua co MQL5\\Experts)"
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AI_DATA.mq5")
    dst = os.path.join(exp, "AI_DATA.mq5")
    shutil.copyfile(src, dst)
    ex5 = os.path.join(exp, "AI_DATA.ex5")
    try:
        os.remove(ex5)
    except OSError:
        pass
    logp = os.path.join(TMP, "ai_compile.log")
    os.makedirs(TMP, exist_ok=True)
    subprocess.run('"%s" /compile:"%s" /log:"%s"' % (os.path.join(MT5_DIR, "metaeditor64.exe"), dst, logp),
                   capture_output=True, timeout=180)
    if not os.path.exists(ex5):
        try:
            raw = open(logp, "rb").read()
            t = raw.decode("utf-16", "ignore") if raw[:2] == b"\xff\xfe" else raw.decode("utf-8", "ignore")
        except OSError:
            t = "(khong co log bien dich)"
        return "LOI BIEN DICH AI_DATA:\n" + t[-1500:]
    sym = tim_ma_vang(cmd)
    ini = os.path.join(MT5_DIR, "ai_start.ini")
    mt5_stop()
    time.sleep(6)
    try:
        with open(ini, "w", encoding="utf-16", newline="") as f:
            f.write("[Experts]\r\nAllowLiveTrading=0\r\nAllowDllImport=0\r\nEnabled=1\r\nAccount=0\r\nProfile=0\r\n"
                    "[StartUp]\r\nExpert=AI_DATA\r\nSymbol=%s\r\nPeriod=M1\r\n" % sym)
        if not mt5_start(ini):
            return "khong khoi dong lai duoc MT5 thu 3"
        ok = False
        for _ in range(40):
            time.sleep(4)
            if os.path.exists(os.path.join(AI_FILES, "XAU_M1.csv")):
                ok = True
                break
    finally:
        try:
            os.remove(ini)
        except OSError:
            pass
    ma = ""
    try:
        ma = open(os.path.join(AI_FILES, "symbol.txt"), encoding="utf-8", errors="ignore").read().strip()
    except OSError:
        pass
    return "AI_DATA: bien dich OK; chart %s; du lieu %s; ma vang EA tim thay: %s" % (sym, "DA XUAT" if ok else "CHUA THAY file", ma or "(chua)")


def bien_dich_ai_data():
    """Chep + bien dich AI_DATA.mq5 trong MT5 thu 3. Tra ve '' neu OK, nguoc lai thong bao loi."""
    exp = os.path.join(MT5_DIR, "MQL5", "Experts")
    if not os.path.isdir(exp):
        return "MT5 thu 3 chua san sang (chua co MQL5\\Experts)"
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AI_DATA.mq5")
    dst = os.path.join(exp, "AI_DATA.mq5")
    shutil.copyfile(src, dst)
    ex5 = os.path.join(exp, "AI_DATA.ex5")
    try:
        os.remove(ex5)
    except OSError:
        pass
    logp = os.path.join(TMP, "ai_compile.log")
    os.makedirs(TMP, exist_ok=True)
    subprocess.run('"%s" /compile:"%s" /log:"%s"' % (os.path.join(MT5_DIR, "metaeditor64.exe"), dst, logp),
                   capture_output=True, timeout=180)
    if os.path.exists(ex5):
        return ""
    try:
        raw = open(logp, "rb").read()
        t = raw.decode("utf-16", "ignore") if raw[:2] == b"\xff\xfe" else raw.decode("utf-8", "ignore")
    except OSError:
        t = "(khong co log bien dich)"
    return "LOI BIEN DICH AI_DATA:\n" + t[-1500:]


def dong_nhat_ky_mt5(n=400):
    d = os.path.join(MT5_DIR, "logs")
    try:
        fs = sorted(f for f in os.listdir(d) if re.match(r"^\d{8}\.log$", f))
        p = os.path.join(d, fs[-1])
        size = os.path.getsize(p)
        off = max(0, size - 80000)
        off += off % 2
        with open(p, "rb") as f:
            f.seek(off)
            raw = f.read()
        txt = raw.decode("utf-16-le", "ignore") if raw.count(b"\x00") > len(raw) // 4 else raw.decode("utf-8", "ignore")
        return [l.strip() for l in txt.replace("\ufeff", "").splitlines() if l.strip()][-n:]
    except (OSError, IndexError):
        return []


def dang_nhap(cmd):
    """Dang nhap (lai) MT5 thu 3 bang TK trong KHOA.txt (mat khau) + lenh (login, server), gan AI_DATA, kiem tra ket noi.
    Chi tat/mo MT5 THU 3. EA chi xuat nen; AllowLiveTrading=0."""
    if os.name != "nt":
        return "chi chay tren Windows"
    login = str(cmd.get("login") or CFG.get("MT5_LOGIN", ""))
    server = str(cmd.get("server") or CFG.get("MT5_SERVER", ""))
    pw = CFG.get("MT5_PASS", "")
    if not (login and server and pw):
        return "thieu login / server / MT5_PASS (dien MT5_PASS trong KHOA.txt)"
    if not os.path.exists(os.path.join(MT5_DIR, "terminal64.exe")):
        return "chua co MT5 thu 3 (chay cai_mt5 truoc)"
    loi = bien_dich_ai_data()
    if loi:
        return loi
    sym = tim_ma_vang(cmd)
    ini = os.path.join(MT5_DIR, "ai_login.ini")
    mt5_stop()
    time.sleep(6)
    try:
        with open(ini, "w", encoding="utf-16", newline="") as f:
            f.write("[Common]\r\nLogin=%s\r\nPassword=%s\r\nServer=%s\r\nKeepPrivate=1\r\nNewsEnable=0\r\n"
                    "[Experts]\r\nAllowLiveTrading=0\r\nAllowDllImport=0\r\nEnabled=1\r\nAccount=0\r\nProfile=0\r\n"
                    "[StartUp]\r\nExpert=AI_DATA\r\nSymbol=%s\r\nPeriod=M1\r\n" % (login, pw, server, sym))
        if not mt5_start(ini):
            return "khong khoi dong lai duoc MT5 thu 3"
        for _ in range(30):
            time.sleep(4)
            if mt5_dang_chay():
                break
        ok = False
        for _ in range(30):
            time.sleep(4)
            if os.path.exists(os.path.join(AI_FILES, "XAU_M1.csv")):
                ok = True
                break
    finally:
        try:
            os.remove(ini)
        except OSError:
            pass
    kw = re.compile(r"authoriz|invalid|login|connect|network|failed|AI_DATA|synchron", re.I)
    ls = [l[:220] for l in dong_nhat_ky_mt5() if kw.search(l)][-12:]
    return "TK %s @ %s, chart %s: du lieu nen %s\n--- nhat ky MT5 ---\n%s" % (login, server, sym, "DA XUAT" if ok else "CHUA CO", "\n".join(ls))


VENV = os.path.join(BASE, "venv")
VPY = os.path.join(VENV, "Scripts", "python.exe")
PROBE = os.path.join(DATA, "mt5_probe.json")


def tac_vu_phien(ten, exe, arg, wd):
    """Chay chuong trinh trong PHIEN nguoi dung dang dang nhap (nhu 2 MT5 cua MAG) qua tac vu lich Interactive."""
    user = CFG.get("MT5_USER") or "Administrator"
    ps = ("$a=New-ScheduledTaskAction -Execute '%s' -Argument '%s' -WorkingDirectory '%s';"
          "$p=New-ScheduledTaskPrincipal -UserId \"$env:COMPUTERNAME\\%s\" -LogonType Interactive -RunLevel Limited;"
          "$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries "
          "-ExecutionTimeLimit ([TimeSpan]::Zero) -Priority 8;"
          "Register-ScheduledTask -TaskName %s -Action $a -Principal $p -Settings $s -Force | Out-Null;"
          "Start-ScheduledTask -TaskName %s") % (exe, arg.replace("'", "''"), wd, user, ten, ten)
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=120)
    if r.returncode:
        log("tac_vu_phien loi: %s" % (r.stderr or r.stdout).strip()[:300])
    return r.returncode == 0


def py_cai():
    """Tao venv rieng + cai thu vien MetaTrader5 (khong dong vao Python dung chung cua MAG)."""
    if not os.path.exists(VPY):
        r = subprocess.run([sys.executable, "-m", "venv", VENV], capture_output=True, text=True, timeout=300)
        if r.returncode or not os.path.exists(VPY):
            return "tao venv loi: " + (r.stderr or r.stdout)[-600:]
    env = dict(os.environ, PIP_NO_CACHE_DIR="1", PIP_DISABLE_PIP_VERSION_CHECK="1")
    r = subprocess.run([VPY, "-m", "pip", "install", "--only-binary", ":all:", "MetaTrader5"],
                       capture_output=True, text=True, timeout=900, env=env)
    return "pip ma %s\n%s" % (r.returncode, (r.stdout + r.stderr)[-900:])


def mt5_probe(cmd=None):
    if not os.path.exists(VPY):
        return "chua co venv (chay py_cai)"
    if str((cmd or {}).get("tat", "1")) != "0":
        mt5_stop()  # chi MT5 thu 3; de thu vien tu khoi dong terminal va dang nhap
        time.sleep(6)
    try:
        os.remove(PROBE)
    except OSError:
        pass
    app = os.path.dirname(os.path.abspath(__file__))
    if not tac_vu_phien("AITRADING_PROBE", VPY, '"%s"' % os.path.join(app, "py_mt5.py"), BASE):
        return "khong chay duoc tac vu probe"
    for _ in range(45):
        time.sleep(4)
        if os.path.exists(PROBE):
            time.sleep(1)
            try:
                kq = open(PROBE, encoding="utf-8").read()[:2500]
            except OSError:
                continue
            kw = re.compile(r"authoriz|invalid|login|connect|network|failed|synchron|account", re.I)
            return kq + "\n--- nhat ky MT5 ---\n" + "\n".join(l[:220] for l in dong_nhat_ky_mt5() if kw.search(l))[-1800:]
    return "probe khong ra ket qua sau 3 phut"


def cai_mt5(cmd):
    """MT5 thu 3: chep (CHI DOC) ban cai cua MT5 MAG -> C:\\AITRADING\\MT5, dang nhap DEMO, portable.
    Khong chay setup (tranh de len MT5 MAG). Mat khau chi lay tu KHOA.txt (MT5_PASS)."""
    if os.name != "nt":
        return "chi chay tren Windows"
    login = str(cmd.get("login") or CFG.get("MT5_LOGIN", ""))
    server = str(cmd.get("server") or CFG.get("MT5_SERVER", ""))
    pw = CFG.get("MT5_PASS", "")
    if not (login and server and pw):
        return "thieu MT5_LOGIN / MT5_SERVER / MT5_PASS (dien trong KHOA.txt)"
    exe = os.path.join(MT5_DIR, "terminal64.exe")
    if not os.path.exists(exe):
        src = str(cmd.get("nguon") or r"C:\Program Files\MetaTrader 5")
        if not os.path.exists(os.path.join(src, "terminal64.exe")):
            return "khong thay ban cai MT5 nguon: " + src
        if shutil.disk_usage(BASE).free < 4 * 1073741824:
            return "o dia trong < 4 GB - khong cai"
        r = subprocess.run(["robocopy", src, MT5_DIR, "/E", "/XD", "MQL5", "config", "logs", "bases", "Tester",
                            "/XF", "*.log", "/R:1", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP"],
                           capture_output=True, text=True, timeout=900)
        if r.returncode >= 8 or not os.path.exists(exe):
            return "robocopy loi (ma %s)" % r.returncode
    ini = os.path.join(MT5_DIR, "ai_first.ini")
    try:
        txt = ("[Common]\r\nLogin=%s\r\nPassword=%s\r\nServer=%s\r\nKeepPrivate=1\r\nNewsEnable=0\r\n"
               "[Experts]\r\nAllowLiveTrading=0\r\nAllowDllImport=0\r\nEnabled=0\r\nAccount=0\r\nProfile=0\r\n") % (login, pw, server)
        with open(ini, "w", encoding="utf-16", newline="") as f:
            f.write(txt)
        if not mt5_dang_chay():
            if not mt5_start(ini):
                return "khong tao duoc tac vu khoi dong MT5 (xem quangia_log)"
            for _ in range(30):
                time.sleep(4)
                if mt5_dang_chay():
                    break
        time.sleep(25)
    finally:
        try:
            os.remove(ini)  # xoa file co mat khau
        except OSError:
            pass
    return "MT5 thu 3: %s (TK demo %s)" % ("DANG CHAY" if mt5_dang_chay() else "chua thay chay - xem lai", login)

def khoa_dat(key, value):
    """Ghi/ sua 1 dong key=value trong KHOA.txt (CRLF), giu nguyen cac dong khac."""
    try:
        with open(KHOA, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    except OSError:
        lines = []
    out, done = [], False
    for ln in lines:
        if ln.strip().upper().startswith(key.upper() + "="):
            out.append("%s=%s" % (key, value))
            done = True
        else:
            out.append(ln)
    if not done:
        out.append("%s=%s" % (key, value))
    with open(KHOA, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(out) + "\r\n")


_DN = {"chay": False}
MEM_FEED = {}


def _dang_nhap_nen():
    try:
        load_cfg()
        tg("MT5 thứ 3: " + dang_nhap({})[:3500])
    except Exception as e:
        tg("MT5 thứ 3 lỗi: %s" % redact(str(e))[:300])
    finally:
        _DN["chay"] = False


def tg_nhan_lenh(st):
    """Nhan lenh tu CHAT CUA ANH (bot AI): /mt5 <so TK> <server> <mat khau> , /ai , /status , /tat , /bat , /help.
    Tin chua mat khau bi XOA ngay. Chi nhan tu dung chat da biet."""
    tok = CFG.get("TELEGRAM_TOKEN", "")
    chat = CFG.get("TELEGRAM_CHAT") or st.get("chat", "")
    if not tok or not chat:
        return
    base = "https://api.telegram.org/bot%s/" % tok
    s, b = http("GET", base + "getUpdates?timeout=0&offset=%d" % st.get("tg_off", 0), timeout=20)
    if s != 200:
        return
    for u in json.loads(b.decode("utf-8")).get("result", []):
        st["tg_off"] = u["update_id"] + 1
        m = u.get("message") or {}
        if str(m.get("chat", {}).get("id")) != str(chat):
            continue
        txt = (m.get("text") or "").strip()
        if not txt.startswith("/"):
            continue
        parts = txt.split(None, 3)
        cmd = parts[0].split("@")[0].lower()
        if cmd == "/mt5":
            if len(parts) < 4:
                tg("Gõ: /mt5 <số tài khoản> <server> <mật khẩu>\nvd: /mt5 123456 Exness-MT5Real15 matkhau")
            else:
                http("POST", base + "deleteMessage", {"Content-Type": "application/x-www-form-urlencoded"},
                     urllib.parse.urlencode({"chat_id": chat, "message_id": m.get("message_id", 0)}).encode("utf-8"), 20)
                if _DN["chay"]:
                    tg("Đang đăng nhập rồi, chờ kết quả đã.")
                    continue
                khoa_dat("MT5_LOGIN", parts[1])
                khoa_dat("MT5_SERVER", parts[2])
                khoa_dat("MT5_PASS", parts[3])
                tg("🔐 Đã nhận và xoá tin chứa mật khẩu. Đang đăng nhập MT5 thứ 3 (3–5 phút)…")
                _DN["chay"] = True
                threading.Thread(target=_dang_nhap_nen, daemon=True).start()
        elif cmd == "/ai":
            tg(ai_bot.mo_ta(FEED, DATA))
        elif cmd in ("/status", "/trangthai"):
            tg(tom_tat(st))
        elif cmd == "/tat":
            open(FLAG_TAT, "w").write("tat")
            tg("⛔ AI đã TẮT (không báo nữa). Gõ /bat để bật lại.")
        elif cmd == "/bat":
            try:
                os.remove(FLAG_TAT)
            except OSError:
                pass
            tg("✅ AI đã BẬT.")
        elif cmd in ("/help", "/start"):
            tg("Lệnh: /mt5 <số TK> <server> <mật khẩu> (tin được xoá ngay) · /ai (AI đang thấy gì) · /status · /tat · /bat")
    save_state(st)


# ---------- vong chinh ----------
def main():
    for d in (APP, DATA, TMP):
        os.makedirs(d, exist_ok=True)
    khoa_chuan_hoa()
    load_cfg()
    ensure_khoa_keys()
    st = load_state()
    if st.get("goi") is None and os.path.exists(os.path.join(APP, "PACKAGE")):
        with open(os.path.join(APP, "PACKAGE"), encoding="utf-8") as f:
            st["goi"] = f.read().strip()
        save_state(st)
    log("Quan gia %s chay (goi %s)" % (VERSION, st.get("goi")))
    tg("🟢 Quản gia AITRADING %s đã chạy trên %s (gói %s)" % (VERSION, CFG["TEN_MAY"], st.get("goi")))
    push_nhatky(st, "khoi dong")
    last_poll = 0.0
    last_nk = time.time()
    last_disk = 0.0
    last_mag = 0.0
    last_chat = 0.0
    last_ai = 0.0
    last_tgcmd = 0.0
    while True:
        load_cfg()
        now = time.time()
        try:
            if now - last_poll >= POLL:
                last_poll = now
                if not CFG.get("GOI_TOKEN"):
                    log("Chua co GOI_TOKEN trong KHOA.txt")
                else:
                    if poll_update(st):
                        push_nhatky(st, "sau cap nhat")
                        log("Thoat de chay ban moi")
                        sys.exit(0)
                    if poll_commands(st) == "restart":
                        log("Khoi dong lai theo lenh")
                        sys.exit(0)
                    st.pop("loi", None)
            if CFG.get("TELEGRAM_TOKEN") and not (CFG.get("TELEGRAM_CHAT") or st.get("chat")) and now - last_chat >= 60:
                last_chat = now
                if tim_chat(st):
                    tg("🟢 Quản gia AITRADING %s đã chạy trên %s (gói %s)" % (VERSION, CFG["TEN_MAY"], st.get("goi")))
            if CFG.get("TELEGRAM_TOKEN") and now - last_tgcmd >= 8:
                last_tgcmd = now
                tg_nhan_lenh(st)
            if not os.path.exists(FLAG_TAT):
                try:
                    ai_feed.chay(CFG, DATA, FEED, st, MEM_FEED)
                except Exception as e:
                    log("feed loi: %s" % e)
            if now - last_ai >= 10 and not os.path.exists(FLAG_TAT):
                last_ai = now
                ai_bot.chay(FEED, DATA, st, tg, log)
                save_state(st)
            if now - last_mag >= 300:
                last_mag = now
                if not os.path.exists(FLAG_TAT):
                    thu_mag(st)
            if now - last_nk >= NHATKY_EVERY:
                last_nk = now
                push_nhatky(st, "dinh ky")
            if now - last_disk >= 6 * 3600:
                last_disk = now
                if shutil.disk_usage(BASE).free < 2 * 1073741824:
                    tg("⚠️ %s: ổ đĩa còn dưới 2 GB" % CFG["TEN_MAY"])
        except SystemExit:
            raise
        except Exception as e:
            st["loi"] = "%s %s" % (datetime.now().strftime("%d/%m %H:%M"), redact(str(e))[:200])
            save_state(st)
            log("LOI: %s" % e)
        time.sleep(2)


if __name__ == "__main__":
    main()
