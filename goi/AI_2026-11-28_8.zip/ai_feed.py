# -*- coding: utf-8 -*-
"""NGUON GIA: tu dung nen M1/M5/M15/H1 tu file gia MAG ghi moi giay (FD14_PRICE_XAU.txt = bid;ask;gmt_unix;...)
- CHI DOC qua ranh_gioi (khong dung MT5 rieng, khong dang nhap TK nao). Gia = BID cua san Exness MAG dang noi.
- Nen DONG ghi ra <feed>/XAU_<khung>.csv (time,open,high,low,close,tickvol) cho ai_bot doc."""
import os, json, time
import ranh_gioi

KHUNG = {"M1": 60, "M5": 300, "M15": 900, "H1": 3600}
TOI_DA = 400


def doc_gia(cfg, ten="FD14_PRICE_XAU.txt"):
    raw = ranh_gioi.doc(cfg, ten)
    if not raw:
        return None
    try:
        p = raw.decode("utf-8", "ignore").strip().splitlines()[0].split(";")
        return float(p[0]), float(p[1]), int(p[2])
    except (ValueError, IndexError):
        return None


def them_gia(bars, ts, bid):
    """bars: {khung: [[t, o, h, l, c, n], ...]}. Tra ve danh sach khung vua co nen DONG."""
    dong = []
    for kh, sec in KHUNG.items():
        ls = bars.setdefault(kh, [])
        t = ts - ts % sec
        if ls and ls[-1][0] == t:
            b = ls[-1]
            b[2] = max(b[2], bid); b[3] = min(b[3], bid); b[4] = bid; b[5] += 1
        elif not ls or t > ls[-1][0]:
            ls.append([t, bid, bid, bid, bid, 1])
            if len(ls) > 1:
                dong.append(kh)
            del ls[:-TOI_DA]
    return dong


def ghi_csv(feed_dir, bars, ten="XAU", khung=None):
    os.makedirs(feed_dir, exist_ok=True)
    for kh in (khung or bars):
        ls = bars.get(kh, [])[:-1]  # bo nen dang chay
        if not ls:
            continue
        tmp = os.path.join(feed_dir, "%s_%s.tmp" % (ten, kh))
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            for b in ls:
                f.write("%d,%.3f,%.3f,%.3f,%.3f,%d\n" % tuple(b))
        os.replace(tmp, os.path.join(feed_dir, "%s_%s.csv" % (ten, kh)))


def nap(data_dir):
    try:
        with open(os.path.join(data_dir, "bars.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def luu(data_dir, bars):
    tmp = os.path.join(data_dir, "bars.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(bars, f)
    os.replace(tmp, os.path.join(data_dir, "bars.json"))


def chay(cfg, data_dir, feed_dir, st, mem):
    """Goi moi ~2 giay. mem: dict giu trong RAM. Tra ve True neu co nen dong moi."""
    g = doc_gia(cfg)
    if g is None:
        return False
    bid, _, ts = g
    if ts <= mem.get("ts", 0) or time.time() - ts > 45:  # trung hoac gia cu (thi truong dong)
        return False
    mem["ts"] = ts
    if "bars" not in mem:
        mem["bars"] = nap(data_dir)
    dong = them_gia(mem["bars"], ts, bid)
    if dong:
        ghi_csv(feed_dir, mem["bars"], khung=dong)
        luu(data_dir, mem["bars"])
        return True
    return False


def trang_thai(cfg, feed_dir):
    """Mo ta nguon gia (cho lenh ai_thu / /ai): file co khong, gia cu bao lau, da dung duoc bao nhieu nen."""
    goc = ranh_gioi.goc(cfg)
    o = ["nguon gia: %s (%s)" % (os.path.join(goc, "FullD"), "co" if os.path.isdir(os.path.join(goc, "FullD")) else "KHONG THAY thu muc")]
    o.append("file doc duoc: " + (", ".join(ranh_gioi.liet_ke(cfg)) or "(khong co)"))
    g = doc_gia(cfg)
    if g is None:
        o.append("FD14_PRICE_XAU.txt: khong doc duoc")
    else:
        tuoi = int(time.time()) - g[2]
        o.append("gia cuoi: bid=%.2f ask=%.2f cach day %d giay%s" % (g[0], g[1], tuoi,
                 " -> THI TRUONG DONG / bot MAG khong ghi (AI chi chay khi gia moi < 45 giay)" if tuoi > 45 else " (dang cap nhat)"))
    for kh in KHUNG:
        p = os.path.join(feed_dir, "XAU_%s.csv" % kh)
        n = len(open(p).read().splitlines()) if os.path.exists(p) else 0
        o.append("%s: %d nen dong (can >= 13)" % (kh, n))
    return "\n".join(o)
