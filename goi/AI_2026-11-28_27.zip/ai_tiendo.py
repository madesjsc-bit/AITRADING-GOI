# -*- coding: utf-8 -*-
"""DANH GIA + TIEN DO HOC (tac gia 28/11): AI GIA DINH vao lenh SAU cay xac nhan A / P (theo dieu kien D1, D2) theo nguyen tac BAT RAU.
Tu cham: KHOANG CACH tu diem vao den DAY THAP NHAT cua nen (BUY) / DINH CAO NHAT (SELL) - cang NGAN cang tot.
 ti le bat = 1 - khoang_cach / rau  (1.0 = vao dung day rau; 0 = vao o gia mo cua).
'Hoc xong' = dat DU cac tieu chi (duoi, tac gia duyet nguong) tren du lieu SAU, on dinh nhieu ngay. Bao cao hang ngay + /hoc."""
import csv, json, os, statistics, time
import ai_tick, ai_hocnen, ai_hocrau

NGUONG = {"mau_tin_hieu": 100, "ti_le_bat_trung_vi": 0.80, "ngay_on_dinh": 3, "lech_hoc_thu": 0.20, "thang_toi_thieu": 0.50}
N_NEN_SAU = 6


def tai_model(data_dir, ten, nm):
    """Uu tien mo hinh CHUNG (nhieu du lieu hon); khong co thi mo hinh rieng."""
    for fn in ("rau_model_chung.json", "rau_model_%s_%s.json" % (ten, nm)):
        try:
            return json.load(open(os.path.join(data_dir, fn), encoding="utf-8"))
        except Exception:
            pass
    return None


def danh_gia(ticks, sigs, sg, G, model):
    """sigs: [t_close] (giay, thoi diem nen tin hieu da dong). -> list ket qua tung tin hieu."""
    nen = ai_hocnen.nen_idx(ticks); out = []
    if not nen or not model:
        return out
    starts = [t for t, _, _ in nen]
    for tc in sigs:
        k0 = next((i for i, t in enumerate(starts) if t >= tc), None)
        if k0 is None or k0 < 31:
            continue
        got = None
        for idx in range(k0, min(len(nen), k0 + N_NEN_SAU)):
            if idx > 0 and starts[idx] - starts[idx - 1] > 120:
                break
            t0, i0, i1 = nen[idx]; u = ai_hocrau._u_truot(ticks, nen, idx)
            ms = ai_hocrau.mau_nen(ticks, nen, idx, sg, G, buoc=2, toi_da=10 ** 6)
            for f, yl, yu, j in ms:
                xb = ai_hocrau.bin_hoa(f, model["edges"])
                if ai_hocrau.du_doan([tuple(x) for x in model["rau_xong"]], xb) >= model["th1"] and ai_hocrau.du_doan([tuple(x) for x in model["len_tiep"]], xb) >= model["th2"]:
                    xs = [sg * ticks[q][1] for q in range(i0, i1)]; o = xs[0]; low_now = min(xs[:j + 1]); entry = xs[j]
                    L = min(xs); rau = o - L
                    r = ai_hocnen.quan_ly(ticks, i0 + j, sg, u, low_now, o, model["c"])
                    kc = max(0.0, entry - L)
                    got = {"kc_g": kc / G, "rau_g": rau / G, "bat": max(0.0, min(1.0, 1 - kc / rau)) if rau > 1e-12 else 0.0, "xanh": xs[-1] > o,
                           "pnl_g": (r["pnl"] / G) if r else 0.0, "sl_g": (r["risk"] / G) if r else 0.0, "nen_sau": idx - k0}
                    break
            if got:
                break
        out.append(got)
    return out


def doc_tin_hieu(data_dir, ten):
    """-> ({BUY:[t_close],SELL:[...]}) tu ai_phathien.csv (push A/P dang tao; khung M1)."""
    d = {1: [], -1: []}
    try:
        with open(os.path.join(data_dir, "ai_phathien.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) >= 5 and r[1] == ten and r[2] == "M1" and r[3] in ("A_dangtao", "P_dangtao"):
                    d[int(r[4])].append(int(r[0]) + 60)
    except (OSError, ValueError):
        pass
    return d


def tong_hop(rs):
    ok = [r for r in rs if r]
    n = len(rs)
    if not ok:
        return {"n_tin": n, "n_vao": 0}
    bat = [r["bat"] for r in ok]
    return {"n_tin": n, "n_vao": len(ok), "bat_tv": statistics.median(bat), "bat_tb": sum(bat) / len(bat),
            "kc_tv": statistics.median([r["kc_g"] for r in ok]), "kc_tb": sum(r["kc_g"] for r in ok) / len(ok),
            "rau_tv": statistics.median([r["rau_g"] for r in ok]), "xanh": sum(1 for r in ok if r["xanh"]) / len(ok),
            "loi_tb": sum(r["pnl_g"] for r in ok) / len(ok), "sl_tb": sum(r["sl_g"] for r in ok) / len(ok),
            "thang": sum(1 for r in ok if r["pnl_g"] > 0) / len(ok)}


def danh_gia_ma(data_dir, ten, G):
    ticks = ai_tick.doc_het(data_dir, ten); sg_t = doc_tin_hieu(data_dir, ten); out = {}
    for sg, nm in ((1, "BUY"), (-1, "SELL")):
        m = tai_model(data_dir, ten, nm)
        sigs = sorted(sg_t[sg]); cut = int(len(sigs) * 0.7)
        rs = danh_gia(ticks, sigs, sg, G, m) if m else []
        out[nm] = {"tat_ca": tong_hop(rs), "hoc": tong_hop(rs[:cut]), "thu": tong_hop(rs[cut:]) if len(sigs) - cut >= 10 else None, "co_mo_hinh": bool(m)}
    return out


def ghi_lich_su(data_dir, ten, kq):
    p = os.path.join(data_dir, "hoc_lichsu.csv"); ngay = time.strftime("%Y-%m-%d", time.gmtime(time.time() + 7 * 3600))
    try:
        with open(p, "a", encoding="utf-8", newline="") as f:
            for nm, v in kq.items():
                a = v["tat_ca"]
                if a.get("n_vao"):
                    csv.writer(f).writerow([ngay, ten, nm, a["n_tin"], a["n_vao"], round(a["bat_tv"], 3), round(a["kc_tv"], 3), round(a["loi_tb"], 3), round(a["thang"], 3)])
    except OSError:
        pass


def lich_su_ngay(data_dir, ten, nm):
    """-> {ngay: bat_trung_vi (lan cuoi trong ngay)}"""
    d = {}
    try:
        with open(os.path.join(data_dir, "hoc_lichsu.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) >= 9 and r[1] == ten and r[2] == nm:
                    d[r[0]] = float(r[5])
    except (OSError, ValueError):
        pass
    return d


def tieu_chi(data_dir, ten, nm, v):
    a = v["tat_ca"]; t = v["thu"]; ls = lich_su_ngay(data_dir, ten, nm); ngay = sorted(ls)[-NGUONG["ngay_on_dinh"]:]
    on_dinh = len(ngay) >= NGUONG["ngay_on_dinh"] and all(ls[x] >= NGUONG["ti_le_bat_trung_vi"] for x in ngay)
    c = [("Đủ mẫu: %d/%d tín hiệu đã đánh giá" % (a["n_tin"], NGUONG["mau_tin_hieu"]), a["n_tin"] >= NGUONG["mau_tin_hieu"]),
         ("Bắt được ≥%.0f%% râu (trung vị)%s" % (NGUONG["ti_le_bat_trung_vi"] * 100, (": %.0f%%" % (t["bat_tv"] * 100)) if t and t.get("n_vao") else ": chưa có dữ liệu sau"),
          bool(t and t.get("n_vao") and t["bat_tv"] >= NGUONG["ti_le_bat_trung_vi"])),
         ("Ổn định %d ngày liên tiếp đạt ngưỡng" % NGUONG["ngay_on_dinh"], on_dinh),
         ("Lệch học–thử ≤%.0f%%" % (NGUONG["lech_hoc_thu"] * 100), bool(t and t.get("n_vao") and v["hoc"].get("n_vao") and abs(v["hoc"]["bat_tv"] - t["bat_tv"]) <= NGUONG["lech_hoc_thu"] * max(1e-9, v["hoc"]["bat_tv"]))),
         ("Thắng ≥%.0f%% & lãi TB dương" % (NGUONG["thang_toi_thieu"] * 100), bool(a.get("n_vao") and a["thang"] >= NGUONG["thang_toi_thieu"] and a["loi_tb"] > 0))]
    return c


def tin_hieu_moi_ngay(data_dir, ten, nm_sg, now=None):
    now = now or time.time(); ts = doc_tin_hieu(data_dir, ten)[nm_sg]
    if len(ts) < 2:
        return 0.0
    span = max(ts[-1] - ts[0], 3 * 3600)
    return len(ts) / (span / 86400.0)


def bao_cao(data_dir, mas=("XAU", "BTC")):
    o = ["📚 BÁO CÁO TIẾN ĐỘ HỌC – bắt RÂU nến sau xác nhận A/P"]
    for ten in mas:
        G = 1.0 if ten == "XAU" else 30.0
        try:
            kq = danh_gia_ma(data_dir, ten, G)
        except Exception as e:
            o.append("%s: lỗi đánh giá (%s)" % (ten, e)); continue
        for nm, sg in (("BUY", 1), ("SELL", -1)):
            v = kq[nm]; a = v["tat_ca"]
            o.append("— %s · %s %s" % (ten, nm, "(bắt râu dưới)" if sg > 0 else "(bắt râu trên)"))
            if not v["co_mo_hinh"]:
                o.append("   AI chưa có mô hình (cần giá từng giây ≥ vài giờ)"); continue
            if not a.get("n_vao"):
                o.append("   %d tín hiệu A/P, chưa vào được lệnh bóng nào" % a["n_tin"]); continue
            o.append("   Vào bóng %d/%d tín hiệu · khoảng cách vào→đáy TB %.2f giá (râu TB %.2f) · BẮT ĐƯỢC %.0f%% râu (trung vị) · nến xanh %.0f%%" % (
                a["n_vao"], a["n_tin"], a["kc_tb"], a["rau_tv"], a["bat_tv"] * 100, a["xanh"] * 100))
            o.append("   Lãi TB %+.2f giá · SL TB %.2f giá · thắng %.0f%%" % (a["loi_tb"], a["sl_tb"], a["thang"] * 100))
            ch = tieu_chi(data_dir, ten, nm, v); ok = sum(1 for _, x in ch if x)
            o.append("   TIẾN ĐỘ: %d/%d tiêu chí đạt %s" % (ok, len(ch), "🎓 HỌC XONG (chờ anh duyệt)" if ok == len(ch) else ""))
            for tx, x in ch:
                o.append("     %s %s" % ("✅" if x else "⏳", tx))
            ls = lich_su_ngay(data_dir, ten, nm)
            if ls:
                o.append("     Xu hướng bắt râu theo ngày: " + " → ".join("%.0f%%" % (ls[k] * 100) for k in sorted(ls)[-5:]))
            rate = tin_hieu_moi_ngay(data_dir, ten, sg)
            if ok < len(ch) and rate > 0:
                con = max(0, NGUONG["mau_tin_hieu"] - a["n_tin"]); ngay = max(con / rate, NGUONG["ngay_on_dinh"])
                o.append("     Dự kiến còn ≥ %.0f ngày (đang có ~%.0f tín hiệu/ngày; cần đủ mẫu + %d ngày ổn định)" % (ngay, rate, NGUONG["ngay_on_dinh"]))
    o.append("Ngưỡng 'học xong' do em đề xuất – anh duyệt/đổi bằng lời.")
    return "\n".join(o)


def cap_nhat_ngay(data_dir, mas=("XAU", "BTC")):
    for ten in mas:
        G = 1.0 if ten == "XAU" else 30.0
        try:
            ghi_lich_su(data_dir, ten, danh_gia_ma(data_dir, ten, G))
        except Exception:
            pass
