# -*- coding: utf-8 -*-
"""HOC TU MAG: Đ2 - NEN P / NHIP HOI / PUSH MO (port tu D14.mqh: X14D2, X14ScoreD2, X14Resist, EvalD2, EvalHoi, X14MoChain, EvalMO).
Dung chung SR + ham cua ai_d1. Chua port: tru diem sat bien SWR/SWV (X14Pen), suyt P (EvalSP - cho Q0 sau), canh bao rau khung ke tiep.
Khong co phan giao dich."""
import time
import ai_d1 as d1

P2 = {"ChainOpen": 3, "MaxPull": 4, "D2DepthK": 1.3, "D2Near": 0.8, "D2Pass": 0.6, "FractalK": 3, "SlopeMinD2": 1.8, "D2Min": 7.0}
LE = d1.LE
TB = d1.TREND_BARS


def up_ok(s, x, sg):
    return d1.dt(s, x, sg, 5)


def is_p(s, x, sg, pot):
    return d1.col(s, x) == sg and (pot or sg * (s.c[x] - s.lw[x]) > 0) and up_ok(s, x, sg)


def lw_open(s, i):
    if i < 0 or i + 9 >= s.n:
        return s.lw[i] if i >= 0 else 0.0
    return (9.0 * s.o[i] + sum((9 - k) * s.c[i + k] for k in range(1, 9))) / 45.0


def struct(s, i, sg, pot, P=None, D=None):
    """-> (f dict | None, ly_do)"""
    P = P or P2; D = D or d1.PARAMS; G = s.G; n3 = D["Depth"] * G
    if i < 0 or i + TB + LE + 10 >= s.n:
        return None, "thieu du lieu"
    r = -1
    for x in range(i + 1, i + P["MaxPull"] + 1):
        if (d1.col(s, x) != -sg and sg * (s.c[x] - s.lw[x]) > 0 and sg * (s.o[x] - s.lw[x]) > 0
                and up_ok(s, x, sg) and d1.col(s, x - 1) == -sg):
            r = x; break
    if r < 0:
        return None, "khong thay chuoi mo + nen hoi dau tien"
    h0 = r - 1; clu = h0 - i + 1
    for x in range(i + 1, h0 + 1):
        if is_p(s, x, sg, False):
            return None, "cum hoi da co nen P"
    inside = 0
    for x in range(i, h0 + 1):
        if x == i and pot:
            continue
        if sg * (s.c[x] - s.lw[x + 4]) < 0:
            return None, "nen hoi dong thung ma9-4"
        if sg * (s.c[x] - s.lw[x]) <= 0:
            inside += 1
    if inside > 1:
        return None, "cum hoi co %d nen dong trong dai" % inside
    if clu > P["MaxPull"]:
        return None, "cum hoi %d nen > %d" % (clu, P["MaxPull"])
    x = r; c1b = False
    while x < s.n - LE and x - r < 200:
        if not (d1.col(s, x) != -sg and sg * (s.c[x] - s.lw[x]) > 0):
            break
        if not (sg * (s.o[x] - s.lw[x]) > 0):
            c1b = True; x += 1; break
        x += 1
    cs = x - 1; nchain = cs - r + 1
    if nchain < P["ChainOpen"]:
        return None, "chuoi mo %d nen < %d" % (nchain, P["ChainOpen"])
    for q in range(r, cs):
        if not up_ok(s, q, sg):
            return None, "dai chua don + tach 5 duong"
    w5 = d1.w(s, r, sg, 5)
    if w5 < D["A8"] * G:
        return None, "A8: dai 5 duong cuoi chuoi mo %.2f" % (w5 / G)
    base = s.lw[cs] if c1b else s.o[cs]
    depth = sg * (s.c[r] - base)
    if depth < P["D2DepthK"] * n3:
        return None, "do sau D2 %.2f" % (depth / G)
    tn = d1.seg(s, i, max(3, cs - i + 1), sg, P["SlopeMinD2"]); tf = d1.seg(s, cs + 1, TB, sg, P["SlopeMinD2"])
    trend = P["D2Near"] * tn + (1.0 - P["D2Near"]) * tf
    if trend < P["D2Pass"]:
        return None, "EMA50 trend %.0f%% < %.0f%%" % (trend * 100, P["D2Pass"] * 100)
    first = True; reset = -1; lim = min(s.n - LE, cs + 300)
    for q in range(cs + 1, lim + 1):
        if sg * (s.c[q] - s.lw[q + 3]) < 0:
            reset = q; break
    if reset < 0:
        reset = lim
    cnt = 0
    for q in range(reset - 1, cs, -1):
        if d1.col(s, q) == -sg and cnt >= P["ChainOpen"]:
            first = False; break
        nr = d1.col(s, q) != -sg and sg * (s.c[q] - s.lw[q]) > 0
        ob = sg * (s.o[q] - s.lw[q]) > 0
        if nr and (cnt == 0 or (ob and up_ok(s, q, sg))):
            cnt += 1
        elif nr:
            cnt = 1
        else:
            cnt = 0
    if not first:
        return None, "khong phai cum hoi dau tien cua chuoi"
    return {"r": r, "h0": h0, "cs": cs, "nchain": nchain, "c1b": c1b, "depth": depth, "w5": w5, "trend": trend,
            "tn": tn, "tf": tf, "clu": clu, "key": s.t[cs]}, ""


def resist(s, i, sg, P=None):
    P = P or P2; G = s.G; c = s.c[i]; best = 99 * G; k = max(1, P["FractalK"])
    def pk(hh, ll, x):
        for q in range(1, k + 1):
            v = hh[x] if sg > 0 else ll[x]; a = hh[x - q] if sg > 0 else ll[x - q]; b = hh[x + q] if sg > 0 else ll[x + q]
            if not (sg * (v - a) > 0 and sg * (v - b) >= 0):
                return None
        return hh[x] if sg > 0 else ll[x]
    x = i + k
    while x <= i + 150 and x + k < s.n:
        v = pk(s.h, s.l, x)
        if v is not None and sg * (v - c) > 0:
            best = min(best, sg * (v - c))
        x += 1
    t5 = d1.next_tf(s.tf, 1); lst = [b for b in s.htf.get(t5, []) if b[0] <= s.t[i]]
    if len(lst) >= 160:
        ser = list(reversed(lst))[:160]
        h5 = [b[2] for b in ser]; l5 = [b[3] for b in ser]
        for x in range(1 + k, 151):
            v = pk(h5, l5, x)
            if v is not None and sg * (v - c) > 0:
                best = min(best, sg * (v - c))
    day = time.gmtime(s.t[i]).tm_yday; ext = None; x = i + 1
    while x < i + 1500 and x < s.n and time.gmtime(s.t[x]).tm_yday == day:
        e = s.h[x] if sg > 0 else s.l[x]
        ext = e if ext is None else (max(ext, e) if sg > 0 else min(ext, e)); x += 1
    if ext is not None and sg * (ext - c) > 0:
        best = min(best, sg * (ext - c))
    return best


def cham_diem(s, i, sg, f, pot, P=None, D=None, hyp=False, c_hyp=0.0):
    P = P or P2; D = D or d1.PARAMS; G = s.G; n3 = D["Depth"] * G
    cP = c_hyp if hyp else s.c[i]; oP = c_hyp if hyp else s.o[i]; tc = {}; ex = {}
    touch = sum(1 for x in range(f["r"], f["cs"] + 1) if ((s.lw[x] - s.l[x]) if sg > 0 else (s.h[x] - s.lw[x])) > 0)
    tc["TC1"] = 1.1 * (1.0 - touch / float(max(1, f["cs"] - f["r"] + 1)))
    tc["TC2"] = d1.lin(f["depth"], n3, 0.5, 2 * n3, 1.0)
    v3 = 1.0
    if not hyp:
        for x in range(i, f["h0"] + 1):
            if x == i and pot:
                continue
            if sg * (s.c[x] - s.lw[x]) <= 0:
                v3 = 0.67 if sg * (s.c[x] - s.lw[x + 2]) > 0 else 0.33
                break
    tc["TC3"] = 0.4 * v3
    clu = f["clu"]
    tc["TC4"] = 0.7 * (1.0 if clu <= 2 else (0.75 if clu == 3 else 0.5))
    lwb = lw_open(s, i - 1) if (i >= 1 and not hyp) else s.lw[i]
    slb = lwb - sg * D["SLPad"] * G; sld = sg * (cP - slb)
    ex.update(sl=slb, sld=sld, block=2 if sld >= D["BlockTh"] * G else 1, sl_lon=sld > D["MaxSL"] * G)
    tc["TC5"] = 0.8 if ex["block"] == 1 else 0.4
    body = abs(cP - oP); wick = (s.h[i] - max(oP, cP)) if sg > 0 else (min(oP, cP) - s.l[i]); v6 = 0.0
    if hyp:
        v6 = 1.0
    elif body > 0:
        v6 = 1.0 if wick <= body else max(0.0, 1.0 - (wick - body) / body)
    tc["TC6"] = 0.3 * v6
    tc["TC7"] = 1.2 * f["trend"]
    t2 = d1.next_tf(s.tf, 1); t3 = d1.next_tf(s.tf, 2)
    tc["TC8"] = 0.5 * d1.score_line2(cP, d1.htf_e50(s, i, t2), d1.htf_e50(s, i, t3), sg, G, D["Depth"])[0]
    lwh = d1.htf_lw(s, i, t2); ktt = False; ex["ktt3"] = -9
    if lwh:
        up = all(sg * (lwh[k] - lwh[k + 1]) > 0 for k in range(4)); dn = all(-sg * (lwh[k] - lwh[k + 1]) > 0 for k in range(4))
        ex["ktt3"] = 1 if up else (-1 if dn else 0)
        ktt = sg * (cP - lwh[0]) > 0 and all(sg * (lwh[k] - lwh[k + 1]) > 0 for k in range(5))
    tc["TC9"] = 1.3 if ktt else 0.0
    res = resist(s, i, sg, P)
    tc["TC10"] = d1.lin(res, 0.5 * n3, 0.0, 2.5 * n3, 1.3)
    ob = cP if hyp else (s.o[i - 1] if i >= 1 else s.c[i])
    dist = sg * (ob - s.e[i])
    if dist <= 0:
        v11 = 0.0
    elif dist <= n3:
        v11 = 1.4 * dist / n3
    elif dist <= 2 * n3:
        v11 = 1.4
    else:
        v11 = 1.4 * max(0.0, 1.0 - (dist / (2 * n3) - 1.0))
    tc["TC11"] = v11
    return tc, ex


def eval_p(s, p, sg, pot=False, P=None, D=None):
    r = {"ok": False, "sg": sg, "loai": "P", "a": p}
    if p < 0 or p + TB + LE + 10 >= s.n:
        r["why"] = "thieu du lieu"; return r
    if not is_p(s, p, sg, pot):
        r["why"] = "khong phai nen P"; return r
    f, why = struct(s, p, sg, pot, P, D)
    if f is None:
        r["why"] = why; return r
    tc, ex = cham_diem(s, p, sg, f, pot, P, D)
    r.update(ok=True, kind="P", tc=tc, score=sum(tc.values()), key=f["key"], t=s.t[p], gia=s.c[p], **ex)
    return r


def eval_hoi(s, i, d, P=None, D=None):
    r = {"ok": False, "sg": d, "loai": "HOI", "a": i}
    if i < 1 or i + TB + LE + 10 >= s.n:
        return r
    if d1.col(s, i) != -d or d * (s.c[i] - s.lw[i + 4]) < 0:
        return r
    rr = i + 1
    if not (d1.col(s, rr) != -d and d * (s.c[rr] - s.lw[rr]) > 0 and d * (s.o[rr] - s.lw[rr]) > 0 and up_ok(s, rr, d)):
        return r
    f, why = struct(s, i, d, False, P, D)
    if f is None:
        r["why"] = why; return r
    tc, ex = cham_diem(s, i, d, f, False, P, D)
    r.update(ok=True, kind="nhip hoi", tc=tc, score=sum(tc.values()), key=f["key"], t=s.t[i], gia=s.c[i], **ex)
    return r


def mo_chain(s, m, d, P=None, D=None):
    """-> (ok, c1_in, depth) - chuoi mo C1..CK (X14MoChain)."""
    P = P or P2; D = D or d1.PARAMS; G = s.G; K = max(2, P["ChainOpen"]); c1in = False
    if m < 0 or m + K + 10 >= s.n:
        return False, False, 0.0
    for k in range(K):
        x = m + k; is_c1 = (k == K - 1)
        if d1.col(s, x) == -d or not (d * (s.c[x] - s.lw[x]) > 0):
            return False, False, 0.0
        if not (d * (s.o[x] - s.lw[x]) > 0):
            if is_c1:
                c1in = True
            else:
                return False, False, 0.0
        if not is_c1 and not up_ok(s, x, d):
            return False, False, 0.0
    if d1.w(s, m, d, 5) < D["A8"] * G:
        return False, False, 0.0
    c1 = m + K - 1; base = s.lw[c1] if c1in else s.o[c1]
    dep = d * (s.c[m] - base)
    if dep < P["D2DepthK"] * D["Depth"] * G:
        return False, False, 0.0
    return True, c1in, dep


def ctx_m1(m1_bars, t_open, G):
    """M1Context: 'Khung m1 DI LEN/DI XUONG/DI NGANG trong 30p truoc, bien X.XX' (m1_bars: [(t,o,h,l,c)] cu->moi, chi nen < t_open)."""
    ls = [b for b in m1_bars if b[0] < t_open][-150:]
    if len(ls) < 40:
        return ""
    ser = list(reversed(ls)); c = [b[4] for b in ls]
    v = c[0]; out = []
    for x in c:
        v = v + (2.0 / 51.0) * (x - v); out.append(v)
    e = list(reversed(out))
    up = all(e[j] > e[j + 3] for j in range(30)); dn = all(e[j] < e[j + 3] for j in range(30))
    hi = max(b[2] for b in ser[:30]); lo = min(b[3] for b in ser[:30]); slope = e[0] - e[29]
    tr = "ĐI NGANG"
    if up and slope >= d1.SLOPE_MIN * G:
        tr = "ĐI LÊN"
    if dn and -slope >= d1.SLOPE_MIN * G:
        tr = "ĐI XUỐNG"
    return "Khung m1 %s trong 30p trước, biên %.2f" % (tr, (hi - lo) / G * G)


def eval_mo(s, m, d, m1_bars=None, P=None, D=None):
    """Push MO: chuoi mo moi du dieu kien o nen m (chua du o nen truoc). Kem diem PULLBACK (gia dinh) + GIAO CAT (gia dinh)."""
    P = P or P2; D = D or d1.PARAMS; G = s.G
    r = {"ok": False, "sg": d, "loai": "MO", "a": m}
    if m < 0 or m + TB + LE + 10 >= s.n:
        return r
    ok, c1in, dep = mo_chain(s, m, d, P, D)
    if not ok:
        return r
    if mo_chain(s, m + 1, d, P, D)[0]:
        return r                                       # da du dieu kien o nen truoc (da push luc do)
    K = max(2, P["ChainOpen"]); doc = abs(s.o[m + K - 1] - s.o[m])
    r.update(ok=True, doc=doc, key=s.t[m + K - 1], t=s.t[m], ctx=ctx_m1(m1_bars or [], s.t[m], G) if m1_bars is not None else "")
    # GIAO CAT: nen A gia dinh = nen ngay sau m, open = close m, close = ma9-4 cua m (Đ1 chieu -d)
    gc = {"ok": False, "score": 0.0}
    if m >= 1 and m + 5 < s.n:
        a = m - 1; sv = (s.o[a], s.c[a], s.h[a], s.l[a])
        cA = s.lw[m + 4]
        s.o[a] = s.c[m]; s.c[a] = cA; s.h[a] = max(s.o[a], cA); s.l[a] = min(s.o[a], cA)
        try:
            rr = d1.eval_d1(s, a, -d, D, pot=True)
        finally:
            s.o[a], s.c[a], s.h[a], s.l[a] = sv
        if rr.get("ok"):
            gc = {"ok": True, "score": rr["score"]}
    r["gc"] = gc
    # PULLBACK: nen P gia dinh dong tai ma9-0 cua m, cum hoi 1 nen
    x = m; c1b = False
    while x < s.n - LE and x - m < 200 and d1.col(s, x) != -d and d * (s.c[x] - s.lw[x]) > 0:
        if not (d * (s.o[x] - s.lw[x]) > 0):
            c1b = True; x += 1; break
        x += 1
    cs = max(m, x - 1)
    base = s.lw[cs] if c1b else s.o[cs]
    tn = d1.seg(s, m, max(3, cs - m + 1), d, P["SlopeMinD2"]); tf = d1.seg(s, cs + 1, TB, d, P["SlopeMinD2"])
    f = {"r": m, "h0": m, "cs": cs, "nchain": cs - m + 1, "c1b": c1b, "depth": d * (s.c[m] - base), "w5": d1.w(s, m, d, 5),
         "trend": P["D2Near"] * tn + (1 - P["D2Near"]) * tf, "tn": tn, "tf": tf, "clu": 1, "key": s.t[cs]}
    tc, ex = cham_diem(s, m, d, f, True, P, D, hyp=True, c_hyp=s.lw[m])
    r["pb"] = {"score": sum(tc.values()), "ktt3": ex["ktt3"]}
    return r


# ---------------- Dinh dang push (cu phap MAG + 'AI ' o dau, ngan cach ' · ') ----------------
def _tri(sg):
    return "▲" if sg > 0 else "▼"


def _ktt(tf, ktt3):
    k = d1.next_tf(tf, 1)
    return {1: "thuận " + k, -1: "ngược " + k, 0: k + " xoắn"}.get(ktt3, "")


def _tag(ten):
    return " BTC" if ten == "BTC" else ""


def _g(ten):
    return d1.G_TAISAN.get(ten, 1.0)


def push_p(ten, kh, r):
    tx = "AI P%s ĐANG TẠO | %s%s | %s | %.1fđ" % (_tri(r["sg"]), kh, _tag(ten), "BUY" if r["sg"] > 0 else "SELL", r["score"])
    if r["score"] < P2["D2Min"]:
        tx += " | >> thiếu %.1fđ" % (P2["D2Min"] - r["score"])
    if r["sl_lon"]:
        tx += " | >> SL %.2f > %.2f" % (r["sld"] / _g(ten), d1.PARAMS["MaxSL"])
    if r.get("ktt3", -9) != -9:
        tx += " | " + ("" if r["ktt3"] == 1 else ">> ") + _ktt(kh, r["ktt3"])
    return tx.replace(" | ", d1.DAU_CACH)


def push_hoi(ten, kh, r):
    tx = "AI h%s NHỊP HỒI PULLBACK | %s%s | %s | %.1fđ" % (_tri(r["sg"]), kh, _tag(ten), "BUY" if r["sg"] > 0 else "SELL", r["score"])
    if r.get("ktt3", -9) != -9:
        tx += " | " + ("" if r["ktt3"] == 1 else ">> ") + _ktt(kh, r["ktt3"])
    return tx.replace(" | ", d1.DAU_CACH)


def push_mo(ten, kh, r):
    d = r["sg"]; lab = _ktt(kh, r["pb"]["ktt3"])
    pbt = "%.1fđ" % r["pb"]["score"] + (" (%s)" % lab if lab else "")
    tx = "AI M%s MỞ %s | %s%s | dốc %.2f | PULLBACK %s %s | GIAO CẮT %s %sđ" % (
        _tri(d), "LÊN" if d > 0 else "XUỐNG", kh, _tag(ten), r["doc"], "BUY" if d > 0 else "SELL", pbt,
        "SELL" if d > 0 else "BUY", ("%.1f" % r["gc"]["score"]) if r["gc"]["ok"] else "–")
    if r.get("ctx"):
        tx += " | " + r["ctx"]
    return tx.replace(" | ", d1.DAU_CACH)
