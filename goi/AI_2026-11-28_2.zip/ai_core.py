# -*- coding: utf-8 -*-
"""LOI NHAN BIET "DAY MO RONG" (dai MA9 mo) - quy tac cua tac gia (DAC_TA_BOT_MT5.md muc 1.3).
ma9-k = LWMA 9 (gia Close) lui k nen. Dai MO len voi m duong: ma9-0 > ma9-1 > ... > ma9-(m-1)
(dung thu tu NGHIEM NGAT, khong bang / cham / xoan). Xuong: nguoc lai. m = 1 + so nen lien tiep LWMA9 di cung chieu (toi da 5).
Chi dung nen DA DONG. Khong co phan giao dich nao."""


def lwma(closes, i, n=9):
    """LWMA(n) tai chi so i (trong so n..1, nen moi nhat nang nhat)."""
    if i < n - 1 or i >= len(closes):
        return None
    s = 0.0
    for j in range(n):
        s += closes[i - j] * (n - j)
    return s / (n * (n + 1) / 2.0)


def trang_thai(closes):
    """-> {'huong': 'len'|'xuong'|'' , 'm': 1..5, 'v': [ma9-0..ma9-4]}"""
    i = len(closes) - 1
    v = [lwma(closes, i - k) for k in range(5)]
    if any(x is None for x in v):
        return {"huong": "", "m": 0, "v": []}
    if v[0] > v[1]:
        h = "len"
    elif v[0] < v[1]:
        h = "xuong"
    else:
        return {"huong": "", "m": 1, "v": v}
    m = 1
    for k in range(1, 5):
        if (v[k - 1] > v[k]) if h == "len" else (v[k - 1] < v[k]):
            m += 1
        else:
            break
    return {"huong": h, "m": m, "v": v}


def su_kien(truoc, nay, so_bao=3):
    """'mo' (vua mo / dao chieu), 'them' (them duong), 'dong' (thu lai / xoan), '' (khong co gi)."""
    def mo(s):
        return bool(s and s.get("huong")) and s.get("m", 0) >= so_bao
    if mo(nay) and (not mo(truoc) or truoc.get("huong") != nay["huong"]):
        return "mo"
    if mo(nay) and nay["m"] > truoc.get("m", 0):
        return "them"
    if mo(truoc) and not mo(nay):
        return "dong"
    return ""


def van_ban(ten, khung, ev, nay, gia):
    huong = "LÊN ⬆️" if nay.get("huong") == "len" else ("XUỐNG ⬇️" if nay.get("huong") == "xuong" else "")
    tieu = {"mo": "DÂY MỞ RỘNG", "them": "DÂY MỞ THÊM", "dong": "DÂY THU LẠI / XOẮN"}[ev]
    dong = ["🤖 AI · %s %s · %s %s" % (ten, khung, tieu, huong if ev != "dong" else "")]
    dong.append("Giá đóng nến: %s" % gia)
    if ev != "dong":
        dong.append("Số đường đúng thứ tự: %d/5" % nay["m"])
    dong.append("ma9-0…4: " + " · ".join("%.2f" % x for x in nay.get("v", [])))
    if ev == "mo":
        dong.append("Lý do: các đường MA9 xếp đúng thứ tự, không chạm, không xoắn.")
    elif ev == "them":
        dong.append("Lý do: LWMA9 đi cùng chiều thêm một nến → thêm đường mở.")
    else:
        dong.append("Lý do: thứ tự các đường MA9 bị phá, dây thu lại.")
    dong.append("Cấp: CHỈ BÁO (AI không vào lệnh).")
    return "\n".join(dong)
