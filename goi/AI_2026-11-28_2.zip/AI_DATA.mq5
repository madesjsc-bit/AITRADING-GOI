//+------------------------------------------------------------------+
//| AI_DATA - CHI XUAT DU LIEU nen (khong co ham giao dich nao).      |
//| Tu tim ma vang (XAU / GOLD), xuat nen DA DONG M1,M5,M15,H1 ra    |
//| MQL5\Files\AI\XAU_<khung>.csv moi vai giay.                       |
//+------------------------------------------------------------------+
#property strict
input int InpBars   = 400;   // so nen xuat
input int InpSeconds = 5;    // chu ky (giay)

string g_sym = "";
datetime g_last[4];
ENUM_TIMEFRAMES g_tf[4] = {PERIOD_M1, PERIOD_M5, PERIOD_M15, PERIOD_H1};
string g_nm[4] = {"M1", "M5", "M15", "H1"};

string PickSymbol()
{
   int n = SymbolsTotal(false);
   for(int i = 0; i < n; i++)
   {
      string s = SymbolName(i, false);
      string u = s;
      StringToUpper(u);
      if(StringFind(u, "XAU") >= 0 || StringFind(u, "GOLD") >= 0)
      {
         SymbolSelect(s, true);
         return s;
      }
   }
   return "";
}

int OnInit()
{
   FolderCreate("AI");
   for(int k = 0; k < 4; k++) g_last[k] = 0;
   EventSetTimer(InpSeconds);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void ExportTf(int k)
{
   MqlRates r[];
   ArraySetAsSeries(r, false);
   int n = CopyRates(g_sym, g_tf[k], 1, InpBars, r); // vi tri 1 = bo nen dang chay, chi nen da dong
   if(n < 20) return;
   if(r[n-1].time == g_last[k]) return;               // chua co nen moi
   string tmp = "AI\\" + "XAU_" + g_nm[k] + ".tmp";
   string dst = "AI\\" + "XAU_" + g_nm[k] + ".csv";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_ANSI);
   if(h == INVALID_HANDLE) return;
   int dg = (int)SymbolInfoInteger(g_sym, SYMBOL_DIGITS);
   for(int i = 0; i < n; i++)
      FileWriteString(h, StringFormat("%I64d,%s,%s,%s,%s,%I64d\r\n", (long)r[i].time,
                      DoubleToString(r[i].open, dg), DoubleToString(r[i].high, dg),
                      DoubleToString(r[i].low, dg), DoubleToString(r[i].close, dg), r[i].tick_volume));
   FileClose(h);
   if(FileMove(tmp, 0, dst, FILE_REWRITE)) g_last[k] = r[n-1].time;
}

void OnTimer()
{
   if(g_sym == "")
   {
      g_sym = PickSymbol();
      if(g_sym == "") return;
      int h = FileOpen("AI\\symbol.txt", FILE_WRITE | FILE_TXT | FILE_ANSI);
      if(h != INVALID_HANDLE) { FileWriteString(h, g_sym); FileClose(h); }
   }
   for(int k = 0; k < 4; k++) ExportTf(k);
}
