# -*- coding: utf-8 -*-
"""BAI 1 - HOC MOI CAY NEN (tac gia 28/11): 4 ky nang, hoc tu GIA EXNESS (file gia MAG) tung giay, MOI nen (khong can la A/P):
  K1 BAT RAU DUOI cua nen xanh (BUY)         K2 BAT RAU TREN cua nen do (SELL)
  K3 NHAN RA nen 'len luon khong rau duoi' / 'xuong luon khong rau tren' (khong cho hoi, khong co rau de bat)
  K4 CAM NHAN nen se XANH hay DO
Sau khi BAI 1 'hoc xong' (du tieu chi, tac gia duyet) -> sang BAI 2:
BAI 2 - DANH GIA CAY A TOT: la cay A ma nen B se xanh (BUY) / do (SELL) va gia di them du xa de DOI SL DUONG (MFE >= 1 x SL).
Chi nghien cuu/gia lap."""
import csv, json, os, statistics, time
import ai_tick, ai_hocnen, ai_hocrau, ai_tiendo

NG1 = {"nen_toi_thieu": 3000, "mau_moi_dang": 300, "bat_rau": 0.80, "pha_day_toi_da": 0.35, "auc_khong_rau": 0.70, "auc_mau": 0.65, "ngay_on_dinh": 3}
NG2 = {"mau_cay_A": 100, "auc_diem": 0.60, "ti_le_tot_toi_thieu": 0.30, "mfe_r": 1.0}

TEN_SOM = ["giay_tren_nen", "x_so_open", "dinh_so_open", "day_so_open", "toc_do_5s", "toc_do_15s", "ti_le_tick_len", "nen_truoc_mau",
           "rau_nen_truoc", "so_nen_nguoc_truoc", "cu_chay_truoc", "bien_do_u"]


def mau_som(ticks, nen, idx, sg, G, sec=60):
    """Mau o cac moc 5,10,..,50 giay dau nen (khong can co rau). -> [(f, xanh, khong_rau)]"""
    t0, i0, i1 = nen[idx]; u = ai_hocrau._u_truot(ticks, nen, idx)
    if u <= 0 or i1 - i0 < 40:
        return []
    xs = [sg * ticks[j][1] for j in range(i0, i1)]; ts = [ticks[j][0] - t0 for j in range(i0, i1)]
    o = xs[0]; close = xs[-1]; xanh = 1 if close > o else 0
    khong_rau = 1 if (xanh and (o - min(xs)) <= 0.1 * u) else 0
    pcol = prau = 0.0
    if idx > 0 and nen[idx - 1][0] + sec == t0:
        px = [sg * ticks[j][1] for j in range(nen[idx - 1][1], nen[idx - 1][2])]; pcol = (px[-1] - px[0]) / u; prau = (min(px[0], px[-1]) - min(px)) / u
    nguoc = 0; chay = 0.0; q = idx - 1
    while q >= max(0, idx - 12) and nen[q][0] + sec == nen[q + 1][0]:
        a_, b_ = nen[q][1], nen[q][2]
        if sg * (ticks[b_ - 1][1] - ticks[a_][1]) < 0:
            nguoc += 1; chay += abs(ticks[b_ - 1][1] - ticks[a_][1]); q -= 1
        else:
            break
    out = []
    for frac in (0.08, 0.17, 0.25, 0.33, 0.5, 0.67, 0.83):
        j = int(frac * (len(xs) - 1))
        if j < 2:
            continue
        w = xs[:j + 1]; hi = max(w); lo = min(w)
        f = [ts[j] / float(sec), (xs[j] - o) / u, (hi - o) / u, (o - lo) / u, (xs[j] - xs[max(0, j - 5)]) / u, (xs[j] - xs[max(0, j - 15)]) / u,
             sum(1 for a in range(max(1, j - 9), j + 1) if xs[a] > xs[a - 1]) / 10.0, pcol, prau, nguoc / 12.0, chay / u / 10.0, u / G]
        out.append((f, xanh, khong_rau, frac))
    return out


def hoc_bai1(data_dir, mas, Gmap):
    """Huan luyen K3/K4 (+ doc ket qua K1/K2 tu mo hinh chung) tren MOI nen. Ghi data/bai1.json."""
    tr = []; te = []; dem = {"nen": 0, "xanh_rau_duoi": 0, "do_rau_tren": 0, "xanh_khong_rau": 0, "do_khong_rau": 0}
    ds_nen = {}
    for ten in mas:
        ticks = ai_tick.doc_het(data_dir, ten)
        for sec in (60, 300, 900):
            nen = ai_hocnen.nen_idx(ticks, sec)[-ai_hocnen.TOI_DA_NEN:]
            if len(nen) < 40:
                continue
            cut = int(len(nen) * 0.7); ds_nen["%s_M%d" % (ten, sec // 60)] = len(nen)
            for idx in range(31 if sec == 60 else 11, len(nen)):
                t0, i0, i1 = nen[idx]; dem["nen"] += 1
                o = ticks[i0][1]; c = ticks[i1 - 1][1]; v = [ticks[j][1] for j in range(i0, i1)]
                u = max(1e-12, ai_hocrau._u_truot(ticks, nen, idx)) 
                if c > o:
                    dem["xanh_rau_duoi" if (o - min(v)) > 0.1 * u else "xanh_khong_rau"] += 1
                elif c < o:
                    dem["do_rau_tren" if (max(v) - o) > 0.1 * u else "do_khong_rau"] += 1
                for sg in (1, -1):
                    for f, xanh, kr, frac in mau_som(ticks, nen, idx, sg, Gmap.get(ten, 1.0), sec):
                        (tr if idx < cut else te).append((f, xanh, kr, frac))
    res = {"t": int(time.time()), "dem": dem, "nen_theo_ma": ds_nen}
    if len(tr) < 400 or len(te) < 150:
        res["ly_do"] = "chua du mau (hoc %d, thu %d)" % (len(tr), len(te)); _luu(data_dir, res); return res
    if len(tr) > 12000:
        st = len(tr) / 12000.0; tr = [tr[int(i * st)] for i in range(12000)]
    edges = ai_hocrau.chia_bin([x[0] for x in tr]); Xb = [ai_hocrau.bin_hoa(x[0], edges) for x in tr]; Xt = [ai_hocrau.bin_hoa(x[0], edges) for x in te]
    mo = {}
    for nm, vi in (("mau", 1), ("khong_rau", 2)):
        sk, gf = ai_hocrau.tang_cuong(Xb, [x[vi] for x in tr]); pt = [ai_hocrau.du_doan(sk, x) for x in Xt]; yt = [x[vi] for x in te]
        mo[nm] = sk
        sub = {}
        for lo, hi, nh in ((0, 0.2, "som(<=12s)"), (0.2, 0.45, "giua(~15-27s)"), (0.45, 1.0, "muon(>30s)")):
            ids = [i for i, x in enumerate(te) if lo <= x[3] < hi]
            if len(ids) > 60:
                sub[nh] = {"auc": ai_hocrau.auc([yt[i] for i in ids], [pt[i] for i in ids]),
                           "acc": sum(1 for i in ids if (pt[i] >= 0.5) == bool(yt[i])) / float(len(ids))}
        res[nm] = {"auc": ai_hocrau.auc(yt, pt), "ti_le_duong": sum(yt) / float(len(yt)), "theo_thoi_diem": sub,
                   "quan_trong": [TEN_SOM[i] for i in sorted(range(len(gf)), key=lambda i: -gf[i])[:3] if gf[i] > 0]}
    with open(os.path.join(data_dir, "bai1_model.json"), "w", encoding="utf-8") as f:
        json.dump({"edges": edges, "mau": mo["mau"], "khong_rau": mo["khong_rau"]}, f)
    _luu(data_dir, res)
    return res


def _luu(data_dir, res):
    with open(os.path.join(data_dir, "bai1.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)


def doc_bai1(data_dir):
    try:
        return json.load(open(os.path.join(data_dir, "bai1.json"), encoding="utf-8"))
    except Exception:
        return None


def rau_moi_nen(data_dir, mas, Gmap):
    """K1/K2 tren MOI nen (dung mo hinh chung): ti le bat rau trung vi, ti le rau bi pha - tren du lieu SAU."""
    out = {}
    for sg, nm in ((1, "K1"), (-1, "K2")):
        rs = []
        for ten in mas:
            m = ai_tiendo.tai_model(data_dir, ten, "BUY" if sg > 0 else "SELL")
            if not m:
                continue
            ticks = ai_tick.doc_het(data_dir, ten); G = Gmap.get(ten, 1.0)
            nen = ai_hocnen.nen_idx(ticks); cut = int(len(nen) * 0.7)
            sig = [nen[i][0] for i in range(max(cut, 31), len(nen))]
            rs += [r for r in ai_tiendo.danh_gia_o_moi_nen(ticks, nen, sig, sg, G, m) if r]
        out[nm] = ai_tiendo.tong_hop(rs) if rs else None
        if rs:
            out[nm]["pha_day"] = sum(1 for r in rs if r.get("pha")) / float(len(rs))
    return out


def tieu_chi_bai1(data_dir, b1, k12):
    d = b1["dem"]; ls = _ls(data_dir)
    mm = min(d["xanh_rau_duoi"], d["do_rau_tren"], d["xanh_khong_rau"], d["do_khong_rau"])
    k1 = k12.get("K1"); k2 = k12.get("K2")
    ngay = sorted(ls)[-NG1["ngay_on_dinh"]:]
    ok_st = len(ngay) >= NG1["ngay_on_dinh"] and all(ls[x] for x in ngay)
    km = b1.get("khong_rau", {}); mau = b1.get("mau", {})
    def am(sub):
        v = [x["auc"] for k, x in sub.items() if "giua" in k or "muon" in k]
        return max(v) if v else mau.get("auc", 0)
    c = [("Đủ nến: %d/%d nến · mỗi dạng ≥%d (ít nhất %d)" % (d["nen"], NG1["nen_toi_thieu"], NG1["mau_moi_dang"], mm), d["nen"] >= NG1["nen_toi_thieu"] and mm >= NG1["mau_moi_dang"]),
         ("K1 bắt râu DƯỚI ≥%.0f%% râu%s" % (NG1["bat_rau"] * 100, (": %.0f%%" % (k1["bat_tv"] * 100)) if k1 else ": chưa có"), bool(k1 and k1["bat_tv"] >= NG1["bat_rau"] and k1["pha_day"] <= NG1["pha_day_toi_da"])),
         ("K2 bắt râu TRÊN ≥%.0f%% râu%s" % (NG1["bat_rau"] * 100, (": %.0f%%" % (k2["bat_tv"] * 100)) if k2 else ": chưa có"), bool(k2 and k2["bat_tv"] >= NG1["bat_rau"] and k2["pha_day"] <= NG1["pha_day_toi_da"])),
         ("K3 nhận ra nến 'đi thẳng không râu' AUC ≥%.2f%s" % (NG1["auc_khong_rau"], (": %.2f" % km["auc"]) if km else ""), bool(km and km["auc"] >= NG1["auc_khong_rau"])),
         ("K4 cảm nhận xanh/đỏ AUC ≥%.2f (giữa/muộn nến)%s" % (NG1["auc_mau"], (": %.2f" % am(mau.get("theo_thoi_diem", {}))) if mau else ""), bool(mau and am(mau.get("theo_thoi_diem", {})) >= NG1["auc_mau"])),
         ("Ổn định %d ngày liên tiếp đạt" % NG1["ngay_on_dinh"], ok_st)]
    return c


def _ls(data_dir):
    d = {}
    try:
        for r in csv.reader(open(os.path.join(data_dir, "bai1_lichsu.csv"), encoding="utf-8")):
            if len(r) >= 2:
                d[r[0]] = r[1] == "1"
    except OSError:
        pass
    return d


def ghi_lichsu_bai1(data_dir, dat):
    ngay = time.strftime("%Y-%m-%d", time.gmtime(time.time() + 7 * 3600)); d = _ls(data_dir); d[ngay] = dat
    with open(os.path.join(data_dir, "bai1_lichsu.csv"), "w", encoding="utf-8", newline="") as f:
        for k in sorted(d)[-30:]:
            csv.writer(f).writerow([k, "1" if d[k] else "0"])


# ---------------- BAI 2: danh gia cay A tot ----------------
def gan_nhan_cay_A(data_dir, st, mas):
    """Moi tin hieu A/P da qua B: nhan TOT neu B xanh dung chieu VA gia di them >= 1 x SL (du doi SL duong). Ghi ai_nhan_A.csv."""
    import ai_hoc
    xong = st.setdefault("nhan_A", [])
    now = time.time(); tick_cache = {}
    try:
        rows = list(csv.reader(open(os.path.join(data_dir, "ai_phathien.csv"), encoding="utf-8")))
    except OSError:
        return 0
    n = 0
    for r in rows:
        if len(r) < 8 or r[3] not in ("A_dangtao", "P_dangtao") or r[2] != "M1":
            continue
        t, ten, sg, score = int(r[0]), r[1], int(r[4]), float(r[7]); key = "%s_%d_%d" % (ten, t, sg)
        if key in xong or now - t < 60 + 240:
            continue
        if ten not in mas:
            continue
        ticks = tick_cache.setdefault(ten, ai_tick.doc_het(data_dir, ten))
        tb = t + 60; seg = [(ts, sg * b) for ts, b in ticks if tb <= ts < tb + 240]
        if len(seg) < 100:
            xong.append(key); continue
        ob = seg[0][1]; cb = next((b for ts, b in seg if ts >= tb + 59), seg[-1][1]); mfe = max(b for _, b in seg) - ob
        sn = ai_hoc.doc_snap(data_dir, ai_hoc.tao_id(ten, "M1", t, sg, "a" if r[3] == "A_dangtao" else "p"))
        risk = (sn or {}).get("sld") or max(1e-9, statistics.median([abs(seg[i + 1][1] - seg[i][1]) for i in range(len(seg) - 1)]) * 60)
        tot = 1 if (cb > ob and mfe >= NG2["mfe_r"] * risk) else 0
        try:
            with open(os.path.join(data_dir, "ai_nhan_A.csv"), "a", encoding="utf-8", newline="") as f:
                csv.writer(f).writerow([t, ten, r[3], sg, round(score, 2), int(cb > ob), round(mfe / risk, 2), tot])
        except OSError:
            pass
        xong.append(key); n += 1
    st["nhan_A"] = xong[-2000:]
    return n


def bao_cao_bai2(data_dir):
    rows = []
    try:
        rows = [r for r in csv.reader(open(os.path.join(data_dir, "ai_nhan_A.csv"), encoding="utf-8")) if len(r) >= 8]
    except OSError:
        pass
    o = ["— BÀI 2 · Đánh giá CÂY A TỐT (B xanh đúng chiều + giá đi thêm ≥ %.1f×SL để dời SL dương)" % NG2["mfe_r"]]
    if not rows:
        o.append("   Đang thu nhãn (chưa có cây A nào đủ thời gian đánh giá). Bài 2 chính thức bắt đầu sau khi Bài 1 học xong."); return o
    tot = [int(r[7]) for r in rows]; sc = [float(r[4]) for r in rows]
    o.append("   %d cây A/P đã có nhãn · %.0f%% là cây TỐT · B xanh đúng chiều %.0f%%" % (len(rows), 100.0 * sum(tot) / len(tot), 100.0 * sum(int(r[5]) for r in rows) / len(rows)))
    if len(set(tot)) > 1:
        o.append("   Điểm MAG dự đoán cây tốt: AUC %.2f (0.5 = vô dụng)" % ai_hocrau.auc(tot, sc))
    for lo, hi in ((0, 5), (5, 7), (7, 11)):
        g = [int(r[7]) for r in rows if lo <= float(r[4]) < hi]
        if g:
            o.append("   Điểm %d–%s: %d cây · tốt %.0f%%" % (lo, "10" if hi == 11 else hi, len(g), 100.0 * sum(g) / len(g)))
    if len(rows) < NG2["mau_cay_A"]:
        o.append("   Cần ≥ %d cây A để kết luận (đang %d)." % (NG2["mau_cay_A"], len(rows)))
    return o


def bao_cao(data_dir, mas, Gmap):
    b1 = doc_bai1(data_dir)
    o = ["📚 BÁO CÁO HỌC – BÀI 1: học MỌI cây nến (giá Exness từng giây)"]
    if not b1 or "dem" not in b1:
        o.append("   Chưa có dữ liệu (cần giá từng giây ≥ vài giờ)."); o += bao_cao_bai2(data_dir); return "\n".join(o)
    d = b1["dem"]
    o.append("   Đã học %d nến (%s)" % (d["nen"], " · ".join("%s %d" % kv for kv in sorted(b1["nen_theo_ma"].items()))))
    o.append("   Xanh có râu dưới %d · Đỏ có râu trên %d · Xanh đi thẳng (không râu) %d · Đỏ đi thẳng %d" % (d["xanh_rau_duoi"], d["do_rau_tren"], d["xanh_khong_rau"], d["do_khong_rau"]))
    if "ly_do" in b1:
        o.append("   " + b1["ly_do"])
    else:
        k12 = rau_moi_nen(data_dir, mas, Gmap)
        for nm, tx in (("K1", "K1 · BUY bắt RÂU DƯỚI nến xanh"), ("K2", "K2 · SELL bắt RÂU TRÊN nến đỏ")):
            k = k12.get(nm)
            kq = ("bắt được %.0f%% râu (trung vị) · râu bị phá %.0f%% · SL TB %.2f giá · lãi TB %+.2f giá · %d nến thử" % (
                k["bat_tv"] * 100, k["pha_day"] * 100, k["sl_tb"], k["loi_tb"], k["n_vao"])) if k else "chưa có mô hình/dữ liệu"
            o.append("   %s: %s" % (tx, kq))
        km = b1["khong_rau"]; mau = b1["mau"]
        o.append("   K3 · nhận ra nến đi thẳng KHÔNG RÂU: AUC %.2f (%.0f%% nến là loại này) · dựa vào: %s" % (km["auc"], km["ti_le_duong"] * 100, ", ".join(km["quan_trong"])))
        o.append("   K4 · cảm nhận XANH hay ĐỎ: " + " · ".join("%s AUC %.2f, đúng %.0f%%" % (k, x["auc"], x["acc"] * 100) for k, x in mau["theo_thoi_diem"].items()))
        ch = tieu_chi_bai1(data_dir, b1, k12); ok = sum(1 for _, x in ch if x)
        o.append("   TIẾN ĐỘ BÀI 1: %d/%d tiêu chí %s" % (ok, len(ch), "🎓 HỌC XONG – chờ anh duyệt để sang BÀI 2" if ok == len(ch) else ""))
        for tx, x in ch:
            o.append("     %s %s" % ("✅" if x else "⏳", tx))
        ghi_lichsu_bai1(data_dir, ok == len(ch))
        if ok < len(ch):
            ngay_co = max(0.25, (time.time() - os.path.getmtime(os.path.join(data_dir, "bai1_model.json"))) / 86400.0) if os.path.exists(os.path.join(data_dir, "bai1_model.json")) else 1.0
            o.append("   Dự kiến: cần ≥ %d nến + %d ngày ổn định → còn khoảng %s" % (NG1["nen_toi_thieu"], NG1["ngay_on_dinh"],
                     "≥ %d ngày (đã đủ nến, chờ ổn định/đạt ngưỡng)" % NG1["ngay_on_dinh"] if d["nen"] >= NG1["nen_toi_thieu"] else "%d ngày" % max(NG1["ngay_on_dinh"], int(round(NG1["nen_toi_thieu"] / max(300.0, d["nen"] / ngay_co) + 0.5))) ))
    o += bao_cao_bai2(data_dir)
    return "\n".join(o)


def bai1_dat(data_dir, mas, Gmap):
    """-> (so tieu chi dat, tong). Dung de bao khi HOC XONG."""
    b1 = doc_bai1(data_dir)
    if not b1 or "dem" not in b1 or "ly_do" in b1:
        return 0, 6
    ch = tieu_chi_bai1(data_dir, b1, rau_moi_nen(data_dir, mas, Gmap))
    return sum(1 for _, x in ch if x), len(ch)
