# -*- coding: utf-8 -*-
"""BOT AI v0 (chi bao): doc nen XAU do MT5 cua AI xuat ra (AI_DATA.mq5), nhan biet "day mo rong", bao Telegram.
Luat nam trong data/luat_ai.json (tac gia day dan dan, Claude cap nhat bang lenh `luat`). CHUA hoc may."""
import os, json, csv, time
import ai_core
import ai_d1
import ai_hoc
import ai_d2
import ai_sim

MAC_DINH = {"khung": ["M1", "M5"], "so_duong_bao": 3, "chong_lap_giay": 60, "bao_dong": True, "ten": "XAU", "d1": True, "kieu_cu": False, "gio_san": 0}
CHO_PHEP = {"khung": list, "so_duong_bao": int, "chong_lap_giay": int, "bao_dong": bool, "ten": str, "d1": bool, "kieu_cu": bool, "gio_san": int}


def tai_luat(data_dir):
    luat = dict(MAC_DINH)
    try:
        with open(os.path.join(data_dir, "luat_ai.json"), encoding="utf-8") as f:
            for k, v in json.load(f).items():
                if k in CHO_PHEP:
                    luat[k] = v
    except Exception:
        pass
    return luat


def sua_luat(data_dir, kv):
    """kv: dict chuoi. Chi nhan khoa trong danh sach cho phep. Tra ve (ok, thong bao)."""
    luat = tai_luat(data_dir)
    for k, v in kv.items():
        if k not in CHO_PHEP:
            return False, "khoa khong hop le: %s (duoc: %s)" % (k, ", ".join(sorted(CHO_PHEP)))
        try:
            if k == "khung":
                luat[k] = [x for x in v.replace(" ", "").split(",") if x in ("M1", "M5", "M15", "H1")]
                if not luat[k]:
                    return False, "khung phai trong M1,M5,M15,H1"
            elif k == "gio_san":
                luat[k] = max(-12, min(14, int(v)))
            elif k == "so_duong_bao":
                luat[k] = max(2, min(5, int(v)))
            elif k == "chong_lap_giay":
                luat[k] = max(0, min(3600, int(v)))
            elif k in ("bao_dong", "d1", "kieu_cu"):
                luat[k] = v.lower() in ("1", "true", "on", "co")
            else:
                luat[k] = ",".join(x for x in v.upper().replace(" ", "").split(",") if x in ("XAU", "BTC")) or "XAU"
        except ValueError:
            return False, "gia tri khong hop le cho %s" % k
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "luat_ai.json"), "w", encoding="utf-8") as f:
        json.dump(luat, f, ensure_ascii=False, indent=1)
    return True, json.dumps(luat, ensure_ascii=False)


def doc_nen(path, toida=60):
    """CSV: time,open,high,low,close,tickvol (nen DA DONG). -> (times, closes) hoac None."""
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            rows = [l.strip().split(",") for l in f.read().splitlines()[-toida:] if l.strip()]
        rows = [r for r in rows if len(r) >= 5 and r[0].isdigit()]
        return [int(r[0]) for r in rows], [float(r[4]) for r in rows]
    except Exception:
        return None


def doc_ohlc(path, toida=400):
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            rows = [l.strip().split(",") for l in f.read().splitlines()[-toida:] if l.strip()]
        return [(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])) for r in rows if len(r) >= 5 and r[0].isdigit()]
    except Exception:
        return None


def chay(files_dir, data_dir, st, gui, log):
    """Goi dinh ky. gui(text) -> gui Telegram. Tra ve so tin da gui."""
    luat = tai_luat(data_dir)
    ai = st.setdefault("ai", {})
    da_gui = 0
    for ten, kh in [(t, k) for t in luat["ten"].split(",") for k in luat["khung"]]:
        r = doc_nen(os.path.join(files_dir, "%s_%s.csv" % (ten, kh)))
        if not r or len(r[1]) < 13:
            continue
        times, closes = r
        key = kh if ten == "XAU" else "%s_%s" % (ten, kh)   # XAU giu khoa cu
        s = ai.get(key)
        if s and s.get("t") == times[-1]:
            continue  # chua co nen dong moi
        nay = ai_core.trang_thai(closes)
        if s is None:  # lan dau: chi ghi nhan
            ai[key] = {"t": times[-1], "huong": nay["huong"], "m": nay["m"], "gui": 0}
            continue
        if luat.get("kieu_cu") and luat.get("d1", True):
            ohlc = doc_ohlc(os.path.join(files_dir, "%s_%s.csv" % (ten, kh)))
            if ohlc and len(ohlc) >= 100:
                sr = ai_d1.SR(ohlc, ai_d1.G_TAISAN.get(ten, 1.0))
                for sg in (1, -1):
                    rr = ai_d1.eval_d1(sr, 1, sg)
                    if rr["ok"]:
                        try:
                            os.makedirs(data_dir, exist_ok=True)
                            with open(os.path.join(data_dir, "ai_phathien.csv"), "a", encoding="utf-8", newline="") as f:
                                csv.writer(f).writerow([times[-1], ten, kh, "d1_" + rr["kind"], sg, rr["nhanh"], rr["gia"], rr["sl"]])
                        except OSError:
                            pass
                        if gui(ai_d1.van_ban(ten, kh, rr)):
                            da_gui += 1
                        log("AI %s %s D1 %s %s" % (ten, kh, rr["kind"], "BUY" if sg > 0 else "SELL"))
        ev = ai_core.su_kien({"huong": s["huong"], "m": s["m"]}, nay, luat["so_duong_bao"])
        s.update({"t": times[-1], "huong": nay["huong"], "m": nay["m"]})
        if ev == "dong" and not luat["bao_dong"]:
            ev = ""
        if not luat.get("kieu_cu"):
            ev = ""   # cu phap MAG: dung "MO" (chua port) - tin kieu cu tat
        if ev:
            try:
                os.makedirs(data_dir, exist_ok=True)
                with open(os.path.join(data_dir, "ai_phathien.csv"), "a", encoding="utf-8", newline="") as f:
                    csv.writer(f).writerow([times[-1], ten, kh, ev, nay["huong"], nay["m"], closes[-1]])
            except OSError:
                pass
            if time.time() - s.get("gui", 0) >= luat["chong_lap_giay"]:
                if gui(ai_core.van_ban(ten, kh, ev, nay, "%.2f" % closes[-1])):
                    s["gui"] = time.time()
                    da_gui += 1
                log("AI %s %s %s m=%d" % (ten, kh, ev, nay["m"]))
    return da_gui


def _ghi_csv(data_dir, row):
    try:
        os.makedirs(data_dir, exist_ok=True)
        with open(os.path.join(data_dir, "ai_phathien.csv"), "a", encoding="utf-8", newline="") as fh:
            csv.writer(fh).writerow(row)
    except OSError:
        pass


def chay_dong(mem_feed, data_dir, st, gui, log):
    """Khi 1 nen vua DONG (nen moi bat dau): push NHIP HOI (h) va MO (M) giong OnNewBar cua MAG. MO chi 1 lan / xu huong."""
    luat = tai_luat(data_dir); ai_hoc.GIO_SAN = luat.get("gio_san", 0)
    if not luat.get("d1", True):
        return 0
    rec = st.setdefault("ai_dong", {}); lastmo = st.setdefault("ai_mo", {})
    n = 0
    for ten in luat["ten"].split(","):
        bars = (mem_feed.get(ten) or {}).get("bars") or {}
        for kh in luat["khung"]:
            ls = bars.get(kh) or []
            if len(ls) < 100:
                continue
            f = ls[-1]; sk = "%s_%s" % (ten, kh)
            if sk not in rec:
                rec[sk] = f[0]; continue          # lan dau chi ghi nhan
            if rec[sk] == f[0]:
                continue
            rec[sk] = f[0]
            htf = {k: [tuple(b[:5]) for b in (bars.get(k) or [])] for k in ("M5", "M15", "M30", "H1", "H4")}
            sr = ai_d1.SR([tuple(b[:5]) for b in ls[:-1]], ai_d1.G_TAISAN.get(ten, 1.0), forming=tuple(f[:5]), tf=kh, htf=htf)
            m1 = [tuple(b[:5]) for b in (bars.get("M1") or [])[:-1]]
            for d in (1, -1):
                r = ai_d2.eval_mo(sr, 1, d, m1)
                if not r["ok"]:
                    continue
                if lastmo.get(sk) == d:
                    continue                       # da push MO cung chieu -> cho MO nguoc chieu
                lastmo[sk] = d
                sid = ai_hoc.tao_id(ten, kh, f[0] - ai_d1.KHUNG_GIAY[kh], d, "m")
                ai_hoc.luu_snap(data_dir, sid, {"id": sid, "loai": "MO", "ten": ten, "kh": kh, "sg": d, "t": f[0] - ai_d1.KHUNG_GIAY[kh], "doc": r["doc"], "pb_score": r["pb"]["score"],
                                                "gc_ok": r["gc"]["ok"], "gc_score": r["gc"]["score"], "ctx": r.get("ctx", "")})
                _ghi_csv(data_dir, [f[0], ten, kh, "MO", d, "", "", round(r["pb"]["score"], 1)])
                if gui(ai_d2.push_mo(ten, kh, r) + ai_hoc.chan_tin(sid), ai_hoc.ban_phim(sid)):
                    n += 1
                log("AI %s %s MO %s" % (ten, kh, "LEN" if d > 0 else "XUONG"))
            for d in (1, -1):
                rsp = ai_d2.eval_sp(sr, 1, d)
                if rsp["ok"]:
                    sid = ai_hoc.tao_id(ten, kh, f[0] - ai_d1.KHUNG_GIAY[kh], d, "s")
                    ai_hoc.luu_snap(data_dir, sid, {"id": sid, "loai": "SP", "ten": ten, "kh": kh, "sg": d, "t": f[0] - ai_d1.KHUNG_GIAY[kh], "kind": "suyt P",
                                                    "nhanh": "", "score": rsp["score"], "tc": rsp["tc"], "sl": rsp["sl"], "sld": rsp["sld"], "sl_lon": rsp["sl_lon"]})
                    _ghi_csv(data_dir, [f[0] - ai_d1.KHUNG_GIAY[kh], ten, kh, "SP_dong", d, "", round(rsp["gia"], 2), round(rsp["score"], 1)])
                    if gui(ai_d2.push_sp(ten, kh, rsp) + ai_hoc.chan_tin(sid, ai_hoc.doc_snap(data_dir, sid)), ai_hoc.ban_phim(sid)):
                        n += 1
                    log("AI %s %s SUYT P %s %.1fd" % (ten, kh, "BUY" if d > 0 else "SELL", rsp["score"]))
            for d in (1, -1):
                r = ai_d2.eval_hoi(sr, 1, d)
                if r["ok"]:
                    sid = ai_hoc.tao_id(ten, kh, f[0] - ai_d1.KHUNG_GIAY[kh], d, "h")
                    ai_hoc.luu_snap(data_dir, sid, {"id": sid, "loai": "HOI", "ten": ten, "kh": kh, "sg": d, "t": f[0], "nhanh": "", "score": r["score"],
                                                    "tc": r["tc"], "sl": r["sl"], "sld": r["sld"], "sl_lon": r["sl_lon"]})
                    _ghi_csv(data_dir, [f[0], ten, kh, "HOI", d, "", round(r["gia"], 2), round(r["score"], 1)])
                    if gui(ai_d2.push_hoi(ten, kh, r) + ai_hoc.chan_tin(sid), ai_hoc.ban_phim(sid)):
                        n += 1
                    log("AI %s %s HOI %s %.1fd" % (ten, kh, "BUY" if d > 0 else "SELL", r["score"]))
    return n


def chay_pot(mem_feed, data_dir, st, gui, log, thoai=None):
    """Cay A DANG TAO (nen dang chay) - giong PotPush/OnPotential cua MAG: moi nen 1 push, moi setup (key) chi push lan dau."""
    luat = tai_luat(data_dir); ai_hoc.GIO_SAN = luat.get("gio_san", 0)
    if not luat.get("d1", True):
        return 0
    ai = st.setdefault("ai_pot", {})
    n = 0
    for ten in luat["ten"].split(","):
        bars = (mem_feed.get(ten) or {}).get("bars") or {}
        for kh in luat["khung"]:
            ls = bars.get(kh) or []
            if len(ls) < 100:
                continue
            f = ls[-1]
            sk = "%s_%s" % (ten, kh)
            rec = ai.setdefault(sk, {"bar": 0, "key": {}})
            if rec["bar"] == f[0]:
                continue                       # nen nay da co push (1 push / nen / khung)
            htf = {k: [tuple(b[:5]) for b in (bars.get(k) or [])] for k in ("M5", "M15", "M30", "H1", "H4")}
            sr = ai_d1.SR([tuple(b[:5]) for b in ls[:-1]], ai_d1.G_TAISAN.get(ten, 1.0), forming=tuple(f[:5]), tf=kh, htf=htf)
            for sg in (1, -1):
                r = ai_d1.eval_d1(sr, 0, sg, pot=True)
                if r["ok"] and rec["key"].get(str(sg)) != r["key"]:
                    rec["key"][str(sg)] = r["key"]; rec["bar"] = f[0]
                    sid = ai_hoc.tao_id(ten, kh, f[0], sg, "a")
                    ai_hoc.luu_snap(data_dir, sid, {"id": sid, "loai": "A", "ten": ten, "kh": kh, "sg": sg, "t": f[0], "kind": r["kind"], "nhanh": r["nhanh"],
                                                    "score": r["score"], "tc": r["tc"], "len": r["len"], "nb": r["nb"], "depth": r["depth"],
                                                    "a8": r["a8"], "sl": r["sl"], "sld": r["sld"], "sl_lon": r["sl_lon"]})
                    _ghi_csv(data_dir, [f[0], ten, kh, "A_dangtao", sg, r["nhanh"], round(r["gia"], 2), round(r["score"], 1)])
                    ai_sim.cho_theo_doi(st, sid, ten, kh, sg, f[0])
                    if gui(ai_d1.push_a(ten, kh, r) + ai_hoc.chan_tin(sid, ai_hoc.doc_snap(data_dir, sid)), ai_hoc.ban_phim(sid)):
                        n += 1
                    if thoai:
                        thoai(ai_hoc.doc_snap(data_dir, sid))
                    log("AI %s %s A dang tao %s %.1fd" % (ten, kh, "BUY" if sg > 0 else "SELL", r["score"]))
                    break
                # P tiem nang (OnPotential cua MAG): open trong dai -> gia cham ma9-1; open da ngoai dai -> sau #30 giay neu xanh
                if sg * (sr.o[0] - sr.lw[0]) <= 0:
                    trig = sg * (sr.c[0] - sr.lw[1]) >= 0
                else:
                    trig = (time.time() - f[0] >= 30) and ai_d1.col(sr, 0) == sg
                if not trig:
                    continue
                rp = ai_d2.eval_p(sr, 0, sg, pot=True)
                if rp["ok"] and rec.setdefault("keyp", {}).get(str(sg)) != rp["key"]:
                    rec["keyp"][str(sg)] = rp["key"]; rec["bar"] = f[0]
                    sid = ai_hoc.tao_id(ten, kh, f[0], sg, "p")
                    ai_hoc.luu_snap(data_dir, sid, {"id": sid, "loai": "P", "ten": ten, "kh": kh, "sg": sg, "t": f[0], "kind": "P", "nhanh": "",
                                                    "score": rp["score"], "tc": rp["tc"], "sl": rp["sl"], "sld": rp["sld"], "sl_lon": rp["sl_lon"]})
                    _ghi_csv(data_dir, [f[0], ten, kh, "P_dangtao", sg, "", round(rp["gia"], 2), round(rp["score"], 1)])
                    ai_sim.cho_theo_doi(st, sid, ten, kh, sg, f[0])
                    if gui(ai_d2.push_p(ten, kh, rp) + ai_hoc.chan_tin(sid, ai_hoc.doc_snap(data_dir, sid)), ai_hoc.ban_phim(sid)):
                        n += 1
                    log("AI %s %s P dang tao %s %.1fd" % (ten, kh, "BUY" if sg > 0 else "SELL", rp["score"]))
                    break
    return n


def mo_ta(files_dir, data_dir):
    """Cho lenh ai_thu: AI dang thay gi."""
    luat = tai_luat(data_dir)
    out = ["LUAT: " + json.dumps(luat, ensure_ascii=False)]
    for ten, kh in [(t, k) for t in luat["ten"].split(",") for k in luat["khung"]]:
        r = doc_nen(os.path.join(files_dir, "%s_%s.csv" % (ten, kh)))
        if not r or len(r[1]) < 13:
            out.append("%s %s: chua co du lieu nen" % (ten, kh))
            continue
        t = ai_core.trang_thai(r[1])
        out.append("%s %s: huong=%s so_duong=%d/5 ma9=%s gia=%.2f" % (ten, kh, t["huong"] or "khong", t["m"],
                   ",".join("%.2f" % x for x in t["v"]), r[1][-1]))
    return "\n".join(out)
