# -*- coding: utf-8 -*-
"""HOC 'RAU NEN' (tac gia 28/11/2026) - 2 BAI:
  BAI 1  Lenh BUY : bat RAU DUOI cua nen (nen xanh tao rau duoi).
  BAI 2  Lenh SELL: bat RAU TREN cua nen (guong).
MUC TIEU: loi nhieu gia nhat co the, SL NGAN nhat co the. SL = ngay duoi day rau (rau bi pha = 'khong con la rau' -> SL).
Neu nen co nguy co di NGUOC mau lenh: cat som (chon SL luon) hoac con co hoi thi giu - tham so c duoc HOC.
Hoc tu gia tung giay: (d) xuong duoi gia mo >= d, (b) bat khoi day >= b, (w) day khong bi pha w giay -> 'rau xong' -> VAO ngay (gia thap, gan day).
Kiem thu qua khu (70%) roi thu tren du lieu SAU (30%) de khong hoc vet. Chi nghien cuu/gia lap - khong giao dich that."""
import json, os, statistics, time
import ai_tick

LUOI_D = (0.0, 0.2, 0.4)           # xuong duoi open >= d * u   (u = bien do M1 trung vi)
LUOI_B = (0.08, 0.15, 0.25)        # bat khoi day >= b * u
LUOI_W = (0, 3, 8)                 # day khong bi pha w giay
LUOI_C = (0.6, 1.0)                # cat som khi lo >= c * rui ro (1.0 = cho cham SL)
PAD = 0.08                         # dem SL duoi day rau (x u)
HORIZON = 120                      # giay theo doi sau khi vao
TOI_DA_NEN = 1500


TOI_THIEU_TICK = 12      # moi nen can >= 12 tick (vong lap lay mau ~1-2 giay/lan)


def nen_idx(ticks, sec=60, toi_thieu=TOI_THIEU_TICK):
    """-> [(t0, i0, i1)] khoang chi so tick cua cac nen du tick."""
    out = []; i = 0; n = len(ticks)
    while i < n:
        t0 = ticks[i][0] - ticks[i][0] % sec; j = i
        while j < n and ticks[j][0] < t0 + sec:
            j += 1
        if j - i >= toi_thieu:
            out.append((t0, i, j))
        i = j
    return out


def trich(path, sg):
    """Dac trung RAU cua 1 nen (sg=+1 rau DUOI, sg=-1 rau TREN). path = [(dt,bid)]."""
    p = [(dt, sg * b) for dt, b in path]
    o = p[0][1]; c = p[-1][1]
    i_low = min(range(len(p)), key=lambda i: p[i][1]); low = p[i_low][1]; t_low = p[i_low][0]
    wick = min(o, c) - low
    if wick <= 0:
        return None
    rec = next((dt - t_low for dt, b in p[i_low:] if b >= low + 0.5 * wick), None)
    truoc = [b for dt, b in p if t_low - 5 <= dt <= t_low]; sau = [b for dt, b in p if t_low <= dt <= t_low + 5]
    return {"rau": wick, "than": abs(c - o), "dung_mau": c > o, "t_day": t_low, "hoi50_s": rec,
            "thu_lai_day": sum(1 for dt, b in p[i_low + 1:] if b <= low + 0.15 * wick),
            "toc_do_truoc": (truoc[-1] - truoc[0]) / max(1, len(truoc)) if len(truoc) > 1 else 0.0,
            "toc_do_sau": (sau[-1] - sau[0]) / max(1, len(sau)) if len(sau) > 1 else 0.0}


def mo_phong(ticks, i0, i1, sg, u, d, b, w, c, G, pad=PAD, horizon=HORIZON):
    """Bat rau trong nen [i0,i1) roi quan ly: SL ngay duoi day, doi SL duong khi qua gia mo, cat som theo c.
    -> dict hoac None (khong co trigger)."""
    o = sg * ticks[i0][1]; low = None; t_low = 0; k = -1
    for i in range(i0, i1):
        ts, bid = ticks[i]; x = sg * bid
        if low is None or x < low:
            low = x; t_low = ts
        if low <= o - d * u and x - low >= b * u and ts - t_low >= w:
            k = i; break
    if k < 0:
        return None
    return quan_ly(ticks, k, sg, u, low, o, c, pad, horizon)


def quan_ly(ticks, k, sg, u, low, o, c, pad=PAD, horizon=HORIZON):
    """Vao o tick k (khung BUY: low = day rau hien tai, o = gia mo nen). SL ngay duoi day; doi SL duong khi qua gia mo; cat som theo c."""
    entry = sg * ticks[k][1]; sl = low - pad * u; risk = entry - sl
    if risk <= 0:
        return None
    sl0 = sl; be = False; ket = "het gio"; thoat = None; ts_k = ticks[k][0]; pha = False
    for i in range(k + 1, len(ticks)):
        ts, bid = ticks[i]
        if ts - ts_k > horizon:
            break
        x = sg * bid
        if x < low - 1e-12:
            pha = True                                 # day rau bi pha -> khong con la rau
        if x <= sl:
            thoat = sl; ket = "SL duong" if sl >= entry else "SL"; break
        if x <= entry - c * risk and c < 1.0:
            thoat = x; ket = "cat som"; break
        if not be and x >= o and x > entry:
            be = True; sl = max(sl, entry + 0.05 * u)
        thoat = x
    if thoat is None:
        thoat = entry
    return {"entry": entry, "sl": sl0, "risk": risk, "pnl": thoat - entry, "ket": ket, "pha_day": pha, "k": k}


def hoc_mot_chieu(ticks, sg, G, min_mau=30):
    nen = nen_idx(ticks)[-TOI_DA_NEN:]
    if len(nen) < 120:
        return None
    rng = []
    for t0, i0, i1 in nen:
        v = [x[1] for x in ticks[i0:i1]]; rng.append(max(v) - min(v))
    u = statistics.median(rng) or G
    cut = int(len(nen) * 0.7); train, test = nen[:cut], nen[cut:]
    feats = [f for f in (trich([(ticks[j][0] - t0, ticks[j][1]) for j in range(i0, i1)], sg) for t0, i0, i1 in nen) if f]

    def diem(ds, d, b, w, c):
        rs = [r for r in (mo_phong(ticks, i0, i1, sg, u, d, b, w, c, G) for t0, i0, i1 in ds) if r]
        if len(rs) < min_mau:
            return None
        pnl = [r["pnl"] / G for r in rs]; rk = [r["risk"] / G for r in rs]
        return {"n": len(rs), "loi_tb": sum(pnl) / len(pnl), "sl_tb": sum(rk) / len(rk), "thang": sum(1 for x in pnl if x > 0) / len(pnl),
                "pha_day": sum(1 for r in rs if r["pha_day"]) / len(rs), "diem": sum(pnl) / len(pnl) - 0.5 * sum(rk) / len(rk)}
    best = None
    for d in LUOI_D:
        for b in LUOI_B:
            for w in LUOI_W:
                for c in LUOI_C:
                    s = diem(train, d, b, w, c)
                    if s and (best is None or s["diem"] > best[1]["diem"]):
                        best = ((d, b, w, c), s)
    if not best:
        return {"u": u, "nen": len(nen), "ly_do": "chua du mau trigger (>= %d)" % min_mau}
    (d, b, w, c), s_tr = best
    return {"u": u, "nen": len(nen), "d": d, "b": b, "w": w, "c": c, "train": s_tr, "test": diem(test, d, b, w, c),
            "rau_trung_vi": statistics.median([f["rau"] for f in feats]) / G if feats else 0,
            "t_day_trung_vi": statistics.median([f["t_day"] for f in feats]) if feats else 0,
            "ti_le_dung_mau": sum(1 for f in feats if f["dung_mau"]) / max(1, len(feats))}


def chay_hoc(data_dir, ten, G):
    """2 bai: BUY (rau duoi) va SELL (rau tren). Ghi data/dau_nen_hoc_<ten>.json (ten file giu cho tuong thich)."""
    ticks = ai_tick.doc_het(data_dir, ten)
    out = {"t": int(time.time()), "ticks": len(ticks)}
    for sg, nm in ((1, "BUY"), (-1, "SELL")):
        out[nm] = hoc_mot_chieu(ticks, sg, G)
    with open(os.path.join(data_dir, "dau_nen_hoc_%s.json" % ten), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    return out


def bao_cao(data_dir, ten):
    try:
        d = json.load(open(os.path.join(data_dir, "dau_nen_hoc_%s.json" % ten), encoding="utf-8"))
    except Exception:
        return "Chưa có dữ liệu học râu nến cho %s (cần vài giờ giá từng giây)." % ten
    o = ["🕯 Học RÂU NẾN %s – %d giá từng giây đã lưu" % (ten, d["ticks"])]
    for nm, ten_bai in (("BUY", "BÀI 1 · BUY bắt RÂU DƯỚI"), ("SELL", "BÀI 2 · SELL bắt RÂU TRÊN")):
        h = d.get(nm)
        o.append("— " + ten_bai)
        if not h:
            o.append("   chưa đủ nến (cần ≥120 nến có giá đủ)"); continue
        if "d" not in h:
            o.append("   " + h.get("ly_do", "")); continue
        t = h["test"]
        o.append("   Râu trung vị %.2f giá, đáy tạo ở ~giây %d, %.0f%% nến có râu là đúng màu lệnh" % (h["rau_trung_vi"], h["t_day_trung_vi"], h["ti_le_dung_mau"] * 100))
        o.append("   Bộ bắt tốt nhất: xuống ≥%.2fu dưới open · bật ≥%.2fu khỏi đáy · đáy giữ %ds · cắt sớm khi lỗ ≥%.0f%% SL" % (h["d"], h["b"], h["w"], h["c"] * 100))
        o.append("   Học (quá khứ): %d lệnh · lãi TB %+.2f giá · SL TB %.2f giá · thắng %.0f%% · râu bị phá %.0f%%" % (
            h["train"]["n"], h["train"]["loi_tb"], h["train"]["sl_tb"], h["train"]["thang"] * 100, h["train"]["pha_day"] * 100))
        o.append("   Thử (dữ liệu sau): " + (("%d lệnh · lãi TB %+.2f giá · SL TB %.2f giá · thắng %.0f%% · râu bị phá %.0f%%" % (
            t["n"], t["loi_tb"], t["sl_tb"], t["thang"] * 100, t["pha_day"] * 100)) if t else "chưa đủ mẫu"))
    return "\n".join(o)
