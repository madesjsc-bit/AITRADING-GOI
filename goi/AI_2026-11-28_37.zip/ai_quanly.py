# -*- coding: utf-8 -*-
"""KICH BAN QUAN LY LENH cho tung kieu vao (A / P / suyt P) sau khi VAO LENH LOI GIA (bat rau nen) - tac gia 28/11:
Uu tien CAN BANG: keo SL DUONG (bao toan von) va NUOI TP XA (an song tot), RUI RO IT NHAT. Khi vao: tap trung xem gia chay de keo SL duong;
sau khi SL duong thi nuoi thoai mai hon (trail rong hon).
Chinh sach tham so: be (keo SL ve hoa von khi lai >= be x R), khoa (lai toi thieu giu khi hoa von = khoa x R), trail (khoang trail sau hoa von = trail x R), tp (chot xa = tp x R hoac khong).
R = khoang cach vao -> SL ban dau (SL sat day rau). AI thu luoi chinh sach tren cac lenh gia lap, kiem thu quá khu -> du lieu sau, chon chinh sach tot nhat cho tung (ma, kieu vao). Chi gia lap."""
import json, os, time
import ai_tick, ai_hocnen, ai_tiendo, ai_bai2

LUOI_BE = (0.5, 0.8, 1.2)
LUOI_KHOA = (0.0, 0.15, 0.3)
LUOI_TRAIL = (0.8, 1.5, 2.5)
LUOI_TP = (0.0, 3.0, 6.0)         # 0 = khong chot, chi trail
HORIZON = 1800
MIN_MAU = 25


def mo_phong(ticks, k, sg, entry, sl, cs, horizon=HORIZON):
    """entry, sl o khung BUY (da nhan sg). cs = (be, khoa, trail, tp). -> dict."""
    be_r, khoa, trail, tp = cs
    R = entry - sl
    if R <= 0:
        return None
    x_sl = sl; be = False; peak = entry; ts0 = ticks[k][0]; mfe = 0.0; mae = 0.0; ket = "het gio"; thoat = None
    for i in range(k + 1, len(ticks)):
        if ticks[i][0] - ts0 > horizon:
            break
        x = sg * ticks[i][1]
        mfe = max(mfe, x - entry); mae = min(mae, x - entry)
        if x <= x_sl:
            thoat = x_sl; ket = "SL duong" if x_sl >= entry else "SL"; break
        peak = max(peak, x)
        if tp > 0 and x >= entry + tp * R:
            thoat = entry + tp * R; ket = "TP"; break
        if not be and x >= entry + be_r * R:
            be = True; x_sl = max(x_sl, entry + khoa * R)
        if be:
            x_sl = max(x_sl, peak - trail * R, entry + khoa * R)
        thoat = x
    if thoat is None:
        thoat = entry
    return {"r": (thoat - entry) / R, "be": be, "mfe_r": mfe / R, "mae_r": mae / R, "ket": ket}


def lay_vao_lenh(data_dir, ten, G):
    """Cac lenh gia lap: tin hieu A/P/suyt P (chuan + noi long) -> diem vao = bat rau (mo hinh) hoac gia mo nen B. -> [(loai, sg, k, entry_f, sl_f)]"""
    ticks = ai_tick.doc_het(data_dir, ten)
    if len(ticks) < 500:
        return ticks, []
    nen = ai_hocnen.nen_idx(ticks); pos = {t: i for i, (t, _, _) in enumerate(nen)}
    out = []
    for r in ai_bai2.doc_tap(data_dir):
        if r["ten"] != ten:
            continue
        sg = r["sg"]; tb = r["t"] + 60; m = ai_tiendo.tai_model(data_dir, ten, "BUY" if sg > 0 else "SELL"); got = None
        if m:
            for q in range(3):
                i = pos.get(tb + 60 * q)
                if i is not None and i > 30:
                    got = ai_tiendo._thu_nen(ticks, nen, i, sg, G, m)
                    if got:
                        break
        loai = "A" if r["f"][ai_bai2.TEN_F.index("loai")] in (0.0, 1.0) else ("P" if r["f"][ai_bai2.TEN_F.index("loai")] == 2.0 else "suyt P")
        if got and got.get("sl_f") is not None and got["entry_f"] - got["sl_f"] > 0:
            out.append((loai, sg, got["k"], got["entry_f"], got["sl_f"], r["t"]))
    return ticks, out


def hoc(data_dir, ten, G):
    """Tim chinh sach tot nhat cho tung kieu vao. Ghi data/quanly_<ma>.json."""
    ticks, vl = lay_vao_lenh(data_dir, ten, G)
    res = {"t": int(time.time()), "n_vao": len(vl), "kieu": {}}
    for loai in ("A", "P", "suyt P"):
        ls = sorted([x for x in vl if x[0] == loai], key=lambda x: x[5])[-150:]       # 150 lenh gan nhat (nhe CPU)
        if len(ls) < MIN_MAU:
            res["kieu"][loai] = {"n": len(ls), "ly_do": "cần ≥ %d lệnh giả lập (đang %d)" % (MIN_MAU, len(ls))}; continue
        cut = int(len(ls) * 0.7); tr = ls[:cut]; te = ls[cut:]
        def diem(ds, cs):
            rs = [mo_phong(ticks, k, sg, e, sl, cs) for _, sg, k, e, sl, _t in ds]
            rs = [x for x in rs if x]
            if len(rs) < 8:
                return None
            n = len(rs); mr = sum(x["r"] for x in rs) / n; thua = sum(1 for x in rs if x["r"] <= -0.9) / n; be = sum(1 for x in rs if x["be"]) / n
            return {"n": n, "r_tb": mr, "thua_day_sl": thua, "ti_le_sl_duong": be, "mfe_r": sum(x["mfe_r"] for x in rs) / n, "diem": mr - 0.3 * thua}
        best = None
        for b in LUOI_BE:
            for kh in LUOI_KHOA:
                for tr_ in LUOI_TRAIL:
                    for tp in LUOI_TP:
                        d = diem(tr, (b, kh, tr_, tp))
                        if d and (best is None or d["diem"] > best[1]["diem"]):
                            best = ((b, kh, tr_, tp), d)
        if not best:
            res["kieu"][loai] = {"n": len(ls), "ly_do": "chưa đủ mẫu hợp lệ"}; continue
        cs, d_tr = best
        base = diem(te, (1e9, 0.0, 1e9, 0.0)) if te else None     # moc: giu SL goc, khong keo (de so sanh)
        res["kieu"][loai] = {"n": len(ls), "cs": {"be": cs[0], "khoa": cs[1], "trail": cs[2], "tp": cs[3]}, "hoc": d_tr, "thu": diem(te, cs), "moc_khong_keo": base}
    with open(os.path.join(data_dir, "quanly_%s.json" % ten), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    return res


def bao_cao(data_dir, ten):
    try:
        d = json.load(open(os.path.join(data_dir, "quanly_%s.json" % ten), encoding="utf-8"))
    except Exception:
        return "🛠 KỊCH BẢN QUẢN LÝ LỆNH %s: chưa có dữ liệu." % ten
    o = ["🛠 KỊCH BẢN QUẢN LÝ LỆNH %s (sau VÀO LỆNH LỢI GIÁ bằng râu nến · giả lập · R = SL ban đầu sát đáy râu)" % ten]
    for loai, nm in (("A", "Cây A"), ("P", "Cây P"), ("suyt P", "Suýt P")):
        k = d["kieu"].get(loai)
        if not k:
            continue
        if "cs" not in k:
            o.append("   %s: %s" % (nm, k.get("ly_do", ""))); continue
        c = k["cs"]; t = k.get("thu"); m = k.get("moc_khong_keo")
        o.append("   %s (%d lệnh): kéo SL về hòa vốn khi lãi ≥ %.1fR (khóa %.2fR) → trail %.1fR%s" % (
            nm, k["n"], c["be"], c["khoa"], c["trail"], (" · chốt TP %.0fR" % c["tp"]) if c["tp"] else " · không chốt, nuôi theo trail"))
        if t:
            o.append("      Thử (dữ liệu sau): lãi TB %+.2fR · %.0f%% lệnh đã kéo được SL dương · %.0f%% chạm SL gốc · MFE TB %.1fR%s" % (
                t["r_tb"], t["ti_le_sl_duong"] * 100, t["thua_day_sl"] * 100, t["mfe_r"], (" · (không kéo SL: %+.2fR, %.0f%% chạm SL)" % (m["r_tb"], m["thua_day_sl"] * 100)) if m else ""))
    return "\n".join(o)
