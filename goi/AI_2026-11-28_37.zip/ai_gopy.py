# -*- coding: utf-8 -*-
"""TONG HOP DAC DIEM CAY A/P TOT + GOI Y TIEU CHI MOI (tac gia 28/11: 'ngoai nhung tieu chi minh cho, thoai mai bo sung de goi y').
Moi cay A/P da co ket qua (tot = vao xong lai >= $3 tai lot 0.01): so sanh nhom TOT vs XAU tren
 (1) tieu chi cua tac gia (TC1..TC11, diem, loai, nhanh, SL...)  (2) tieu chi MOI AI tu bo sung: gio san, thu trong tuan, bien dong (u gan/xa),
 than/rau cua nen tin hieu, chuoi nen nguoc truoc do, dong luong 3 nen, khoang cach toi dinh/day ngay, so tick.
Xep hang theo AUC + 'nguong tot nhat' (ti le tot o 2 phia). Chi goi y - tac gia duyet moi dua vao luat."""
import json, os, time
import ai_tick, ai_bai2

TEN_MOI = ["gio_san", "thu", "bien_dong_gan_xa", "than_nen_A", "rau_tren_nen_A", "rau_duoi_nen_A", "so_nen_nguoc_truoc", "cu_chay_truoc", "dong_luong_3_nen",
           "xa_dinh_day_ngay", "so_tick_phut"]
NHAN = {"diem": "Điểm tổng MAG", "loai": "Loại (A/suýt A/P)", "nhanh": "Nhánh (thuận/cắt/ngược)", "sl_gia": "SL gợi ý (giá)", "chuan": "Là cây chuẩn MAG",
        "btc": "Là BTC", "gio_san": "GIỜ SÀN (0–23)", "thu": "THỨ trong tuần (0=T2)", "bien_dong_gan_xa": "BIẾN ĐỘNG gần/xa (u30 ÷ u360)",
        "than_nen_A": "THÂN nến tín hiệu (÷u)", "rau_tren_nen_A": "RÂU TRÊN nến tín hiệu (÷u)", "rau_duoi_nen_A": "RÂU DƯỚI nến tín hiệu (÷u)",
        "so_nen_nguoc_truoc": "SỐ NẾN ngược chiều liền trước", "cu_chay_truoc": "CÚ CHẠY trước đó (÷u)", "dong_luong_3_nen": "ĐỘNG LƯỢNG 3 nến (÷u)",
        "xa_dinh_day_ngay": "KHOẢNG CÁCH tới đỉnh/đáy ngày (÷u)", "so_tick_phut": "SỐ TICK trong phút"}
for i in range(1, 12):
    NHAN["TC%d" % i] = "TC%d (tiêu chí MAG)" % i
MOI = set(TEN_MOI)


def them(bars, idx, sg, t, ten_gio_san=0):
    """Tieu chi MOI cho nen tin hieu o chi so idx trong bars M1 [(t,o,h,l,c)] (khung BUY nhan sg)."""
    if idx < 40 or idx >= len(bars):
        return None
    def fr(b):
        return (sg * b[1], sg * (b[2] if sg > 0 else b[3]), sg * (b[3] if sg > 0 else b[2]), sg * b[4])
    rg = [b[2] - b[3] for b in bars[idx - 30:idx]]; rg2 = [b[2] - b[3] for b in bars[max(0, idx - 360):idx]]
    u = sorted(rg)[len(rg) // 2] or 1e-9; u2 = sorted(rg2)[len(rg2) // 2] or 1e-9
    o, h, l, c = fr(bars[idx]); top = max(o, c); bot = min(o, c)
    nguoc = 0; chay = 0.0; q = idx - 1
    while q >= idx - 12 and sg * (bars[q][4] - bars[q][1]) < 0:
        nguoc += 1; chay += abs(bars[q][4] - bars[q][1]); q -= 1
    day = time.gmtime(t + ten_gio_san * 3600).tm_yday; ext = None; j = idx
    while j >= 0 and time.gmtime(bars[j][0] + ten_gio_san * 3600).tm_yday == day:
        e = bars[j][2] if sg > 0 else bars[j][3]
        ext = e if ext is None else (max(ext, e) if sg > 0 else min(ext, e)); j -= 1
    lt = time.gmtime(t + ten_gio_san * 3600)
    return {"gio_san": float(lt.tm_hour), "thu": float(lt.tm_wday), "bien_dong_gan_xa": u / u2, "than_nen_A": (top - bot) / u, "rau_tren_nen_A": (h - top) / u,
            "rau_duoi_nen_A": (bot - l) / u, "so_nen_nguoc_truoc": float(nguoc), "cu_chay_truoc": chay / u,
            "dong_luong_3_nen": sg * (bars[idx][4] - bars[idx - 3][4]) / u, "xa_dinh_day_ngay": abs((ext - bars[idx][4]) if ext is not None else 0.0) / u, "so_tick_phut": 0.0}


def auc(ys, xs):
    pos = [x for y, x in zip(ys, xs) if y]; neg = [x for y, x in zip(ys, xs) if not y]
    if not pos or not neg:
        return 0.5
    z = sorted([(x, 1) for x in pos] + [(x, 0) for x in neg]); i = 0; sr = 0.0
    while i < len(z):
        j = i
        while j < len(z) and z[j][0] == z[i][0]:
            j += 1
        sr += sum(1 for k in range(i, j) if z[k][1]) * (i + j + 1) / 2.0
        i = j
    return (sr - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg))


def tot_nhat(xs, ys, min_n=15):
    """Nguong chia tot nhat: -> (nguong, ti_le_tot_cao, n_cao, ti_le_tot_thap, n_thap) hoac None."""
    best = None; vs = sorted(set(xs))
    if len(vs) < 3:
        return None
    for q in range(1, 10):
        th = sorted(xs)[min(len(xs) - 1, int(len(xs) * q / 10.0))]
        hi = [y for x, y in zip(xs, ys) if x >= th]; lo = [y for x, y in zip(xs, ys) if x < th]
        if len(hi) < min_n or len(lo) < min_n:
            continue
        d = abs(sum(hi) / float(len(hi)) - sum(lo) / float(len(lo)))
        if best is None or d > best[0]:
            best = (d, th, sum(hi) / float(len(hi)), len(hi), sum(lo) / float(len(lo)), len(lo))
    return best[1:] if best else None


def phan_tich(rows, extras):
    """rows: doc_tap(); extras: {(t,ten,sg): dict tieu chi moi}. -> list goi y da xep hang."""
    cot = {}
    for r in rows:
        f = dict(zip(ai_bai2.TEN_F, r["f"]))
        e = extras.get((r["t"], r["ten"], r["sg"]), {})
        for k, v in f.items():
            cot.setdefault(k, []).append((v, r["tot"]))
        for k, v in e.items():
            cot.setdefault(k, []).append((v, r["tot"]))
    out = []
    for k, vs in cot.items():
        if len(vs) < 30 or len({x for x, _ in vs}) < 3 or len({y for _, y in vs}) < 2:
            continue
        xs = [x for x, _ in vs]; ys = [y for _, y in vs]
        a = auc(ys, xs); tn = tot_nhat(xs, ys)
        if tn:
            out.append({"ten": k, "auc": a, "n": len(vs), "moi": k in MOI, "nguong": tn[0], "tot_cao": tn[1], "n_cao": tn[2], "tot_thap": tn[3], "n_thap": tn[4],
                        "hieu_ung": max(abs(a - 0.5), abs(tn[1] - tn[3]) / 2.0)})
    return sorted(out, key=lambda x: -x["hieu_ung"])


def thu_thap_extras(data_dir, rows, G_by_ten, gio_san=0, toi_da=1500):
    ex = {}; cache = {}
    for r in rows[-toi_da:]:
        ten = r["ten"]
        if ten not in cache:
            tk = ai_tick.doc_het(data_dir, ten); b = ai_bai2.bars_tu_tick(tk, 60)
            cache[ten] = (b, {x[0]: i for i, x in enumerate(b)})
        b, pos = cache[ten]
        i = pos.get(r["t"])
        if i is None:
            continue
        d = them(b, i, r["sg"], r["t"], gio_san)
        if d:
            ex[(r["t"], r["ten"], r["sg"])] = d
    return ex


def tim_luat(rows, extras, toi_da_dk=3):
    """BO TIEU CHI TOI UU cua AI: tham lam them toi da 3 dieu kien (>= / <) de tang ti le cay TOT, kiem thu tren du lieu SAU."""
    rows = sorted(rows, key=lambda r: r["t"]); cut = int(len(rows) * 0.7)
    def fv(r):
        d = dict(zip(ai_bai2.TEN_F, r["f"])); d.update(extras.get((r["t"], r["ten"], r["sg"]), {})); return d
    X = [fv(r) for r in rows]; y = [r["tot"] for r in rows]
    tr = list(range(cut)); te = list(range(cut, len(rows)))
    if len(tr) < 80 or len(te) < 20:
        return None
    cands = []
    for k in X[0]:
        vals = sorted(x[k] for x in X if k in x)
        if len(set(vals)) < 3 or len(vals) < len(X) * 0.5:
            continue
        for q in range(2, 9):
            th = vals[min(len(vals) - 1, int(len(vals) * q / 10.0))]
            cands.append((k, th, ">="))
            cands.append((k, th, "<"))
    def ok(i, c):
        v = X[i].get(c[0]); return v is not None and ((v >= c[1]) if c[2] == ">=" else (v < c[1]))
    cur = tr; rule = []; base_tr = sum(y[i] for i in tr) / float(len(tr)); rate = base_tr
    for _ in range(toi_da_dk):
        best = None; need = max(25, int(0.12 * len(tr)))
        for c in cands:
            sub = [i for i in cur if ok(i, c)]
            if len(sub) < need:
                continue
            r_ = sum(y[i] for i in sub) / float(len(sub))
            if r_ > rate + 0.03 and (best is None or r_ > best[0]):
                best = (r_, c, sub)
        if not best:
            break
        rate, c, cur = best; rule.append(c)
    if not rule:
        return {"ly_do": "chưa tìm được điều kiện nào cải thiện rõ"}
    sub_te = [i for i in te if all(ok(i, c) for c in rule)]; base_te = sum(y[i] for i in te) / float(len(te))
    mag = [i for i in te if X[i].get("diem", 0) >= 7.0]
    out = {"rule": [{"tieu_chi": c[0], "nguong": c[1], "dau": c[2]} for c in rule], "hoc": {"n": len(cur), "ti_le_tot": rate, "nen": base_tr},
           "thu": {"n": len(sub_te), "ti_le_tot": (sum(y[i] for i in sub_te) / float(len(sub_te))) if sub_te else None, "nen": base_te},
           "mag_diem_ge7": {"n": len(mag), "ti_le_tot": (sum(y[i] for i in mag) / float(len(mag))) if mag else None}}
    return out


def bao_cao(data_dir, gio_san=0, ten=None):
    rows = [r for r in ai_bai2.doc_tap(data_dir) if not ten or r["ten"] == ten]
    n_t = sum(r["tot"] for r in rows)
    o = ["💡 %sTỔNG HỢP CÂY A/P/SUÝT P TỐT & GỢI Ý TIÊU CHÍ MỚI (tốt = vào xong lãi ≥ $%.0f tại lot %.2f)" % (("%s · " % ten) if ten else "", ai_bai2.NG["loi_usd"], ai_bai2.NG["lot"])]
    if len(rows) < 60 or n_t < 10 or n_t > len(rows) - 10:
        o.append("   Cần thêm dữ liệu: có %d cây có kết quả (%d tốt). Cần ≥ 60 cây, mỗi nhóm tốt/xấu ≥ 10." % (len(rows), n_t))
        return "\n".join(o)
    ex = thu_thap_extras(data_dir, rows, {}, gio_san)
    kq = phan_tich(rows, ex)
    o.append("   %d cây có kết quả · %.0f%% là cây tốt · %d cây có đủ tiêu chí mới" % (len(rows), 100.0 * n_t / len(rows), len(ex)))
    top = [x for x in kq if x["hieu_ung"] >= 0.05][:8]
    if not top:
        o.append("   Chưa tìm thấy tiêu chí nào phân biệt rõ cây tốt/xấu. Cần thêm dữ liệu.")
    for x in top:
        o.append("   %s %s: khi ≥ %.2f → tốt %.0f%% (n=%d) · còn lại tốt %.0f%% (n=%d) · AUC %.2f" % (
            "🆕" if x["moi"] else "•", NHAN.get(x["ten"], x["ten"]), x["nguong"], x["tot_cao"] * 100, x["n_cao"], x["tot_thap"] * 100, x["n_thap"], x["auc"]))
    if top:
        o.append("   🆕 = tiêu chí AI tự bổ sung (không có trong bảng điểm MAG). Em chỉ gợi ý – anh duyệt tiêu chí nào thì đưa vào luật.")
    lu = tim_luat(rows, ex)
    if lu:
        if "rule" in lu:
            tx = " VÀ ".join("%s %s %.2f" % (NHAN.get(c["tieu_chi"], c["tieu_chi"]), c["dau"], c["nguong"]) for c in lu["rule"])
            t = lu["thu"]; m = lu["mag_diem_ge7"]
            o.append("   🎯 BỘ TIÊU CHÍ TỐI ƯU (AI): %s" % tx)
            o.append("      Thử trên dữ liệu SAU: %s · MAG (điểm ≥ 7): %s · nền %.0f%%" % (
                ("tốt %.0f%% (n=%d)" % (t["ti_le_tot"] * 100, t["n"])) if t["ti_le_tot"] is not None else "chưa có cây nào thỏa",
                ("tốt %.0f%% (n=%d)" % (m["ti_le_tot"] * 100, m["n"])) if m["ti_le_tot"] is not None else "chưa có cây nào", t["nen"] * 100))
            try:
                json.dump(lu, open(os.path.join(data_dir, "tieuchi_toiuu%s.json" % (("_" + ten) if ten else "")), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            except OSError:
                pass
        else:
            o.append("   🎯 Bộ tiêu chí tối ưu: " + lu["ly_do"])
    return "\n".join(o)
