# -*- coding: utf-8 -*-
"""AI HOC 'RAU NEN' KHONG DUNG SO CO DINH (tac gia 28/11): moi nen co 1 rau khac nhau -> AI phai TU HOC nhan ra
  (1) rau nay da XONG chua (day da hinh thanh, khong bi pha nua)?   (2) nen nay se XANH/len tiep khong (BUY) - gương cho SELL.
Dac trung 'khong don vi' (chia cho bien do nen gan day u) -> tu thich nghi theo ma/khung/thoi diem.
Mo hinh: tang cuong cay cut (boosted stumps, thuan Python, nhe) - hoc tren QUA KHU, thu tren DU LIEU SAU (AUC, so voi luat co dinh).
Chi nghien cuu/gia lap."""
import json, math, os, statistics, time
import ai_tick, ai_hocnen

TEN_DT = ["sau_duoi_open", "bat_khoi_day", "giay_tu_day", "giay_trong_nen", "ti_le_rau", "thu_lai_day", "toc_do_vao_day",
          "toc_do_sau_day", "vi_tri_so_open", "dinh_truoc_so_open", "ti_le_tick_len", "nen_truoc_mau", "rau_nen_truoc", "bien_do_u_ro",
          "so_nen_nguoc_truoc", "cu_chay_truoc"]
NB = 8
SHIFTS = (0, 10, 20, 30, 40, 50)   # tang cuong: dich moc nen 10 giay (nen khong can thang hang gio) -> ~6 lan mau hoc; danh gia chi tren nen THAT (shift 0)


def _u_truot(ticks, nen, idx, n=30):
    rs = []
    for t0, i0, i1 in nen[max(0, idx - n):idx]:
        v = [x[1] for x in ticks[i0:i1]]
        rs.append(max(v) - min(v))
    return statistics.median(rs) if len(rs) >= 10 else 0.0


def mau_nen(ticks, nen, idx, sg, G, buoc=3, toi_da=20, sec=60):
    """Cac mau (dac trung, nhan) trong nen thu idx. Chi lay luc gia da xuong duoi gia mo (dang co rau)."""
    t0, i0, i1 = nen[idx]
    u = _u_truot(ticks, nen, idx)
    if u <= 0 or i1 - i0 < ai_hocnen.TOI_THIEU_TICK:
        return []
    sec = int(sec)
    xs = [sg * ticks[j][1] for j in range(i0, i1)]; ts = [ticks[j][0] - t0 for j in range(i0, i1)]
    o = xs[0]; close = xs[-1]; n = len(xs)
    suf = [0.0] * n; m = xs[-1]
    for j in range(n - 1, -1, -1):
        m = min(m, xs[j]); suf[j] = m
    # nen truoc
    pt0, pi0, pi1 = nen[idx - 1] if idx > 0 else (None, 0, 0)
    pcol = prau = 0.0
    if idx > 0 and pt0 + sec == t0:
        px = [sg * ticks[j][1] for j in range(pi0, pi1)]
        pcol = (px[-1] - px[0]) / u; prau = (min(px[0], px[-1]) - min(px)) / u
    nguoc = 0; chay = 0.0; q = idx - 1
    while q >= max(0, idx - 12) and nen[q][0] + sec == nen[q + 1][0]:
        a_, b_ = nen[q][1], nen[q][2]
        if sg * (ticks[b_ - 1][1] - ticks[a_][1]) < 0:
            nguoc += 1; chay += abs(ticks[b_ - 1][1] - ticks[a_][1]); q -= 1
        else:
            break
    out = []; low = xs[0]; t_low = 0; hi = xs[0]; ups = []; retest = 0
    for j in range(1, n):
        x = xs[j]; hi = max(hi, x); ups.append(1 if x > xs[j - 1] else 0)
        if x < low:
            low = x; t_low = ts[j]; retest = 0
        elif x <= low + 0.05 * u:
            retest += 1
        if j % buoc or o - low < 0.05 * u:
            continue
        f = [(o - low) / u, (x - low) / u, (ts[j] - t_low) / float(sec), ts[j] / float(sec), (o - low) / max(1e-9, hi - low), retest / 10.0,
             (xs[max(0, j - (ts[j] - t_low) - 5)] - low) / u / 5.0 if ts[j] > t_low else 0.0,
             (x - low) / u / max(1, ts[j] - t_low), (x - o) / u, (hi - o) / u, sum(ups[-10:]) / max(1, len(ups[-10:])), pcol, prau, u / G, nguoc / 12.0, chay / u / 10.0]
        out.append((f, 1 if suf[j] >= low - 1e-12 else 0, 1 if close - x >= 0.15 * u else 0, j))
    if len(out) > toi_da:
        step = len(out) / float(toi_da); out = [out[int(i * step)] for i in range(toi_da)]
    return out


def chia_bin(X, nb=NB):
    nf = len(X[0]); edges = []
    for fi in range(nf):
        col = sorted(r[fi] for r in X)
        edges.append([col[int(len(col) * q / nb)] for q in range(1, nb)])
    return edges


def bin_hoa(x, edges):
    return [sum(1 for e in edges[fi] if x[fi] > e) for fi in range(len(x))]


def tang_cuong(Xb, y, vong=40, lr=0.3):
    N = len(y); nf = len(Xb[0]); F = [0.0] * N; stumps = []; gain_f = [0.0] * nf
    for _ in range(vong):
        p = [1.0 / (1.0 + math.exp(-f)) for f in F]
        g = [yi - pi for yi, pi in zip(y, p)]; h = [pi * (1 - pi) for pi in p]
        best = None
        for fi in range(nf):
            sg_ = [0.0] * NB; sh = [0.0] * NB
            for i in range(N):
                b = Xb[i][fi]; sg_[b] += g[i]; sh[b] += h[i]
            Gt = sum(sg_); Ht = sum(sh); GL = HL = 0.0
            for t in range(NB - 1):
                GL += sg_[t]; HL += sh[t]; GR = Gt - GL; HR = Ht - HL
                gain = GL * GL / (HL + 1) + GR * GR / (HR + 1) - Gt * Gt / (Ht + 1)
                if best is None or gain > best[0]:
                    best = (gain, fi, t, GL / (HL + 1), GR / (HR + 1))
        if best is None:
            break
        gain, fi, t, vl, vr = best; gain_f[fi] += gain
        stumps.append((fi, t, vl * lr, vr * lr))
        for i in range(N):
            F[i] += (vl if Xb[i][fi] <= t else vr) * lr
    return stumps, gain_f


def du_doan(stumps, xb):
    f = sum((vl if xb[fi] <= t else vr) for fi, t, vl, vr in stumps)
    return 1.0 / (1.0 + math.exp(-f))


def auc(ys, ps):
    pos = [p for y, p in zip(ys, ps) if y]; neg = [p for y, p in zip(ys, ps) if not y]
    if not pos or not neg:
        return 0.5
    z = sorted([(p, 1) for p in pos] + [(p, 0) for p in neg]); i = 0; sr = 0.0
    while i < len(z):
        j = i
        while j < len(z) and z[j][0] == z[i][0]:
            j += 1
        for k in range(i, j):
            if z[k][1]:
                sr += (i + j + 1) / 2.0
        i = j
    return (sr - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg))


def hoc(ticks, sg, G, max_mau=9000):
    nen = ai_hocnen.nen_idx(ticks)[-ai_hocnen.TOI_DA_NEN:]
    if len(nen) < 150:
        return None
    cut = int(len(nen) * 0.7)
    def lay(a, b):
        S = []
        for idx in range(a, b):
            for f, yl, yu, j in mau_nen(ticks, nen, idx, sg, G):
                S.append((f, yl, yu, idx, j))
        return S
    tr = lay(30, cut); te = lay(cut, len(nen))
    if len(tr) < 300 or len(te) < 100:
        return {"nen": len(nen), "ly_do": "chua du mau (hoc %d, thu %d)" % (len(tr), len(te))}
    if len(tr) > max_mau:
        st = len(tr) / float(max_mau); tr = [tr[int(i * st)] for i in range(max_mau)]
    edges = chia_bin([s[0] for s in tr]); Xb = [bin_hoa(s[0], edges) for s in tr]; Xt = [bin_hoa(s[0], edges) for s in te]
    res = {"nen": len(nen), "mau_hoc": len(tr), "mau_thu": len(te)}; mo = {}
    for ten, vi in (("rau_xong", 1), ("len_tiep", 2)):
        y = [s[vi] for s in tr]; yt = [s[vi] for s in te]
        stumps, gf = tang_cuong(Xb, y)
        pt = [du_doan(stumps, x) for x in Xt]
        top = sorted(range(len(gf)), key=lambda i: -gf[i])[:3]
        res[ten] = {"auc_thu": auc(yt, pt), "ti_le_duong": sum(yt) / len(yt), "quan_trong": [TEN_DT[i] for i in top if gf[i] > 0]}
        mo[ten] = (stumps, pt)
    # QUYET DINH: vao khi P(rau xong) >= th1 va P(len tiep) >= th2 -> mo phong quan ly that tren cac nen thu
    p1 = mo["rau_xong"][1]; p2 = mo["len_tiep"][1]; best = None
    nen_te = {}
    for (f, yl, yu, idx, j), a, b in zip(te, p1, p2):
        nen_te.setdefault(idx, []).append((j, a, b))
    for th1 in (0.5, 0.65, 0.8):
        for th2 in (0.0, 0.5, 0.6):
            for c in (0.6, 1.0):
                rs = []
                for idx, lst in nen_te.items():
                    trig = next((j for j, a, b in sorted(lst) if a >= th1 and b >= th2), None)
                    if trig is None:
                        continue
                    t0, i0, i1 = nen[idx]; u = _u_truot(ticks, nen, idx)
                    xs = [sg * ticks[q][1] for q in range(i0, i0 + trig + 1)]
                    r = ai_hocnen.quan_ly(ticks, i0 + trig, sg, u, min(xs), xs[0], c)
                    if r:
                        rs.append(r)
                if len(rs) >= 20:
                    pnl = [r["pnl"] / G for r in rs]; rk = [r["risk"] / G for r in rs]
                    sc = sum(pnl) / len(pnl) - 0.5 * sum(rk) / len(rk)
                    if best is None or sc > best["diem"]:
                        best = {"th_rau_xong": th1, "th_len_tiep": th2, "c": c, "n": len(rs), "loi_tb": sum(pnl) / len(pnl), "sl_tb": sum(rk) / len(rk),
                                "thang": sum(1 for x in pnl if x > 0) / len(pnl), "pha_day": sum(1 for r in rs if r["pha_day"]) / len(rs), "diem": sc}
    res["quyet_dinh_thu"] = best
    res["_model"] = {"edges": edges, "rau_xong": mo["rau_xong"][0], "len_tiep": mo["len_tiep"][0],
                     "th1": best["th_rau_xong"] if best else 0.65, "th2": best["th_len_tiep"] if best else 0.5, "c": best["c"] if best else 1.0}
    return res


def hoc_chung(data_dir, mas, Gmap, max_mau=12000):
    """HOC CHUNG (nhanh nhat): moi nen M1/M5/M15 cua moi ma, ca BUY lan SELL (guong) -> 1 mo hinh duy nhat.
    Dac trung khong don vi nen XAU/BTC/khung/chieu dung chung. Khi VAO THAT van bat buoc cay A/P dat chuan."""
    tr_all = []; te_all = []; thong_ke = {}
    for ten in mas:
        ticks0 = ai_tick.doc_het(data_dir, ten)
        for sec in (60, 300, 900):
            for shift in SHIFTS:
                ticks = ticks0 if shift == 0 else [(a + shift, b) for a, b in ticks0]
                nen = ai_hocnen.nen_idx(ticks, sec)[-ai_hocnen.TOI_DA_NEN:]
                if len(nen) < 60:
                    continue
                cut = int(len(nen) * 0.7)
                if shift == 0:
                    thong_ke["%s_M%d" % (ten, sec // 60)] = len(nen)
                for sg in (1, -1):
                    for idx in range(31 if sec == 60 else 11, len(nen)):
                        if idx >= cut and shift != 0:
                            continue            # thu chi tren nen THAT
                        for f, yl, yu, j in mau_nen(ticks, nen, idx, sg, Gmap.get(ten, 1.0), sec=sec):
                            (tr_all if idx < cut else te_all).append((f, yl, yu, ten, sec, sg))
    if len(tr_all) < 400 or len(te_all) < 150:
        return {"ly_do": "chua du mau (hoc %d, thu %d)" % (len(tr_all), len(te_all)), "nen": thong_ke}
    if len(tr_all) > max_mau:
        st = len(tr_all) / float(max_mau); tr_all = [tr_all[int(i * st)] for i in range(max_mau)]
    edges = chia_bin([x[0] for x in tr_all]); Xb = [bin_hoa(x[0], edges) for x in tr_all]; Xt = [bin_hoa(x[0], edges) for x in te_all]
    res = {"nen": thong_ke, "mau_hoc": len(tr_all), "mau_thu": len(te_all), "auc": {}}; stu = {}
    for ten_nh, vi in (("rau_xong", 1), ("len_tiep", 2)):
        y = [x[vi] for x in tr_all]; yt = [x[vi] for x in te_all]
        sk, gf = tang_cuong(Xb, y); stu[ten_nh] = sk
        pt = [du_doan(sk, x) for x in Xt]
        res["auc"][ten_nh] = {"tong": auc(yt, pt), "quan_trong": [TEN_DT[i] for i in sorted(range(len(gf)), key=lambda i: -gf[i])[:3] if gf[i] > 0]}
        for key in {(x[3], x[4], x[5]) for x in te_all}:
            idxs = [i for i, x in enumerate(te_all) if (x[3], x[4], x[5]) == key]
            if len(idxs) > 80:
                res["auc"][ten_nh]["%s_M%d_%s" % (key[0], key[1] // 60, "BUY" if key[2] > 0 else "SELL")] = auc([yt[i] for i in idxs], [pt[i] for i in idxs])
    sfx = ("_" + mas[0]) if len(mas) == 1 else ""      # 1 ma = mo hinh DOC LAP cho ma do
    with open(os.path.join(data_dir, "rau_model_chung%s.json" % sfx), "w", encoding="utf-8") as f:
        json.dump({"edges": edges, "rau_xong": stu["rau_xong"], "len_tiep": stu["len_tiep"], "th1": 0.65, "th2": 0.5, "c": 1.0}, f)
    with open(os.path.join(data_dir, "rau_ai_chung%s.json" % sfx), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    return res


def bao_cao_chung(data_dir, ten=None):
    try:
        d = json.load(open(os.path.join(data_dir, "rau_ai_chung%s.json" % (("_" + ten) if ten else "")), encoding="utf-8"))
    except Exception:
        return "Chưa có kết quả học CHUNG."
    if "auc" not in d:
        return "Học CHUNG: " + d.get("ly_do", "")
    nen = d["nen"]
    return "\n".join(["🌐 HỌC mọi nến %s (M1/M5 chính · M15 theo dõi · BUY+SELL gương): %d mẫu học, %d mẫu thử" % (ten or "XAU+BTC", d["mau_hoc"], d["mau_thu"]),
                      "   Số nến: " + " · ".join("%s %d" % kv for kv in sorted(nen.items())),
                      "   'Râu đã xong' AUC %.2f · 'giá đi tiếp đúng chiều' AUC %.2f (0.5 = đoán mò)" % (d["auc"]["rau_xong"]["tong"], d["auc"]["len_tiep"]["tong"]),
                      "   Quan trọng nhất: " + ", ".join(d["auc"]["rau_xong"]["quan_trong"])])


def chay_hoc(data_dir, ten, G):
    ticks = ai_tick.doc_het(data_dir, ten); out = {"t": int(time.time()), "ticks": len(ticks)}
    for sg, nm in ((1, "BUY"), (-1, "SELL")):
        h = hoc(ticks, sg, G)
        if h and "_model" in h:
            with open(os.path.join(data_dir, "rau_model_%s_%s.json" % (ten, nm)), "w", encoding="utf-8") as f:
                json.dump(h.pop("_model"), f)
        out[nm] = h
    with open(os.path.join(data_dir, "rau_ai_%s.json" % ten), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    return out


def bao_cao(data_dir, ten):
    try:
        d = json.load(open(os.path.join(data_dir, "rau_ai_%s.json" % ten), encoding="utf-8"))
    except Exception:
        return "Chưa có kết quả AI học râu cho %s." % ten
    o = ["🧠 AI TỰ HỌC râu nến %s (không dùng số cố định) – %d giá từng giây" % (ten, d["ticks"])]
    for nm, bai in (("BUY", "BÀI 1 · BUY – râu dưới"), ("SELL", "BÀI 2 · SELL – râu trên")):
        h = d.get(nm); o.append("— " + bai)
        if not h:
            o.append("   chưa đủ nến"); continue
        if "rau_xong" not in h:
            o.append("   " + h.get("ly_do", "")); continue
        a, b = h["rau_xong"], h["len_tiep"]
        o.append("   Nhận ra 'râu đã xong': AUC %.2f (0.5 = đoán mò, 1 = hoàn hảo) · quan trọng: %s" % (a["auc_thu"], ", ".join(a["quan_trong"]) or "-"))
        o.append("   Đoán 'giá lên tiếp (BUY)/xuống tiếp (SELL)': AUC %.2f · quan trọng: %s" % (b["auc_thu"], ", ".join(b["quan_trong"]) or "-"))
        q = h.get("quyet_dinh_thu")
        o.append("   Vào theo AI (dữ liệu sau): " + (("%d lệnh · lãi TB %+.2f giá · SL TB %.2f giá · thắng %.0f%% · râu bị phá %.0f%% (ngưỡng râu xong ≥%.0f%%, cắt sớm %.0f%% SL)" % (
            q["n"], q["loi_tb"], q["sl_tb"], q["thang"] * 100, q["pha_day"] * 100, q["th_rau_xong"] * 100, q["c"] * 100)) if q else "chưa đủ lệnh để kết luận"))
    return "\n".join(o)
