# -*- coding: utf-8 -*-
"""BOT AI v0 (chi bao): doc nen XAU do MT5 cua AI xuat ra (AI_DATA.mq5), nhan biet "day mo rong", bao Telegram.
Luat nam trong data/luat_ai.json (tac gia day dan dan, Claude cap nhat bang lenh `luat`). CHUA hoc may."""
import os, json, csv, time
import ai_core

MAC_DINH = {"khung": ["M1", "M5"], "so_duong_bao": 3, "chong_lap_giay": 60, "bao_dong": True, "ten": "XAU"}
CHO_PHEP = {"khung": list, "so_duong_bao": int, "chong_lap_giay": int, "bao_dong": bool, "ten": str}


def tai_luat(data_dir):
    luat = dict(MAC_DINH)
    try:
        with open(os.path.join(data_dir, "luat_ai.json"), encoding="utf-8") as f:
            for k, v in json.load(f).items():
                if k in CHO_PHEP:
                    luat[k] = v
    except Exception:
        pass
    return luat


def sua_luat(data_dir, kv):
    """kv: dict chuoi. Chi nhan khoa trong danh sach cho phep. Tra ve (ok, thong bao)."""
    luat = tai_luat(data_dir)
    for k, v in kv.items():
        if k not in CHO_PHEP:
            return False, "khoa khong hop le: %s (duoc: %s)" % (k, ", ".join(sorted(CHO_PHEP)))
        try:
            if k == "khung":
                luat[k] = [x for x in v.replace(" ", "").split(",") if x in ("M1", "M5", "M15", "H1")]
                if not luat[k]:
                    return False, "khung phai trong M1,M5,M15,H1"
            elif k == "so_duong_bao":
                luat[k] = max(2, min(5, int(v)))
            elif k == "chong_lap_giay":
                luat[k] = max(0, min(3600, int(v)))
            elif k == "bao_dong":
                luat[k] = v.lower() in ("1", "true", "on", "co")
            else:
                luat[k] = ",".join(x for x in v.upper().replace(" ", "").split(",") if x in ("XAU", "BTC")) or "XAU"
        except ValueError:
            return False, "gia tri khong hop le cho %s" % k
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "luat_ai.json"), "w", encoding="utf-8") as f:
        json.dump(luat, f, ensure_ascii=False, indent=1)
    return True, json.dumps(luat, ensure_ascii=False)


def doc_nen(path, toida=60):
    """CSV: time,open,high,low,close,tickvol (nen DA DONG). -> (times, closes) hoac None."""
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            rows = [l.strip().split(",") for l in f.read().splitlines()[-toida:] if l.strip()]
        rows = [r for r in rows if len(r) >= 5 and r[0].isdigit()]
        return [int(r[0]) for r in rows], [float(r[4]) for r in rows]
    except Exception:
        return None


def chay(files_dir, data_dir, st, gui, log):
    """Goi dinh ky. gui(text) -> gui Telegram. Tra ve so tin da gui."""
    luat = tai_luat(data_dir)
    ai = st.setdefault("ai", {})
    da_gui = 0
    for ten, kh in [(t, k) for t in luat["ten"].split(",") for k in luat["khung"]]:
        r = doc_nen(os.path.join(files_dir, "%s_%s.csv" % (ten, kh)))
        if not r or len(r[1]) < 13:
            continue
        times, closes = r
        key = kh if ten == "XAU" else "%s_%s" % (ten, kh)   # XAU giu khoa cu
        s = ai.get(key)
        if s and s.get("t") == times[-1]:
            continue  # chua co nen dong moi
        nay = ai_core.trang_thai(closes)
        if s is None:  # lan dau: chi ghi nhan
            ai[key] = {"t": times[-1], "huong": nay["huong"], "m": nay["m"], "gui": 0}
            continue
        ev = ai_core.su_kien({"huong": s["huong"], "m": s["m"]}, nay, luat["so_duong_bao"])
        s.update({"t": times[-1], "huong": nay["huong"], "m": nay["m"]})
        if ev == "dong" and not luat["bao_dong"]:
            ev = ""
        if ev:
            try:
                os.makedirs(data_dir, exist_ok=True)
                with open(os.path.join(data_dir, "ai_phathien.csv"), "a", encoding="utf-8", newline="") as f:
                    csv.writer(f).writerow([times[-1], ten, kh, ev, nay["huong"], nay["m"], closes[-1]])
            except OSError:
                pass
            if time.time() - s.get("gui", 0) >= luat["chong_lap_giay"]:
                if gui(ai_core.van_ban(ten, kh, ev, nay, "%.2f" % closes[-1])):
                    s["gui"] = time.time()
                    da_gui += 1
                log("AI %s %s %s m=%d" % (ten, kh, ev, nay["m"]))
    return da_gui


def mo_ta(files_dir, data_dir):
    """Cho lenh ai_thu: AI dang thay gi."""
    luat = tai_luat(data_dir)
    out = ["LUAT: " + json.dumps(luat, ensure_ascii=False)]
    for ten, kh in [(t, k) for t in luat["ten"].split(",") for k in luat["khung"]]:
        r = doc_nen(os.path.join(files_dir, "%s_%s.csv" % (ten, kh)))
        if not r or len(r[1]) < 13:
            out.append("%s %s: chua co du lieu nen" % (ten, kh))
            continue
        t = ai_core.trang_thai(r[1])
        out.append("%s %s: huong=%s so_duong=%d/5 ma9=%s gia=%.2f" % (ten, kh, t["huong"] or "khong", t["m"],
                   ",".join("%.2f" % x for x in t["v"]), r[1][-1]))
    return "\n".join(out)
