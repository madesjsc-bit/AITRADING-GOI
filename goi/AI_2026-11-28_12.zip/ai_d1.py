# -*- coding: utf-8 -*-
"""HOC TU MAG: Đ1 - CAY A / SUYT A (port tu MQL5/Experts/FD14/D14.mqh: X14Tree, X14Run, X14Split, EvalD1 - ban 1.4).
Chi dung nen DA DONG. sg = chieu LENH (BUY=+1, SELL=-1); chuoi chay NGUOC chieu lenh.
Chi nhan biet + tinh SL/nhanh (CHUA cham diem TC1-TC8 - lam o buoc sau). Khong co phan giao dich."""

# Mac dinh = input MAG (Inputs.mqh): #20 #22 #23 #24 #25 #26 #38 #75-78 #86. G = 1 "gia": XAU 1 USD, BTC 30 USD.
PARAMS = {"ChainD1": 3, "MaxBuf": 2, "Depth": 2.0, "RevDist": 2.0, "SLPad": 0.3, "BlockTh": 2.0, "MaxSL": 3.0,
          "W3": 0.4, "W4": 0.6, "W5": 0.8, "A8": 1.5, "Leak": 0.1}
G_TAISAN = {"XAU": 1.0, "BTC": 30.0}
KHUNG_GIAY = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400}
NEXT = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]
LE = 40  # le du lieu cuoi mang (MAG dung 320 cho EMA50; AI co ~400 nen)


class SR:
    """Chuoi nen KIEU MQL (chi so 0 = moi nhat). Chi so 0 = nen dang chay GIA LAP (open = close nen dong cuoi)."""
    def __init__(self, bars, G, forming=None, tf="M1", htf=None):
        # bars: [(t, o, h, l, c), ...] cu -> moi, toan nen DA DONG; forming = nen DANG CHAY that (chi so 0)
        # htf: {"M5": [(t,o,h,l,c)...], ...} nen khung lon (chi can nen co t < nen A)
        self.tf = tf; self.htf = htf or {}
        last = bars[-1][4]
        f0 = forming if forming else (bars[-1][0] + KHUNG_GIAY.get(tf, 60), last, last, last, last)
        ser = [f0] + list(reversed(bars))
        self.t = [b[0] for b in ser]; self.o = [b[1] for b in ser]
        self.h = [b[2] for b in ser]; self.l = [b[3] for b in ser]; self.c = [b[4] for b in ser]
        self.n = len(ser); self.G = G
        c = self.c
        self.lw = [None] * self.n
        for i in range(self.n - 8):
            self.lw[i] = sum((9 - q) * c[i + q] for q in range(9)) / 45.0
        chrono = list(reversed(c)); v = chrono[0]; out = []
        for x in chrono:
            v = v + (2.0 / 51.0) * (x - v); out.append(v)
        self.e = list(reversed(out))


def col(s, i):
    d = s.c[i] - s.o[i]
    return 1 if d > 0 else (-1 if d < 0 else 0)


def close_below(s, j, sg):
    return sg * (s.c[j] - s.lw[j]) <= 0


def dt(s, x, bd, m):
    if x < 0 or x + m + 1 >= s.n or s.lw[x + m] is None:
        return False
    return all(bd * (s.lw[x + k] - s.lw[x + k + 1]) > 0 for k in range(m))


def w(s, x, bd, m):
    return bd * (s.lw[x] - s.lw[x + m - 1])


def tree(s, x, sg):
    """1 = A, 2 = suyt A xanh, 3 = suyt A do, 0 = khong."""
    if x < 1 or x + 12 >= s.n or s.lw[x + 4] is None:
        return 0
    cl = col(s, x)
    c4 = sg * (s.c[x] - s.lw[x + 4]); c3 = sg * (s.c[x] - s.lw[x + 3])
    b_ok = sg * (s.o[x - 1] - s.lw[x + 3]) > 0
    if cl == sg and c4 >= 0:
        return 1
    if cl == sg and c3 > 0 and b_ok:
        return 2
    if cl == -sg and c4 >= 0 and b_ok:
        return 3
    return 0


def run(s, ce, cp, sg, P):
    cnt = 0; G = s.G
    for x in range(cp, ce - 1, -1):
        p = cnt + 1
        if p == 1:
            cnt = 1
            continue
        m = min(5, p + 1)
        thr = (P["W3"] if m == 3 else (P["W4"] if m == 4 else P["W5"])) * G
        if dt(s, x, -sg, m) and w(s, x, -sg, m) >= thr:
            cnt += 1
        else:
            cnt = 1
    return cnt


def split(s, a, sg, k, P):
    """-> (ly_do_loi_hoac_'', ce, cs, good, leak)"""
    G = s.G; good = 0; leak = -1
    for j in range(a + 1, a + k + 1):
        if j >= s.n - LE:
            return "thieu du lieu", -1, -1, 0, -1
        if tree(s, j, sg) != 0:
            return "nen dem %d da la cay A / suyt A" % (j - a), -1, -1, 0, -1
        if col(s, j) == sg:
            good += 1
    if k >= 2:
        b1 = a + k
        if sg * (s.c[b1] - s.lw[b1 + 2]) > 0:
            for x in range(b1 - 1, a, -1):
                if sg * (s.c[x] - s.o[b1]) < 0:
                    return "nen dem dong vuot open dem 1", -1, -1, 0, -1
    ce = a + k + 1
    if ce >= s.n - LE:
        return "thieu du lieu", -1, -1, 0, -1
    if not close_below(s, ce, sg):
        return "nen sat A khong phai nen chuoi", -1, -1, 0, -1
    x = ce + 1
    while x < s.n - LE and x - ce < 200:
        if close_below(s, x, sg):
            x += 1
            continue
        if leak < 0 and sg * (s.c[x] - s.lw[x]) <= P["Leak"] * G and x + 1 < s.n - LE and close_below(s, x + 1, sg):
            leak = x
            x += 1
            continue
        break
    cp = x - 1; lp = cp - ce + 1
    if lp < P["ChainD1"]:
        return "chuoi gia %d nen (can >= %d)" % (lp, P["ChainD1"]), -1, -1, 0, -1
    ln = run(s, ce, cp, sg, P); cs = ce + ln - 1
    if leak >= 0 and leak >= cs:
        if leak == cs:
            cs -= 1
        leak = -1
    ln = cs - ce + 1
    if ln < P["ChainD1"]:
        return "chuoi %d nen co dai hop le (can >= %d)" % (max(ln, 0), P["ChainD1"]), -1, -1, 0, -1
    w5 = w(s, ce, -sg, 5)
    if w5 < P["A8"] * G:
        return "A8: dai 5 duong cuoi chuoi %.2f (can >= %.2f)" % (w5 / G, P["A8"]), -1, -1, 0, -1
    depth = sg * (s.o[cs] - s.o[ce])
    if depth < P["Depth"] * G:
        return "do sau chuoi %.2f (can >= %.2f)" % (depth / G, P["Depth"]), -1, -1, 0, -1
    return "", ce, cs, good, leak


def eval_d1(s, a, sg, P=None, pot=False):
    """-> dict ket qua (ok True/False + ly do). a = chi so nen A (1 = nen dong gan nhat; pot=True: a=0 nen DANG CHAY)."""
    P = P or PARAMS; G = s.G
    r = {"ok": False, "sg": sg, "a": a}
    if a < (0 if pot else 1) or a + 15 + LE >= s.n:
        r["why"] = "thieu du lieu"; return r
    if pot:
        cl = col(s, a); typ = 0
        if cl == sg and sg * (s.c[a] - s.lw[a + 3]) > 0:
            typ = 1 if sg * (s.c[a] - s.lw[a + 4]) >= 0 else 2
        elif cl == -sg and sg * (s.c[a] - s.lw[a + 4]) >= 0:
            typ = 3
    else:
        typ = tree(s, a, sg)
    if typ == 0:
        r["why"] = "khong phai nen A / suyt A"; return r
    r["kind"] = {1: "A", 2: "suyt A", 3: "suyt A do"}[typ]
    tried = []; got = None
    for k in range(P["MaxBuf"] + 1):
        why, ce, cs, good, leak = split(s, a, sg, k, P)
        if why == "":
            got = (k, ce, cs, good, leak); break
        tried.append("%d dem: %s" % (k, why))
    if got is None:
        r["why"] = "chuoi/dem khong hop le - " + " | ".join(tried); return r
    nb, ce, cs, good, leak = got
    E = s.e[a]
    ext = min(s.lw[q] for q in range(a, min(cs + 4, s.n - 9) + 1)) if sg > 0 else max(s.lw[q] for q in range(a, min(cs + 4, s.n - 9) + 1))
    if sg * (s.o[a] - E) >= 0:
        br = "THUAN"; SL = ext - sg * P["SLPad"] * G
    elif sg * (s.c[a] - E) > 0:
        br = "CAT"; SL = E - sg * P["SLPad"] * G
    else:
        d = sg * (E - s.c[a])
        if d < P["RevDist"] * G:
            r["why"] = "nhanh nguoc: closeA cach E50 %.2f < %.2f" % (d / G, P["RevDist"]); return r
        br = "NGUOC"; SL = ext - sg * P["SLPad"] * G
    sld = sg * (s.c[a] - SL)
    if sld <= 0:
        r["why"] = "SL khong hop le"; return r
    r.update(ok=True, nb=nb, ce=ce, cs=cs, len=cs - ce + 1, leak=leak >= 0, nhanh=br, sl=SL, sld=sld,
             block=2 if sld >= P["BlockTh"] * G else 1, sl_lon=sld > P["MaxSL"] * G,
             a8=w(s, ce, -sg, 5) / G, depth=sg * (s.o[cs] - s.o[ce]) / G, t=s.t[a], gia=s.c[a], key=s.t[cs],
             good=good)
    cham_diem_d1(s, r, a, sg, ce, cs, nb, good, leak >= 0, P)
    return r


# ---------------- CHAM DIEM Đ1 (port X14ScoreD1: TC1-TC8) ----------------
SLOPE_MIN = 1.5      # #28
SLOPE_MAX = 4.0      # #73
TREND_BARS = 15      # #27
D1_MIN = 5.0         # #10


def lin(x, x0, v0, x1, v1):
    if x1 == x0:
        return v1
    t = max(0.0, min(1.0, (x - x0) / (x1 - x0)))
    return v0 + (v1 - v0) * t


def e50_ord(s, frm, cnt):
    """+1 E50 luon tren E50-3, -1 luon duoi, 0 co cat. -> (ord, slope)"""
    if frm < 0 or frm + cnt + 3 >= s.n or cnt < 2:
        return 0, 0.0
    up = all(s.e[j] > s.e[j + 3] for j in range(frm, frm + cnt))
    dn = all(s.e[j] < s.e[j + 3] for j in range(frm, frm + cnt))
    return (1 if up else (-1 if dn else 0)), s.e[frm] - s.e[frm + cnt - 1]


def e50_trend(s, frm, cnt, min_g):
    o, sl = e50_ord(s, frm, cnt)
    return o if (o != 0 and o * sl >= min_g) else 0


def trend_pct(ordv, slope, sg, min_g, max_g, G):
    if ordv != sg:
        return 0.0
    v = sg * slope
    if v >= max_g:
        return 1.0
    if v >= min_g:
        return 0.7 + 0.3 * (v - min_g) / (max_g - min_g) if max_g > min_g else 1.0
    blocks = int((min_g - max(v, 0.0)) / (0.15 * G) + 1e-9)
    return max(0.3, 0.7 - 0.1 * blocks)


def seg(s, frm, cnt, sg, min_slope):
    G = s.G
    ordv, slope = e50_ord(s, frm, cnt)
    min_g = min_slope * G; max_g = SLOPE_MAX * G
    s15 = slope / (cnt - 1) * 15.0 if cnt > 1 else 0.0
    if ordv == sg:
        return trend_pct(ordv, s15, sg, min_g, max_g, G)
    if ordv == -sg and -sg * s15 >= min_g:
        return 0.25
    return 0.0


def next_tf(tf, k):
    i = NEXT.index(tf) if tf in NEXT else 0
    return NEXT[min(len(NEXT) - 1, i + k)]


def _htf_truoc(s, kh, t_a):
    """Closes cua nen khung lon DA DONG, bat dau truoc nen khung lon chua nen A (cu -> moi)."""
    sec = KHUNG_GIAY[kh]; bucket = t_a - t_a % sec
    return [b[4] for b in s.htf.get(kh, []) if b[0] < bucket]


def htf_e50(s, a, kh):
    cl = _htf_truoc(s, kh, s.t[a])
    if len(cl) < 30:
        return 0.0
    v = cl[0]
    for x in cl[1:]:
        v += (2.0 / 51.0) * (x - v)
    return v + (2.0 / 51.0) * (s.c[a] - v)


def htf_lw(s, a, kh):
    cl = _htf_truoc(s, kh, s.t[a])
    if len(cl) < 14:
        return None
    arr = [s.c[a]] + list(reversed(cl))[:14]
    return [sum((9 - q) * arr[j + q] for q in range(9)) / 45.0 for j in range(6)]


def score_line2(price, a, b, d, G, depth):
    if a == 0 or b == 0:
        return 0.0, "thieu du lieu"
    x = d * price; A = d * a; B = d * b; n3 = depth * G
    if x > A and x > B:
        return 1.0, "tren ca 2"
    if x < A and x < B:
        dd = min(A, B) - x
        if dd >= 2 * n3:
            return 1.0, ""
        if dd >= n3:
            return 0.5 + 0.5 * (dd - n3) / n3, ""
        return 0.0, ""
    lim = A if A > x else B
    return (0.5 if (lim - x) >= n3 else 0.0), ""


def cham_diem_d1(s, r, a, sg, ce, cs, nb, good, has_leak, P):
    G = s.G; n3 = P["Depth"] * G; cA = s.c[a]; oA = s.o[a]; E = s.e[a]
    tc = {}
    touch = sum(1 for x in range(ce, cs + 1) if ((s.h[x] - s.lw[x]) if sg > 0 else (s.lw[x] - s.l[x])) > 0)
    tot = cs - ce + 1
    v1 = 0.5 * (1.0 - touch / max(1, tot))
    tc["TC1"] = v1 * (0.5 if has_leak else 1.0)
    t2 = next_tf(s.tf, 1); t3 = next_tf(s.tf, 2)
    tc["TC2"] = 0.5 * score_line2(cA, htf_e50(s, a, t2), htf_e50(s, a, t3), sg, G, P["Depth"])[0]
    tc["TC3"] = 1.0 if nb == 0 else good / float(nb)
    tc["TC4"] = 0.7 if r["block"] == 1 else 0.35
    body = abs(cA - oA)
    wick = (s.h[a] - max(oA, cA)) if sg > 0 else (min(oA, cA) - s.l[a])
    v5 = 0.0
    if body > 0:
        v5 = 1.0 if wick <= body else max(0.0, 1.0 - (wick - body) / body)
    tc["TC5"] = 0.9 * v5
    fn = seg(s, a, max(3, cs - a + 1), sg, SLOPE_MIN); ff = seg(s, cs + 1, TREND_BARS, sg, SLOPE_MIN)
    tc["TC6"] = 2.2 * (0.75 * fn + 0.25 * ff)
    if r["nhanh"] == "THUAN":
        dep = sg * (s.o[cs] - s.o[ce]); dist = sg * (oA - E)
        v7 = 1.25 * lin(dep, n3, 0.3, 2 * n3, 1.0) + 1.25 * lin(dist, n3, 1.0, 2.5 * n3, 0.0)
    elif r["nhanh"] == "NGUOC":
        v7 = lin(sg * (E - cA), n3, 0.625, 2.5 * n3, 2.5)
    else:
        td = e50_trend(s, a + 1, TREND_BARS, SLOPE_MIN * G)
        v7 = 2.5 if td == sg else (0.625 if td == -sg else 0.0)
    tc["TC7"] = v7
    v8 = 0.0; r["ktt3"] = -9
    lw = htf_lw(s, a, t2)
    if lw:
        up = all(sg * (lw[k] - lw[k + 1]) > 0 for k in range(4))
        dn = all(-sg * (lw[k] - lw[k + 1]) > 0 for k in range(4))
        r["ktt3"] = 1 if up else (-1 if dn else 0)
        xx = sg * cA; A0 = sg * lw[0]; A4 = sg * lw[4]; hi = max(A0, A4); lo = min(A0, A4)
        if xx > hi:
            dd = xx - hi
            v8 = 1.7 if dd <= 3 * n3 else 1.7 * max(0.0, 1.0 - (dd / (3 * n3) - 1.0))
        elif xx >= lo:
            v8 = 0.91
        else:
            v8 = lin(A0 - xx, 0, 0.34, 2.5 * n3, 1.36)
    tc["TC8"] = v8
    r["tc"] = tc
    r["score"] = sum(tc.values())    # chua tru diem sat bien SWR/SWV (X14Pen) - chua port
    r["pen"] = 0.0


def suffix(r, G=1.0):
    """Giong Suffix() cua MAG cho Đ1 (chua co: canh bao rau khung ke tiep, ngược lệnh đang mở, sat bien SW)."""
    sx = ""
    if r["score"] < D1_MIN:
        sx += " | >> thiếu %.1fđ" % (D1_MIN - r["score"])
    if r["sl_lon"]:
        sx += " | >> SL %.2f > %.2f" % (r["sld"] / G, PARAMS["MaxSL"])
    return sx


def push_a(ten, khung, r):
    """Cu phap MAG (PotPush) + 'AI ' o dau. XAU khong ghi ma, BTC ghi."""
    tri = "▲" if r["sg"] > 0 else "▼"
    nhanh = {"THUAN": "THUẬN", "CAT": "CẮT", "NGUOC": "NGƯỢC"}[r["nhanh"]]
    extra = " | " + nhanh + ("" if r["kind"] == "A" else " | " + {"suyt A": "suýt A", "suyt A do": "suýt A đỏ"}[r["kind"]])
    tag = " BTC" if ten == "BTC" else ""
    sfx = suffix(r, G_TAISAN.get(ten, 1.0))
    return "AI A%s ĐANG TẠO | %s%s | %s | %.1fđ%s%s" % (tri, khung, tag, "BUY" if r["sg"] > 0 else "SELL", r["score"], extra, sfx)


def van_ban(ten, khung, r):
    huong = "BUY ⬆️" if r["sg"] > 0 else "SELL ⬇️"
    d = ["🤖 AI · %s %s · Đ1 CÂY %s %s" % (ten, khung, r["kind"].upper().replace("SUYT", "SUÝT"), huong),
         "Giá đóng nến A: %.2f · nhánh %s" % (r["gia"], {"THUAN": "THUẬN", "CAT": "CẮT", "NGUOC": "NGƯỢC"}[r["nhanh"]]),
         "Chuỗi %d nến (đệm %d%s) · độ sâu %.2f · dải 5 đường cuối chuỗi %.2f giá" % (r["len"], r["nb"], ", 1 nến lọt" if r["leak"] else "", r["depth"], r["a8"]),
         "SL gợi ý %.2f (cách %.2f giá)%s" % (r["sl"], r["sld"], " ⚠️ SL lớn → chỉ tham khảo" if r["sl_lon"] else "")]
    d.append("Cấp: CHỈ BÁO (AI không vào lệnh). Điểm TC1–TC8 chưa chấm (đang học từ MAG).")
    return "\n".join(d)
