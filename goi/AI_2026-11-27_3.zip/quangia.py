# -*- coding: utf-8 -*-
"""QUAN GIA AITRADING - chay tren VPS (Python 3.8+, chi thu vien chuan).
Viec: (1) 5 phut kiem AITRADING-GOI: goi moi AI_<ngay>[_n].zip -> tu cai;
(2) doc lenh goi/lenh/*.json (danh sach viec cho phep); (3) day nhat ky len AITRADING-NHATKY;
(4) bao Telegram. KHONG doc/sua gi cua MAG, khong chay lenh tuy y."""
import os, sys, json, time, re, io, zipfile, shutil, socket, base64, hashlib, platform
import subprocess
import urllib.request, urllib.error, urllib.parse
import ranh_gioi
from datetime import datetime

VERSION = "0.2.1"
BASE = os.environ.get("AI_BASE") or (r"C:\AITRADING" if os.name == "nt" else os.path.expanduser("~/AITRADING"))
APP = os.path.join(BASE, "app")
DATA = os.path.join(BASE, "data")
TMP = os.path.join(BASE, "tmp")
KHOA = os.path.join(BASE, "KHOA.txt")
STATE = os.path.join(DATA, "state.json")
LOG = os.path.join(DATA, "quangia_log.txt")
POLL = 300
NHATKY_EVERY = 3 * 3600
MT5_DIR = os.path.join(BASE, "MT5")
MAG_COPY = os.path.join(DATA, "mag_copy")
FLAG_TAT = os.path.join(DATA, "TAT_AI")
KHOA_KEYS = ("MT5_LOGIN", "MT5_SERVER", "MT5_PASS", "MT5_SYMBOL", "MAG_COMMON")
PKG_RE = re.compile(r"^AI_(\d{4}-\d{2}-\d{2})(?:_(\d+))?\.zip$")
CFG = {}
START = time.time()


# ---------- tien ich ----------
def redact(s):
    for k, v in CFG.items():
        if k.endswith("TOKEN") and v and len(v) > 6:
            s = s.replace(v, "***")
    s = re.sub(r"\b\d{6,}:[A-Za-z0-9_-]{30,}", "***", s)
    s = re.sub(r"github_pat_\w+|gh[pousr]_\w{20,}", "***", s)
    return s


def log(msg):
    line = "%s %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), redact(str(msg)))
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        os.makedirs(DATA, exist_ok=True)
        if os.path.exists(LOG) and os.path.getsize(LOG) > 1000000:
            os.replace(LOG, LOG + ".old")
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_cfg():
    c = {}
    try:
        with open(KHOA, encoding="utf-8-sig") as f:
            for ln in f:
                ln = ln.strip()
                if not ln or ln.startswith("#") or "=" not in ln:
                    continue
                k, v = ln.split("=", 1)
                c[k.strip().upper()] = v.strip()
    except Exception:
        pass
    c.setdefault("CHU", "madesjsc-bit")
    for k, d in (("KHO_GOI", "AITRADING-GOI"), ("KHO_NHATKY", "AITRADING-NHATKY"), ("NHANH", "main")):
        if not c.get(k):
            c[k] = d
    if not c.get("TEN_MAY"):
        c["TEN_MAY"] = socket.gethostname()
    CFG.clear()
    CFG.update(c)
    return CFG


def load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    os.makedirs(DATA, exist_ok=True)
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STATE)


# ---------- mang ----------
def http(method, url, headers=None, body=None, timeout=60):
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def _gh_url(kind, path, with_ref):
    repo = CFG["KHO_GOI"] if kind == "goi" else CFG["KHO_NHATKY"]
    url = "https://api.github.com/repos/%s/%s/contents/%s" % (CFG["CHU"], repo, urllib.parse.quote(path))
    ref = CFG["NHANH"] if kind == "goi" else CFG.get("NHANH_NHATKY", "")
    if with_ref and ref:
        url += "?ref=" + urllib.parse.quote(ref)
    return url


def _gh_headers(kind, raw=False):
    tok = CFG.get("GOI_TOKEN" if kind == "goi" else "NHATKY_TOKEN", "")
    h = {"Authorization": "Bearer " + tok, "User-Agent": "aitrading-quangia",
         "X-GitHub-Api-Version": "2022-11-28"}
    h["Accept"] = "application/vnd.github.raw" if raw else "application/vnd.github+json"
    return h


def gh_list(kind, path):
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind))
    if s == 404:
        return []
    if s != 200:
        raise RuntimeError("GitHub list %s HTTP %s" % (path, s))
    d = json.loads(b.decode("utf-8"))
    return d if isinstance(d, list) else []


def gh_raw(kind, path):
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind, True), timeout=300)
    if s != 200:
        raise RuntimeError("GitHub tai %s HTTP %s" % (path, s))
    return b


def gh_put(kind, path, data, msg):
    sha = None
    s, b = http("GET", _gh_url(kind, path, True), _gh_headers(kind))
    if s == 200:
        try:
            sha = json.loads(b.decode("utf-8")).get("sha")
        except Exception:
            sha = None
    body = {"message": msg, "content": base64.b64encode(data).decode("ascii")}
    if sha:
        body["sha"] = sha
    ref = CFG["NHANH"] if kind == "goi" else CFG.get("NHANH_NHATKY", "")
    if ref:
        body["branch"] = ref
    h = _gh_headers(kind)
    h["Content-Type"] = "application/json"
    s, b = http("PUT", _gh_url(kind, path, False), h, json.dumps(body).encode("utf-8"), timeout=120)
    if s not in (200, 201):
        raise RuntimeError("GitHub ghi %s HTTP %s" % (path, s))
    return True


def tg(text):
    tok = CFG.get("TELEGRAM_TOKEN", "")
    if not tok:
        return False
    st = load_state()
    chat = CFG.get("TELEGRAM_CHAT") or st.get("chat", "")
    base = "https://api.telegram.org/bot%s/" % tok
    try:
        if not chat:  # tu tim chat: anh bam Start bot la co
            s, b = http("GET", base + "getUpdates", timeout=30)
            if s == 200:
                res = json.loads(b.decode("utf-8")).get("result", [])
                for u in reversed(res):
                    m = u.get("message") or {}
                    if m.get("chat", {}).get("id"):
                        chat = str(m["chat"]["id"])
                        st["chat"] = chat
                        save_state(st)
                        break
        if not chat:
            log("Telegram: chua co chat (anh bam Start bot AI)")
            return False
        body = urllib.parse.urlencode({"chat_id": chat, "text": text[:4000]}).encode("utf-8")
        s, _ = http("POST", base + "sendMessage", {"Content-Type": "application/x-www-form-urlencoded"}, body, 30)
        return s == 200
    except Exception as e:
        log("Telegram loi: %s" % e)
        return False


# ---------- nhat ky ----------
def tom_tat(st):
    try:
        free = shutil.disk_usage(BASE).free / 1073741824.0
    except Exception:
        free = -1
    return "\n".join([
        "TEN MAY: " + CFG.get("TEN_MAY", ""),
        "THOI GIAN: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "QUAN GIA: " + VERSION,
        "GOI DANG CAI: " + str(st.get("goi", "(chua)")),
        "CHAY DUOC: %d phut" % int((time.time() - START) / 60),
        "O DIA TRONG: %.1f GB" % free,
        "PYTHON: " + platform.python_version() + " / " + platform.platform(),
        "LOI GAN NHAT: " + str(st.get("loi", "(khong)")),
    ]) + "\n"


def push_nhatky(st, reason=""):
    if not CFG.get("NHATKY_TOKEN"):
        return False
    ten = CFG["TEN_MAY"]
    files = {"TOM_TAT.txt": redact(tom_tat(st)).encode("utf-8")}
    try:
        with open(LOG, encoding="utf-8", errors="replace") as f:
            files["quangia_log.txt"] = redact("".join(f.readlines()[-300:])).encode("utf-8")
    except Exception:
        pass
    cache = st.setdefault("pushed", {})
    ok = True
    for n, data in files.items():
        h = hashlib.sha1(data).hexdigest()
        if n != "TOM_TAT.txt" and cache.get(n) == h:
            continue
        try:
            gh_put("nhatky", "nhatky/%s/%s" % (ten, n), data, "nhat ky %s %s" % (ten, reason))
            cache[n] = h
        except Exception as e:
            log("Day nhat ky loi: %s" % e)
            ok = False
    save_state(st)
    return ok


# ---------- cap nhat + lenh ----------
def install_zip(data, name):
    os.makedirs(TMP, exist_ok=True)
    z = zipfile.ZipFile(io.BytesIO(data))
    if z.testzip() is not None:
        raise RuntimeError("zip hong")
    names = z.namelist()
    if "quangia.py" not in names:
        raise RuntimeError("goi khong co quangia.py")
    newdir = os.path.join(BASE, "app_new")
    shutil.rmtree(newdir, ignore_errors=True)
    z.extractall(newdir)
    shutil.copytree(newdir, APP, dirs_exist_ok=True)
    shutil.rmtree(newdir, ignore_errors=True)
    log("Da cai goi %s" % name)


def poll_update(st):
    best = None
    for f in gh_list("goi", "goi"):
        m = PKG_RE.match(f.get("name", ""))
        if m:
            key = (m.group(1), int(m.group(2) or 0))
            if best is None or key > best[0]:
                best = (key, f["name"])
    if not best or best[1] == st.get("goi"):
        return False
    name = best[1]
    if st.get("goi") is None and os.path.exists(os.path.join(APP, "PACKAGE")):
        with open(os.path.join(APP, "PACKAGE"), encoding="utf-8") as f:
            if f.read().strip() == name:  # goi dau da nam trong bo cai lan dau
                st["goi"] = name
                save_state(st)
                return False
    install_zip(gh_raw("goi", "goi/" + name), name)
    st["goi"] = name
    save_state(st)
    tg("✅ AITRADING: đã cài gói %s (quản gia %s)" % (name, VERSION))
    return True


def _don(st):
    n = 0
    shutil.rmtree(os.path.join(BASE, "app_new"), ignore_errors=True)
    if os.path.isdir(TMP):
        for f in os.listdir(TMP):
            p = os.path.join(TMP, f)
            try:
                if time.time() - os.path.getmtime(p) > 86400:
                    shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
                    n += 1
            except Exception:
                pass
    return "da don %d muc" % n


def run_cmd(viec, cmd, st):
    """Danh sach viec CHO PHEP. Tra (ket_qua, hanh_dong)."""
    if viec == "ping":
        tg("🏓 pong từ %s" % CFG["TEN_MAY"])
        return "ok", None
    if viec == "trangthai" or viec == "nhatky":
        push_nhatky(st, "lenh")
        return "ok", None
    if viec == "khoidong_lai":
        return "ok - se khoi dong lai", "restart"
    if viec == "don":
        return _don(st), None
    if viec == "cai_mt5":
        return cai_mt5(cmd), None
    if viec == "mt5_trangthai":
        return "MT5 thu 3 %s" % ("DANG CHAY" if mt5_dang_chay() else "khong chay"), None
    if viec == "tat_ai":
        open(FLAG_TAT, "w").write("tat")
        tg("⛔ AI đã TẮT khẩn (quản gia vẫn chạy)")
        return "da tat AI", None
    if viec == "bat_ai":
        try:
            os.remove(FLAG_TAT)
        except OSError:
            pass
        return "da bat AI", None
    if viec == "gui_tin":
        return ("ok" if tg(str(cmd.get("text", ""))[:1000]) else "khong gui duoc"), None
    return "viec khong nam trong danh sach cho phep: %s" % viec, None


def poll_commands(st):
    files = [f for f in gh_list("goi", "lenh") if f.get("name", "").endswith(".json")]
    if "lenh_done" not in st:  # lan dau: chi ghi nhan, khong chay lenh cu
        st["lenh_done"] = [f["name"][:-5] for f in files]
        save_state(st)
        return None
    action = None
    for f in sorted(files, key=lambda x: x["name"]):
        cid = f["name"][:-5]
        if cid in st["lenh_done"]:
            continue
        try:
            cmd = json.loads(gh_raw("goi", "lenh/" + f["name"]).decode("utf-8-sig"))
            res, act = run_cmd(str(cmd.get("viec", "")), cmd, st)
        except Exception as e:
            res, act = "loi: %s" % e, None
        st["lenh_done"] = (st["lenh_done"] + [cid])[-300:]
        save_state(st)
        log("Lenh %s -> %s" % (cid, res))
        if CFG.get("NHATKY_TOKEN"):
            try:
                gh_put("nhatky", "nhatky/%s/ketqua/%s.txt" % (CFG["TEN_MAY"], cid), redact(res).encode("utf-8"), "ket qua " + cid)
            except Exception as e:
                log("Ghi ket qua loi: %s" % e)
        if act:
            action = act
    return action



def khoa_chuan_hoa():
    """KHOA.txt phai xuong dong kieu Windows (CRLF) de Notepad cu hien dung."""
    try:
        with open(KHOA, "rb") as f:
            b = f.read()
        if b"\n" in b and b.replace(b"\r\n", b"").count(b"\n"):
            with open(KHOA, "wb") as f:
                f.write(b.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
    except Exception as e:
        log("khoa_chuan_hoa: %s" % e)


def ensure_khoa_keys():
    """Them (chi them, khong ghi de) cac khoa con thieu vao KHOA.txt de anh dien."""
    try:
        with open(KHOA, encoding="utf-8-sig") as f:
            have = {ln.split("=", 1)[0].strip().upper() for ln in f if "=" in ln and not ln.strip().startswith("#")}
        miss = [k for k in KHOA_KEYS if k not in have]
        if miss:
            with open(KHOA, "a", encoding="utf-8", newline="") as f:
                f.write("\r\n" + "\r\n".join(k + "=" for k in miss) + "\r\n")
    except Exception as e:
        log("ensure_khoa_keys: %s" % e)


def thu_mag(st):
    """Thu thap (chi doc) vai file nhat ky FD14 cua MAG -> data/mag_copy. CHUA dung de huan luyen."""
    os.makedirs(MAG_COPY, exist_ok=True)
    cache = st.setdefault("mag_sha", {})
    n = 0
    for ten in ranh_gioi.liet_ke(CFG):
        data = ranh_gioi.doc(CFG, ten)
        if data is None:
            continue
        h = hashlib.sha1(data).hexdigest()
        if cache.get(ten) == h:
            continue
        with open(os.path.join(MAG_COPY, ten), "wb") as f:
            f.write(data)
        cache[ten] = h
        n += 1
    return n


def mt5_dang_chay():
    if os.name != "nt":
        return False
    try:
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
              "Where-Object { $_.ExecutablePath -like '%s*' } | Measure-Object | Select -Expand Count" % (MT5_DIR + "\\"))
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60)
        return r.stdout.strip() not in ("", "0")
    except Exception:
        return False


def cai_mt5(cmd):
    """MT5 thu 3: chep (CHI DOC) ban cai cua MT5 MAG -> C:\\AITRADING\\MT5, dang nhap DEMO, portable.
    Khong chay setup (tranh de len MT5 MAG). Mat khau chi lay tu KHOA.txt (MT5_PASS)."""
    if os.name != "nt":
        return "chi chay tren Windows"
    login = str(cmd.get("login") or CFG.get("MT5_LOGIN", ""))
    server = str(cmd.get("server") or CFG.get("MT5_SERVER", ""))
    pw = CFG.get("MT5_PASS", "")
    if not (login and server and pw):
        return "thieu MT5_LOGIN / MT5_SERVER / MT5_PASS (dien trong KHOA.txt)"
    exe = os.path.join(MT5_DIR, "terminal64.exe")
    if not os.path.exists(exe):
        src = str(cmd.get("nguon") or r"C:\Program Files\MetaTrader 5")
        if not os.path.exists(os.path.join(src, "terminal64.exe")):
            return "khong thay ban cai MT5 nguon: " + src
        if shutil.disk_usage(BASE).free < 4 * 1073741824:
            return "o dia trong < 4 GB - khong cai"
        r = subprocess.run(["robocopy", src, MT5_DIR, "/E", "/XD", "MQL5", "config", "logs", "bases", "Tester",
                            "/XF", "*.log", "/R:1", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP"],
                           capture_output=True, text=True, timeout=900)
        if r.returncode >= 8 or not os.path.exists(exe):
            return "robocopy loi (ma %s)" % r.returncode
    ini = os.path.join(MT5_DIR, "ai_first.ini")
    try:
        txt = ("[Common]\r\nLogin=%s\r\nPassword=%s\r\nServer=%s\r\nKeepPrivate=1\r\nNewsEnable=0\r\n"
               "[Experts]\r\nAllowLiveTrading=0\r\nAllowDllImport=0\r\nEnabled=0\r\nAccount=0\r\nProfile=0\r\n") % (login, pw, server)
        with open(ini, "w", encoding="utf-16") as f:
            f.write(txt)
        if not mt5_dang_chay():
            subprocess.Popen('"%s" /portable /config:"%s"' % (exe, ini), cwd=MT5_DIR, creationflags=0x00004000)  # BELOW_NORMAL
            for _ in range(40):
                time.sleep(3)
                if os.path.isdir(os.path.join(MT5_DIR, "MQL5", "Experts")):
                    break
        time.sleep(20)
    finally:
        try:
            os.remove(ini)  # xoa file co mat khau
        except OSError:
            pass
    return "MT5 thu 3: %s (TK demo %s)" % ("DANG CHAY" if mt5_dang_chay() else "chua thay chay - xem lai", login)

# ---------- vong chinh ----------
def main():
    for d in (APP, DATA, TMP):
        os.makedirs(d, exist_ok=True)
    khoa_chuan_hoa()
    load_cfg()
    ensure_khoa_keys()
    st = load_state()
    if st.get("goi") is None and os.path.exists(os.path.join(APP, "PACKAGE")):
        with open(os.path.join(APP, "PACKAGE"), encoding="utf-8") as f:
            st["goi"] = f.read().strip()
        save_state(st)
    log("Quan gia %s chay (goi %s)" % (VERSION, st.get("goi")))
    tg("🟢 Quản gia AITRADING %s đã chạy trên %s (gói %s)" % (VERSION, CFG["TEN_MAY"], st.get("goi")))
    push_nhatky(st, "khoi dong")
    last_poll = 0.0
    last_nk = time.time()
    last_disk = 0.0
    last_mag = 0.0
    while True:
        load_cfg()
        now = time.time()
        try:
            if now - last_poll >= POLL:
                last_poll = now
                if not CFG.get("GOI_TOKEN"):
                    log("Chua co GOI_TOKEN trong KHOA.txt")
                else:
                    if poll_update(st):
                        push_nhatky(st, "sau cap nhat")
                        log("Thoat de chay ban moi")
                        sys.exit(0)
                    if poll_commands(st) == "restart":
                        log("Khoi dong lai theo lenh")
                        sys.exit(0)
                    st.pop("loi", None)
            if now - last_mag >= 300:
                last_mag = now
                if not os.path.exists(FLAG_TAT):
                    thu_mag(st)
            if now - last_nk >= NHATKY_EVERY:
                last_nk = now
                push_nhatky(st, "dinh ky")
            if now - last_disk >= 6 * 3600:
                last_disk = now
                if shutil.disk_usage(BASE).free < 2 * 1073741824:
                    tg("⚠️ %s: ổ đĩa còn dưới 2 GB" % CFG["TEN_MAY"])
        except SystemExit:
            raise
        except Exception as e:
            st["loi"] = "%s %s" % (datetime.now().strftime("%d/%m %H:%M"), redact(str(e))[:200])
            save_state(st)
            log("LOI: %s" % e)
        time.sleep(15)


if __name__ == "__main__":
    main()
