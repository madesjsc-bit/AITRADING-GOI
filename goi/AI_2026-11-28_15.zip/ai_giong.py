# -*- coding: utf-8 -*-
"""BAO THOAI THONG MINH cua AI (khong dung am thanh thu san nhu MAG):
- AI SOAN loi noi moi lan theo TINH HUONG THAT (diem, nhanh, SL, lich su phan hoi cua tac gia, ket qua tin truoc)
- chon CAP: 🔴 khan (diem dat + SL ok) · 🟡 thuong · ⚪ chi chu; khung gio yen lang; gop nhieu tin cung luc thanh 1 loi
- doc bang giong nhan tao tieng Viet (edge-tts) gui thanh tin THOAI Telegram + Bark (iPhone) kem muc uu tien
- ban nhac lai 1 lan khi tin khan chua duoc xem; bao KET QUA khi tin da co ket cuc (hook san)
Chi la thong bao - khong co phan giao dich."""
import os, time, csv, json

CHU = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"]


def doc_nguyen(n):
    n = int(n)
    if n < 10:
        return CHU[n]
    if n < 20:
        return "mười" + ("" if n == 10 else (" lăm" if n == 15 else " " + CHU[n - 10]))
    if n < 100:
        c, d = divmod(n, 10)
        s = CHU[c] + " mươi"
        if d == 0:
            return s
        return s + " " + ("mốt" if d == 1 else ("lăm" if d == 5 else CHU[d]))
    if n < 1000:
        c, r = divmod(n, 100)
        s = CHU[c] + " trăm"
        if r == 0:
            return s
        if r < 10:
            return s + " lẻ " + CHU[r]
        return s + " " + doc_nguyen(r)
    if n < 1000000:
        k, r = divmod(n, 1000)
        s = doc_nguyen(k) + " nghìn"
        if r == 0:
            return s
        if r < 100:
            return s + " không trăm " + (("lẻ " + CHU[r]) if r < 10 else doc_nguyen(r))
        return s + " " + doc_nguyen(r)
    return str(n)


def doc_so(x, le=1):
    """3.4 -> 'ba phẩy bốn'; 7 -> 'bảy'."""
    x = round(float(x), le)
    ng = int(x)
    p = int(round((x - ng) * 10 ** le))
    return doc_nguyen(ng) if p == 0 else "%s phẩy %s" % (doc_nguyen(ng), " ".join(CHU[int(c)] for c in str(p).zfill(le)))


def yen_lang(t, tu=23, den=6):
    """Gio VN (UTC+7)."""
    h = time.gmtime(t + 7 * 3600).tm_hour
    return h >= tu or h < den


def lich_su(data_dir, ten, kh, nhanh):
    """Anh da danh dau chuan/sai bao nhieu lan cho loai tin nay (ten, khung, nhanh)."""
    ok = bad = 0
    try:
        with open(os.path.join(data_dir, "phanhoi.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) < 3:
                    continue
                try:
                    sn = json.load(open(os.path.join(data_dir, "ai_snap", r[1] + ".json"), encoding="utf-8"))
                except Exception:
                    continue
                if sn.get("ten") == ten and sn.get("kh") == kh and sn.get("nhanh") == nhanh:
                    ok += r[2] == "ok"; bad += r[2] == "sai"
    except OSError:
        pass
    return ok, bad


def phan_cap(sn, nguong=5.0):
    """'khan' | 'thuong' | 'chu'"""
    if sn["score"] >= nguong and not sn.get("sl_lon"):
        return "khan"
    if sn["score"] >= nguong - 1.5:
        return "thuong"
    return "chu"


def soan_loi(sn, ok_bad=(0, 0), nguong=5.0):
    ten = "vàng" if sn["ten"] == "XAU" else "Bít-coin"
    kh = {"M1": "một phút", "M5": "năm phút", "M15": "mười lăm phút", "M30": "ba mươi phút", "H1": "một giờ", "H4": "bốn giờ"}.get(sn["kh"], sn["kh"])
    huong = "mua" if sn["sg"] > 0 else "bán"
    nhanh = {"THUAN": "thuận xu hướng", "CAT": "cắt qua E-M-A năm mươi", "NGUOC": "ngược xu hướng"}[sn["nhanh"]]
    s = "%s, khung %s, cây A %s đang tạo, điểm %s trên mười, %s." % (ten.capitalize(), kh, huong, doc_so(sn["score"]), nhanh)
    if sn["score"] >= nguong:
        s += " Đã đạt ngưỡng."
    else:
        s += " Còn thiếu %s điểm." % doc_so(nguong - sn["score"])
    if sn.get("sl_lon"):
        s += " Cảnh báo: stop loss lớn, chỉ tham khảo."
    else:
        s += " Stop loss gợi ý cách %s giá." % doc_so(sn["sld"] / (30.0 if sn["ten"] == "BTC" else 1.0))
    ok, bad = ok_bad
    if ok + bad >= 3:
        s += " Loại này anh từng đánh dấu chuẩn %s trên %s lần." % (doc_nguyen(ok), doc_nguyen(ok + bad))
    return s


def gop(ds):
    """Gop nhieu loi cung luc thanh 1 (de khong 'reo' lien tuc)."""
    if len(ds) == 1:
        return ds[0]
    return "Có %s tín hiệu cùng lúc. " % doc_nguyen(len(ds)) + " ".join("Tín hiệu %s. %s" % (doc_nguyen(i + 1), x) for i, x in enumerate(ds))


def multipart(fields, ten_file, noi_dung, kieu="audio/mpeg", truong="voice"):
    bd = "----ai%d" % int(time.time() * 1000)
    b = b""
    for k, v in fields.items():
        b += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (bd, k, v)).encode("utf-8")
    b += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n" % (bd, truong, ten_file, kieu)).encode("utf-8")
    b += noi_dung + ("\r\n--%s--\r\n" % bd).encode("utf-8")
    return b, "multipart/form-data; boundary=" + bd


def bark_muc(cap):
    """Muc uu tien Bark (iOS): khan = timeSensitive + chuong keo dai; thuong = active; chu = passive (im)."""
    return {"khan": {"level": "timeSensitive", "call": "1", "volume": 8}, "thuong": {"level": "active"}, "chu": {"level": "passive"}}[cap]
