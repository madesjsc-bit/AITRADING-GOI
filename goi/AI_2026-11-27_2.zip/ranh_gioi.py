# -*- coding: utf-8 -*-
"""RANH GIOI voi MAG: module DUY NHAT duoc cham vao thu muc cua MAG - CHI DOC.
Chi mo 'rb', doc 1 lan, dong ngay. Khong ghi / xoa / doi ten / chay lenh. Whitelist file.
(Test tools/test_quangia.py quet ma de bao dam dieu nay.)"""
import os, fnmatch

MAU = ("FD14_AUTO_*.csv", "FD14_PRICE_*.txt")  # file trong Common\Files\FullD duoc phep doc
TOI_DA = 20 * 1024 * 1024


def goc(cfg):
    if cfg.get("MAG_COMMON"):
        return cfg["MAG_COMMON"]
    if os.name == "nt":
        return r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\Common\Files"
    return os.path.expanduser("~/MAG_COMMON_FILES")


def _hop_le(ten):
    return (os.path.basename(ten) == ten and ".." not in ten
            and any(fnmatch.fnmatch(ten.lower(), m.lower()) for m in MAU))


def liet_ke(cfg):
    d = os.path.join(goc(cfg), "FullD")
    try:
        return sorted(n for n in os.listdir(d) if _hop_le(n))
    except OSError:
        return []


def doc(cfg, ten):
    """Tra ve bytes (toi da 20 MB) hoac None. Chi file trong whitelist."""
    if not _hop_le(ten):
        return None
    try:
        with open(os.path.join(goc(cfg), "FullD", ten), "rb") as f:
            return f.read(TOI_DA)
    except OSError:
        return None
