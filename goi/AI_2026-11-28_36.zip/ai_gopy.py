# -*- coding: utf-8 -*-
"""TONG HOP DAC DIEM CAY A/P TOT + GOI Y TIEU CHI MOI (tac gia 28/11: 'ngoai nhung tieu chi minh cho, thoai mai bo sung de goi y').
Moi cay A/P da co ket qua (tot = vao xong lai >= $3 tai lot 0.01): so sanh nhom TOT vs XAU tren
 (1) tieu chi cua tac gia (TC1..TC11, diem, loai, nhanh, SL...)  (2) tieu chi MOI AI tu bo sung: gio san, thu trong tuan, bien dong (u gan/xa),
 than/rau cua nen tin hieu, chuoi nen nguoc truoc do, dong luong 3 nen, khoang cach toi dinh/day ngay, so tick.
Xep hang theo AUC + 'nguong tot nhat' (ti le tot o 2 phia). Chi goi y - tac gia duyet moi dua vao luat."""
import time
import ai_tick, ai_bai2

TEN_MOI = ["gio_san", "thu", "bien_dong_gan_xa", "than_nen_A", "rau_tren_nen_A", "rau_duoi_nen_A", "so_nen_nguoc_truoc", "cu_chay_truoc", "dong_luong_3_nen",
           "xa_dinh_day_ngay", "so_tick_phut"]
NHAN = {"diem": "Điểm tổng MAG", "loai": "Loại (A/suýt A/P)", "nhanh": "Nhánh (thuận/cắt/ngược)", "sl_gia": "SL gợi ý (giá)", "chuan": "Là cây chuẩn MAG",
        "btc": "Là BTC", "gio_san": "GIỜ SÀN (0–23)", "thu": "THỨ trong tuần (0=T2)", "bien_dong_gan_xa": "BIẾN ĐỘNG gần/xa (u30 ÷ u360)",
        "than_nen_A": "THÂN nến tín hiệu (÷u)", "rau_tren_nen_A": "RÂU TRÊN nến tín hiệu (÷u)", "rau_duoi_nen_A": "RÂU DƯỚI nến tín hiệu (÷u)",
        "so_nen_nguoc_truoc": "SỐ NẾN ngược chiều liền trước", "cu_chay_truoc": "CÚ CHẠY trước đó (÷u)", "dong_luong_3_nen": "ĐỘNG LƯỢNG 3 nến (÷u)",
        "xa_dinh_day_ngay": "KHOẢNG CÁCH tới đỉnh/đáy ngày (÷u)", "so_tick_phut": "SỐ TICK trong phút"}
for i in range(1, 12):
    NHAN["TC%d" % i] = "TC%d (tiêu chí MAG)" % i
MOI = set(TEN_MOI)


def them(bars, idx, sg, t, ten_gio_san=0):
    """Tieu chi MOI cho nen tin hieu o chi so idx trong bars M1 [(t,o,h,l,c)] (khung BUY nhan sg)."""
    if idx < 40 or idx >= len(bars):
        return None
    def fr(b):
        return (sg * b[1], sg * (b[2] if sg > 0 else b[3]), sg * (b[3] if sg > 0 else b[2]), sg * b[4])
    rg = [b[2] - b[3] for b in bars[idx - 30:idx]]; rg2 = [b[2] - b[3] for b in bars[max(0, idx - 360):idx]]
    u = sorted(rg)[len(rg) // 2] or 1e-9; u2 = sorted(rg2)[len(rg2) // 2] or 1e-9
    o, h, l, c = fr(bars[idx]); top = max(o, c); bot = min(o, c)
    nguoc = 0; chay = 0.0; q = idx - 1
    while q >= idx - 12 and sg * (bars[q][4] - bars[q][1]) < 0:
        nguoc += 1; chay += abs(bars[q][4] - bars[q][1]); q -= 1
    day = time.gmtime(t + ten_gio_san * 3600).tm_yday; ext = None; j = idx
    while j >= 0 and time.gmtime(bars[j][0] + ten_gio_san * 3600).tm_yday == day:
        e = bars[j][2] if sg > 0 else bars[j][3]
        ext = e if ext is None else (max(ext, e) if sg > 0 else min(ext, e)); j -= 1
    lt = time.gmtime(t + ten_gio_san * 3600)
    return {"gio_san": float(lt.tm_hour), "thu": float(lt.tm_wday), "bien_dong_gan_xa": u / u2, "than_nen_A": (top - bot) / u, "rau_tren_nen_A": (h - top) / u,
            "rau_duoi_nen_A": (bot - l) / u, "so_nen_nguoc_truoc": float(nguoc), "cu_chay_truoc": chay / u,
            "dong_luong_3_nen": sg * (bars[idx][4] - bars[idx - 3][4]) / u, "xa_dinh_day_ngay": abs((ext - bars[idx][4]) if ext is not None else 0.0) / u, "so_tick_phut": 0.0}


def auc(ys, xs):
    pos = [x for y, x in zip(ys, xs) if y]; neg = [x for y, x in zip(ys, xs) if not y]
    if not pos or not neg:
        return 0.5
    z = sorted([(x, 1) for x in pos] + [(x, 0) for x in neg]); i = 0; sr = 0.0
    while i < len(z):
        j = i
        while j < len(z) and z[j][0] == z[i][0]:
            j += 1
        sr += sum(1 for k in range(i, j) if z[k][1]) * (i + j + 1) / 2.0
        i = j
    return (sr - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg))


def tot_nhat(xs, ys, min_n=15):
    """Nguong chia tot nhat: -> (nguong, ti_le_tot_cao, n_cao, ti_le_tot_thap, n_thap) hoac None."""
    best = None; vs = sorted(set(xs))
    if len(vs) < 3:
        return None
    for q in range(1, 10):
        th = sorted(xs)[min(len(xs) - 1, int(len(xs) * q / 10.0))]
        hi = [y for x, y in zip(xs, ys) if x >= th]; lo = [y for x, y in zip(xs, ys) if x < th]
        if len(hi) < min_n or len(lo) < min_n:
            continue
        d = abs(sum(hi) / float(len(hi)) - sum(lo) / float(len(lo)))
        if best is None or d > best[0]:
            best = (d, th, sum(hi) / float(len(hi)), len(hi), sum(lo) / float(len(lo)), len(lo))
    return best[1:] if best else None


def phan_tich(rows, extras):
    """rows: doc_tap(); extras: {(t,ten,sg): dict tieu chi moi}. -> list goi y da xep hang."""
    cot = {}
    for r in rows:
        f = dict(zip(ai_bai2.TEN_F, r["f"]))
        e = extras.get((r["t"], r["ten"], r["sg"]), {})
        for k, v in f.items():
            cot.setdefault(k, []).append((v, r["tot"]))
        for k, v in e.items():
            cot.setdefault(k, []).append((v, r["tot"]))
    out = []
    for k, vs in cot.items():
        if len(vs) < 30 or len({x for x, _ in vs}) < 3 or len({y for _, y in vs}) < 2:
            continue
        xs = [x for x, _ in vs]; ys = [y for _, y in vs]
        a = auc(ys, xs); tn = tot_nhat(xs, ys)
        if tn:
            out.append({"ten": k, "auc": a, "n": len(vs), "moi": k in MOI, "nguong": tn[0], "tot_cao": tn[1], "n_cao": tn[2], "tot_thap": tn[3], "n_thap": tn[4],
                        "hieu_ung": max(abs(a - 0.5), abs(tn[1] - tn[3]) / 2.0)})
    return sorted(out, key=lambda x: -x["hieu_ung"])


def thu_thap_extras(data_dir, rows, G_by_ten, gio_san=0, toi_da=1500):
    ex = {}; cache = {}
    for r in rows[-toi_da:]:
        ten = r["ten"]
        if ten not in cache:
            tk = ai_tick.doc_het(data_dir, ten); b = ai_bai2.bars_tu_tick(tk, 60)
            cache[ten] = (b, {x[0]: i for i, x in enumerate(b)})
        b, pos = cache[ten]
        i = pos.get(r["t"])
        if i is None:
            continue
        d = them(b, i, r["sg"], r["t"], gio_san)
        if d:
            ex[(r["t"], r["ten"], r["sg"])] = d
    return ex


def bao_cao(data_dir, gio_san=0):
    rows = ai_bai2.doc_tap(data_dir)
    n_t = sum(r["tot"] for r in rows)
    o = ["💡 TỔNG HỢP CÂY A/P TỐT & GỢI Ý TIÊU CHÍ MỚI (tốt = vào xong lãi ≥ $%.0f tại lot %.2f)" % (ai_bai2.NG["loi_usd"], ai_bai2.NG["lot"])]
    if len(rows) < 60 or n_t < 10 or n_t > len(rows) - 10:
        o.append("   Cần thêm dữ liệu: có %d cây có kết quả (%d tốt). Cần ≥ 60 cây, mỗi nhóm tốt/xấu ≥ 10." % (len(rows), n_t))
        return "\n".join(o)
    ex = thu_thap_extras(data_dir, rows, {}, gio_san)
    kq = phan_tich(rows, ex)
    o.append("   %d cây có kết quả · %.0f%% là cây tốt · %d cây có đủ tiêu chí mới" % (len(rows), 100.0 * n_t / len(rows), len(ex)))
    top = [x for x in kq if x["hieu_ung"] >= 0.05][:8]
    if not top:
        o.append("   Chưa tìm thấy tiêu chí nào phân biệt rõ cây tốt/xấu. Cần thêm dữ liệu.")
    for x in top:
        o.append("   %s %s: khi ≥ %.2f → tốt %.0f%% (n=%d) · còn lại tốt %.0f%% (n=%d) · AUC %.2f" % (
            "🆕" if x["moi"] else "•", NHAN.get(x["ten"], x["ten"]), x["nguong"], x["tot_cao"] * 100, x["n_cao"], x["tot_thap"] * 100, x["n_thap"], x["auc"]))
    if top:
        o.append("   🆕 = tiêu chí AI tự bổ sung (không có trong bảng điểm MAG). Em chỉ gợi ý – anh duyệt tiêu chí nào thì đưa vào luật.")
    return "\n".join(o)
