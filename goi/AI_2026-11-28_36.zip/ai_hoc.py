# -*- coding: utf-8 -*-
"""CONG CU TOI UU bam-la-xong (giong /why /name /report cua MAG + nut hoc lai):
- moi push AI co id + anh chup (snapshot) -> /why_<id> giai thich diem tung tieu chi
- nut ✅ Chuan / ❌ Sai -> hoi ly do bang nut -> ghi vao hoclai.json (AI 'nho' bai hoc, Claude doc tu NHATKY de chinh luat)
- /report: thong ke push + phan hoi + ty le; /hoclai: xem bai hoc gan nhat
Moi thu chi GHI NHO + THONG KE; khong tu doi luat (doi luat can tac gia duyet)."""
import os, json, csv, time

LY_DO = ["Dây chưa mở đủ", "Râu dài", "Đi ngang / sideway", "Vào muộn", "Điểm sai", "Khác"]
TC_TEN_P = {"TC1": ("Chuỗi mở sạch", 1.1), "TC2": ("Độ sâu", 1.0), "TC3": ("Độ nông cụm hồi", 0.4), "TC4": ("Số nến cụm hồi", 0.7),
            "TC5": ("close→SL", 0.8), "TC6": ("Râu", 0.3), "TC7": ("EMA50 (80/20)", 1.2), "TC8": ("vs EMA50 2 khung lớn", 0.5),
            "TC9": ("vs dải MA9 khung lớn", 1.3), "TC10": ("Cản phía trước", 1.3), "TC11": ("open Bp cách EMA50", 1.4)}
TC_TEN = {"TC1": ("Chuỗi ít râu chạm dải", 0.5), "TC2": ("close A vs EMA50 2 khung lớn", 0.5), "TC3": ("Nến đệm xanh", 1.0),
          "TC4": ("close A → SL", 0.7), "TC5": ("Râu trên A", 0.9), "TC6": ("Xu hướng EMA50", 2.2),
          "TC7": ("Nhánh", 2.5), "TC8": ("close A vs dải MA9 khung lớn", 1.7)}

NAME_DANGTAO = """📖 PUSH "ĐANG TẠO" của AI – đọc thế nào
Ví dụ: AI A▲ ĐANG TẠO · M1 · BUY · 4.8đ · THUẬN · >> thiếu 0.2đ

• AI: tin do bot AI gửi (cú pháp giống bot MAG).
• A▲ ĐANG TẠO: nến hiện tại CHƯA ĐÓNG nhưng đang có dáng cây A (Đ1 – giao cắt): sau chuỗi nến đi ngược, giá vừa cắt ngược lại dải MA9 (đã vượt ma9-3). Nến đóng không đạt thì tín hiệu bỏ. (A = Đ1, ▲ = BUY, ▼ = SELL)
• M1: khung đang xét. Vàng không ghi mã; BTC có chữ BTC (vd M1 BTC).
• BUY: chiều lệnh nếu tín hiệu thành.
• 4.8đ: điểm (thang 10) theo bảng chấm 8 tiêu chí của MAG.
• THUẬN / NGƯỢC / CẮT: vị trí nến A so với EMA50.
• >> thiếu 0.2đ: còn thiếu điểm so với ngưỡng (5.0) – chỉ báo, tự quyết. Các cảnh báo >> khác: >> SL (SL vượt mức).

Xem điểm từng tiêu chí: bấm 👉 /why. Báo cáo: /report. Bấm ✅ Chuẩn / ❌ Sai dưới tin để AI học lại."""


GIO_SAN = 0   # gio san = GMT + GIO_SAN (Exness MT5: server GMT+0). Chinh bang luat gio_san.


def gio_san(t, mau="%d/%m %H:%M"):
    return time.strftime(mau, time.gmtime(t + GIO_SAN * 3600))


def tao_id(ten, kh, t, sg, loai="a"):
    lt = time.gmtime(t + GIO_SAN * 3600)   # GIO SAN (khong phai gio VN) - giong /why cua MAG
    return "%s_%s_%s_%s_%s_%s" % ("b" if ten == "BTC" else "x", kh.lower(), time.strftime("%H%M", lt), loai,
                                 "buy" if sg > 0 else "sell", time.strftime("%d%m", lt))


def luu_snap(data_dir, sid, snap):
    d = os.path.join(data_dir, "ai_snap")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, sid + ".json"), "w", encoding="utf-8") as f:
        json.dump(snap, f, ensure_ascii=False)
    fs = sorted(os.listdir(d))
    for old in fs[:-600]:           # giu 600 anh chup gan nhat
        try:
            os.remove(os.path.join(d, old))
        except OSError:
            pass


def doc_snap(data_dir, sid):
    try:
        with open(os.path.join(data_dir, "ai_snap", sid + ".json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def dong_diem(snap):
    """Thang diem cua tac gia, 1 dong: TC1 0.4 · TC2 0.0 … = 3.4/10"""
    if not snap or not snap.get("tc"):
        return ""
    tcs = snap["tc"]
    return "📐 " + " · ".join("%s %.1f" % (k, tcs[k]) for k in sorted(tcs, key=lambda x: int(x[2:]))) + " = %.1f/10" % snap["score"]


def chan_tin(sid, snap=None):
    d = dong_diem(snap)
    return "\n\n" + ((d + "\n") if d else "") + "👉 /why_%s\n📊 /report\n💬 /name_dangtao" % sid


def ban_phim(sid):
    return {"inline_keyboard": [[{"text": "✅ Chuẩn", "callback_data": "fb|%s|ok" % sid},
                                 {"text": "❌ Sai – học lại", "callback_data": "fb|%s|bad" % sid}],
                                [{"text": "📊 Báo cáo", "callback_data": "rp|-|-"}]]}


def ban_phim_ly_do(sid):
    rows = [[{"text": x, "callback_data": "fr|%s|%d" % (sid, i)}] for i, x in enumerate(LY_DO)]
    return {"inline_keyboard": rows}


def giai_thich(snap):
    d = snap; loai = d.get("loai", "A")
    if loai == "MO":
        return "\n".join(["🔎 /why · %s %s · MỞ %s%s" % (d["ten"], d["kh"], "LÊN" if d["sg"] > 0 else "XUỐNG", (" · nến %s (giờ sàn)" % gio_san(d["t"])) if d.get("t") else ""),
                           "Chuỗi mở đủ điều kiện (nến thứ 3 đóng): dốc %.2f" % d.get("doc", 0),
                           "PULLBACK giả định: %.1fđ · GIAO CẮT giả định: %s" % (d.get("pb_score", 0), ("%.1fđ" % d["gc_score"]) if d.get("gc_ok") else "–"),
                           d.get("ctx", ""), ("Phản hồi của anh: " + d["fb"]) if d.get("fb") else ""]).strip()
    tens = TC_TEN_P if loai in ("P", "HOI") else TC_TEN
    ten_loai = {"A": "A%s %s" % ("▲" if d["sg"] > 0 else "▼", d.get("kind", "")), "P": "P%s" % ("▲" if d["sg"] > 0 else "▼"),
                "HOI": "h%s NHỊP HỒI" % ("▲" if d["sg"] > 0 else "▼")}[loai]
    ng = 5.0 if loai == "A" else 7.0
    out = ["🔎 /why · %s %s · %s %s%s" % (d["ten"], d["kh"], ten_loai, d.get("nhanh", ""), (" · nến %s (giờ sàn)" % gio_san(d["t"])) if d.get("t") else ""),
           "Điểm: %.1fđ / 10 (ngưỡng %.1f)" % (d["score"], ng)]
    for k, (nm, mx) in tens.items():
        out.append("%s %s: %.2f / %.2f" % (k, nm, d["tc"].get(k, 0), mx))
    if loai == "A":
        out.append("Chuỗi %d nến · đệm %d · độ sâu %.2f · dải 5 đường cuối chuỗi %.2f giá" % (d["len"], d["nb"], d["depth"], d["a8"]))
    out.append("SL gợi ý %.2f (cách %.2f giá)%s" % (d["sl"], d["sld"], " ⚠ SL lớn" if d.get("sl_lon") else ""))
    if d.get("ketqua"):
        k = d["ketqua"]
        out.append("📈 KẾT QUẢ sau đó: %s · lãi tối đa $%.2f · ngược tối đa $%.2f (lot 0.01) · %s · ĐIỂM THỰC TẾ %.1f/10 (MAG chấm %.1f)" % (
            "B đúng chiều ✅" if k["b_dung"] else "B ngược chiều ❌", k["mfe_usd"], k["mae_usd"], "TỐT ✅ (đạt $3)" if k["tot"] else "CHƯA ĐẠT $3", k["diem_thuc"], d["score"]))
    if d.get("fb"):
        out.append("Phản hồi của anh: " + d["fb"])
    return "\n".join(out)


def ghi_phan_hoi(data_dir, sid, nhan, ly_do=""):
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "phanhoi.csv"), "a", encoding="utf-8", newline="") as f:
        csv.writer(f).writerow([int(time.time()), sid, nhan, ly_do])
    snap = doc_snap(data_dir, sid)
    if snap is not None:
        snap["fb"] = nhan + ((" – " + ly_do) if ly_do else "")
        luu_snap(data_dir, sid, snap)
    if nhan == "sai":                                  # bai hoc de AI/Claude hoc lai
        p = os.path.join(data_dir, "hoclai.json")
        try:
            ds = json.load(open(p, encoding="utf-8"))
        except Exception:
            ds = []
        ds.append({"t": int(time.time()), "id": sid, "ly_do": ly_do, "snap": snap})
        json.dump(ds[-300:], open(p, "w", encoding="utf-8"), ensure_ascii=False)


def bao_cao(data_dir, gio=24):
    now = time.time(); out = ["📊 /report AI – %d giờ qua" % gio]
    rows = []
    try:
        with open(os.path.join(data_dir, "ai_phathien.csv"), encoding="utf-8") as f:
            rows = [r for r in csv.reader(f) if len(r) >= 8 and r[3] == "A_dangtao" and now - int(r[0]) <= gio * 3600]
    except (OSError, ValueError):
        pass
    if not rows:
        out.append("Chưa có push A ĐANG TẠO trong khoảng này.")
    else:
        tong = len(rows); dat = sum(1 for r in rows if float(r[7]) >= 5.0)
        out.append("Push A ĐANG TẠO: %d (đủ điểm ≥ 5.0: %d · thiếu: %d)" % (tong, dat, tong - dat))
        theo = {}
        for r in rows:
            k = "%s %s %s" % (r[1], r[2], "BUY" if r[4] == "1" else "SELL"); theo.setdefault(k, []).append(float(r[7]))
        for k, v in sorted(theo.items()):
            out.append("• %s: %d tin, điểm TB %.1f" % (k, len(v), sum(v) / len(v)))
    ok = bad = 0; ly = {}
    try:
        with open(os.path.join(data_dir, "phanhoi.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) >= 3 and now - int(r[0]) <= gio * 3600:
                    if r[2] == "ok":
                        ok += 1
                    elif r[2] == "sai":
                        bad += 1; ly[r[3]] = ly.get(r[3], 0) + 1
    except (OSError, ValueError):
        pass
    out.append("Phản hồi của anh: ✅ %d · ❌ %d" % (ok, bad))
    if ly:
        out.append("Lý do sai: " + " · ".join("%s ×%d" % kv for kv in sorted(ly.items(), key=lambda x: -x[1])))
    # KET QUA CAY A/P SAU KHI PUSH (AI quay lai cham)
    try:
        rr = [r for r in csv.reader(open(os.path.join(data_dir, "ai_bai2.csv"), encoding="utf-8")) if len(r) >= 9 + 17 + 1 and r[4] == "1" and now - int(r[0]) <= gio * 3600]
        if rr:
            dt = [float(r[-1]) for r in rr]; dm = [float(r[9 + 11]) for r in rr]
            out.append("📈 Cây A/P đã có kết quả: %d · tốt %.0f%% (đạt $3 tại lot 0.01) · điểm MAG TB %.1f ↔ điểm THỰC TẾ TB %.1f" % (len(rr), 100.0 * sum(int(r[8]) for r in rr) / len(rr), sum(dm) / len(dm), sum(dt) / len(dt)))
    except (OSError, ValueError, IndexError):
        pass
    # ket qua VAO LENH BONG theo luat v0 cua tac gia (gia lap, khong giao dich that)
    n_all = n_vao = thang = 0; tong = 0.0; mfe = 0.0; kc = {}
    try:
        with open(os.path.join(data_dir, "ai_ketqua.csv"), encoding="utf-8") as f:
            for r in csv.reader(f):
                if len(r) < 11 or now - int(r[0]) > gio * 3600:
                    continue
                n_all += 1
                if r[5] == "1":
                    n_vao += 1; p = float(r[7]); tong += p; mfe += float(r[8]); thang += p > 0; kc[r[6]] = kc.get(r[6], 0) + 1
    except (OSError, ValueError):
        pass
    if n_all:
        out.append("🧪 Vào lệnh BÓNG (luật v0: đợi hồi xuống → nến xanh, SL dời dương): %d tín hiệu, vào được %d, thắng %d/%d, tổng %+.1f giá, TB %+.2f, MFE TB %.2f" % (
            n_all, n_vao, thang, n_vao, tong, (tong / n_vao) if n_vao else 0, (mfe / n_vao) if n_vao else 0))
        if kc:
            out.append("   Kết cục: " + " · ".join("%s ×%d" % kv for kv in sorted(kc.items(), key=lambda x: -x[1])))
    out.append("Bài học đã ghi nhớ: %d (xem /hoclai)" % len(_ds(data_dir)))
    return "\n".join(out)


def _ds(data_dir):
    try:
        return json.load(open(os.path.join(data_dir, "hoclai.json"), encoding="utf-8"))
    except Exception:
        return []


def xem_hoclai(data_dir, n=5):
    ds = _ds(data_dir)[-n:]
    if not ds:
        return "Chưa có bài học nào. Bấm ❌ Sai – học lại dưới tin push để AI ghi nhớ."
    return "🧠 Bài học gần nhất:\n" + "\n".join("• %s – %s" % (x["id"], x.get("ly_do") or "(không ghi lý do)") for x in ds)
