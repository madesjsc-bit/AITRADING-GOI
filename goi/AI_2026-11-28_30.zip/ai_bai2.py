# -*- coding: utf-8 -*-
"""BAI 2 - DANH GIA CAY A / P TOT (hoc SONG SONG voi BAI 1 - tac gia 28/11):
VAO LENH xong (bat rau theo BAI 1; chua co mo hinh thi vao o gia mo nen B) → gia di it nhat +3 GIA duong la DAT (cang cao cang tot).
Hoc de DU DOAN cay nao 'tot'. Hoc tu 2 nguon: (1) A/P CHUAN do AI da push; (2) A 'NOI LONG' tu moi cay nen lich su (nhieu mau gap boi) co co 'chuan' de phan biet.
Danh gia cuoi cung CHI tren A/P chuan, du lieu SAU. Chi nghien cuu/gia lap."""
import csv, json, os, time
import ai_d1, ai_tick, ai_hocnen, ai_hocrau, ai_tiendo, ai_hoc

NG = {"mfe_gia": 3.0, "horizon": 600, "mau_chuan": 100, "auc": 0.60, "lift": 1.3, "ti_le_chon": 0.30, "ngay_on_dinh": 3}
PARAMS_NOI = {"ChainD1": 2, "MaxBuf": 3, "Depth": 1.0, "RevDist": 1.0, "SLPad": 0.3, "BlockTh": 2.0, "MaxSL": 3.0,
              "W3": 0.2, "W4": 0.3, "W5": 0.4, "A8": 0.6, "Leak": 0.3}
TEN_F = ["TC%d" % i for i in range(1, 12)] + ["diem", "loai", "nhanh", "sl_gia", "chuan", "btc"]
KIND = {"A": 0, "suyt A": 1, "suyt A do": 1, "P": 2}
NHANH = {"THUAN": 0, "CAT": 1, "NGUOC": 2, "": 3}
FILE = "ai_bai2.csv"


def bars_tu_tick(ticks, sec):
    out = []; cur = None
    for ts, bid in ticks:
        t0 = ts - ts % sec
        if cur is None or cur[0] != t0:
            if cur:
                out.append(tuple(cur))
            cur = [t0, bid, bid, bid, bid]
        else:
            cur[2] = max(cur[2], bid); cur[3] = min(cur[3], bid); cur[4] = bid
    if cur:
        out.append(tuple(cur))
    return out


def dac_trung(tc, score, loai, nhanh, sl_g, chuan, ten):
    f = [tc.get("TC%d" % i, 0.0) for i in range(1, 12)]
    return f + [score, KIND.get(loai, 0), NHANH.get(nhanh, 3), sl_g, chuan, 1 if ten == "BTC" else 0]


def mfe_sau_vao(ticks, k, sg, G, horizon=NG["horizon"]):
    """-> (mfe_g, mae_g) tinh tu tick k (diem vao) trong horizon giay."""
    ts0 = ticks[k][0]; e = sg * ticks[k][1]; mfe = 0.0; mae = 0.0
    for i in range(k + 1, len(ticks)):
        if ticks[i][0] - ts0 > horizon:
            break
        d = sg * ticks[i][1] - e
        mfe = max(mfe, d); mae = min(mae, d)
    return mfe / G, mae / G


def _vi_tri_B(ticks, tb):
    import bisect
    ts = [x[0] for x in ticks]
    return bisect.bisect_left(ts, tb)


def gan_nhan_chuan(data_dir, st, mas, Gmap):
    """Cay A/P chuan da push: gan nhan sau 'horizon' + 1 nen. Vao = bat rau (mo hinh chung) neu co, khong thi gia mo nen B."""
    xong = st.setdefault("b2_xong", []); now = time.time(); n = 0
    try:
        rows = list(csv.reader(open(os.path.join(data_dir, "ai_phathien.csv"), encoding="utf-8")))
    except OSError:
        return 0
    cache = {}
    for r in rows:
        if len(r) < 8 or r[3] not in ("A_dangtao", "P_dangtao") or r[2] != "M1":
            continue
        t, ten, sg = int(r[0]), r[1], int(r[4]); key = "%s_%d_%d" % (ten, t, sg)
        if key in xong or ten not in mas or now - t < 60 + NG["horizon"] + 60:
            continue
        loai = "P" if r[3] == "P_dangtao" else "A"
        sn = ai_hoc.doc_snap(data_dir, ai_hoc.tao_id(ten, "M1", t, sg, "a" if loai == "A" else "p"))
        if not sn:
            xong.append(key); continue
        G = Gmap.get(ten, 1.0); ticks = cache.setdefault(ten, ai_tick.doc_het(data_dir, ten)); tb = t + 60
        kB = _vi_tri_B(ticks, tb)
        if kB >= len(ticks) - 10 or ticks[kB][0] - tb > 90:
            xong.append(key); continue
        entry_k = kB; vao_mo = 0; m = ai_tiendo.tai_model(data_dir, ten, "BUY" if sg > 0 else "SELL")
        if m:
            nen = ai_hocnen.nen_idx(ticks); pos = {tt: i for i, (tt, _, _) in enumerate(nen)}
            for q in range(3):
                i = pos.get(tb + 60 * q)
                if i is None or i < 31:
                    continue
                got = ai_tiendo._thu_nen(ticks, nen, i, sg, G, m)
                if got:
                    entry_k = got["k"]; vao_mo = 1; break
        mfe, mae = mfe_sau_vao(ticks, entry_k, sg, G)
        tot = 1 if mfe >= NG["mfe_gia"] else 0
        f = dac_trung(sn.get("tc", {}), sn["score"], sn.get("kind", loai), sn.get("nhanh", ""), sn["sld"] / G, 1, ten)
        _ghi(data_dir, [t, ten, loai, sg, 1, vao_mo, round(mfe, 3), round(mae, 3), tot] + [round(x, 4) for x in f])
        xong.append(key); n += 1
    st["b2_xong"] = xong[-3000:]
    return n


def _ghi(data_dir, row):
    try:
        with open(os.path.join(data_dir, FILE), "a", encoding="utf-8", newline="") as f:
            csv.writer(f).writerow(row)
    except OSError:
        pass


def sinh_noi_long(data_dir, st, ten, G, toi_da=500):
    """A 'noi long' tu lich su M1 (khong can du chuan MAG): nhieu mau hon. Vao = gia mo nen B."""
    ticks = ai_tick.doc_het(data_dir, ten)
    m1 = bars_tu_tick(ticks, 60)
    if len(m1) < 120:
        return 0
    htf = {"M5": bars_tu_tick(ticks, 300), "M15": bars_tu_tick(ticks, 900), "M30": bars_tu_tick(ticks, 1800), "H1": bars_tu_tick(ticks, 3600)}
    xong = set(st.setdefault("b2_noi", [])); n = 0; now = time.time()
    for a in range(max(80, len(m1) - toi_da), len(m1) - 13):
        t = m1[a][0]
        if now - t < 60 + NG["horizon"] + 120:
            break
        key = "%s_%d" % (ten, t)
        if key in xong:
            continue
        sr = None
        for sg in (1, -1):
            if sr is None:
                sr = ai_d1.SR(m1[max(0, a - 400):a + 1], G, tf="M1", htf={k: [b for b in v if b[0] <= t + 3600] for k, v in htf.items()})
            r = ai_d1.eval_d1(sr, 1, sg, PARAMS_NOI)
            if not r["ok"]:
                continue
            kB = _vi_tri_B(ticks, t + 60)
            if kB >= len(ticks) - 10:
                continue
            mfe, mae = mfe_sau_vao(ticks, kB, sg, G)
            f = dac_trung(r["tc"], r["score"], r["kind"], r["nhanh"], r["sld"] / G, 0, ten)
            _ghi(data_dir, [t, ten, "A", sg, 0, 0, round(mfe, 3), round(mae, 3), 1 if mfe >= NG["mfe_gia"] else 0] + [round(x, 4) for x in f])
            n += 1
        xong.add(key)
        if n >= toi_da:
            break
    st["b2_noi"] = sorted(xong)[-20000:]
    return n


def doc_tap(data_dir):
    rows = []
    try:
        for r in csv.reader(open(os.path.join(data_dir, FILE), encoding="utf-8")):
            if len(r) >= 9 + len(TEN_F):
                rows.append({"t": int(r[0]), "ten": r[1], "sg": int(r[3]), "chuan": int(r[4]), "mfe": float(r[6]), "tot": int(r[8]), "f": [float(x) for x in r[9:9 + len(TEN_F)]]})
    except (OSError, ValueError):
        pass
    return sorted(rows, key=lambda x: x["t"])


def hoc(data_dir):
    rows = doc_tap(data_dir); res = {"t": int(time.time())}
    ch = [r for r in rows if r["chuan"]]; noi = [r for r in rows if not r["chuan"]]
    res.update(n_chuan=len(ch), n_noi=len(noi), ti_le_tot_chuan=(sum(r["tot"] for r in ch) / len(ch)) if ch else 0, mfe_tb_chuan=(sum(r["mfe"] for r in ch) / len(ch)) if ch else 0,
               ti_le_tot_noi=(sum(r["tot"] for r in noi) / len(noi)) if noi else 0)
    cut_t = ch[int(len(ch) * 0.7)]["t"] if len(ch) >= 20 else None
    tr = [r for r in rows if cut_t is None or r["t"] < cut_t]; te = [r for r in ch if cut_t is not None and r["t"] >= cut_t]
    if len(tr) < 150 or len(te) < 15:
        res["ly_do"] = "chua du mau (hoc %d, thu chuan %d) - can ~%d cay A/P chuan" % (len(tr), len(te), NG["mau_chuan"]); _luu(data_dir, res); return res
    if len(tr) > 9000:
        st = len(tr) / 9000.0; tr = [tr[int(i * st)] for i in range(9000)]
    edges = ai_hocrau.chia_bin([r["f"] for r in tr]); Xb = [ai_hocrau.bin_hoa(r["f"], edges) for r in tr]
    sk, gf = ai_hocrau.tang_cuong(Xb, [r["tot"] for r in tr], vong=30)
    pt = [ai_hocrau.du_doan(sk, ai_hocrau.bin_hoa(r["f"], edges)) for r in te]; yt = [r["tot"] for r in te]
    a = ai_hocrau.auc(yt, pt); base = sum(yt) / float(len(yt))
    order = sorted(range(len(te)), key=lambda i: -pt[i]); k = max(3, int(len(te) * NG["ti_le_chon"])); chon = order[:k]
    tl_chon = sum(yt[i] for i in chon) / float(k)
    res.update(auc_thu=a, ti_le_tot_nen=base, ti_le_tot_chon=tl_chon, lift=(tl_chon / base) if base > 0 else 0.0,
               mfe_chon=sum(te[i]["mfe"] for i in chon) / k, mfe_nen=sum(r["mfe"] for r in te) / len(te), n_thu=len(te),
               quan_trong=[TEN_F[i] for i in sorted(range(len(gf)), key=lambda i: -gf[i])[:3] if gf[i] > 0])
    with open(os.path.join(data_dir, "bai2_model.json"), "w", encoding="utf-8") as f:
        json.dump({"edges": edges, "stumps": sk}, f)
    _luu(data_dir, res)
    return res


def _luu(data_dir, res):
    with open(os.path.join(data_dir, "bai2.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)


def doc_kq(data_dir):
    try:
        return json.load(open(os.path.join(data_dir, "bai2.json"), encoding="utf-8"))
    except Exception:
        return None


def tieu_chi(r):
    return [("Đủ mẫu: %d/%d cây A/P CHUẨN đã gắn nhãn" % (r.get("n_chuan", 0), NG["mau_chuan"]), r.get("n_chuan", 0) >= NG["mau_chuan"]),
            ("AUC dự đoán cây tốt ≥%.2f (dữ liệu sau)%s" % (NG["auc"], (": %.2f" % r["auc_thu"]) if "auc_thu" in r else ""), r.get("auc_thu", 0) >= NG["auc"]),
            ("Nhóm AI chọn (top %.0f%%) tốt hơn nền ≥%.1f lần%s" % (NG["ti_le_chon"] * 100, NG["lift"], (": %.1f lần" % r["lift"]) if "lift" in r else ""), r.get("lift", 0) >= NG["lift"])]


def bao_cao(data_dir):
    r = doc_kq(data_dir)
    o = ["— BÀI 2 · Đánh giá cây A/P TỐT = vào xong đi ≥ %.0f giá dương (càng cao càng tốt) – HỌC SONG SONG" % NG["mfe_gia"]]
    if not r:
        o.append("   Đang thu nhãn (chưa có đủ dữ liệu)."); return o
    o.append("   Mẫu: %d cây A/P chuẩn + %d cây 'nới lỏng' (học thêm) · tốt: chuẩn %.0f%% · nới %.0f%% · đi thêm TB %.1f giá (chuẩn)" % (
        r["n_chuan"], r["n_noi"], r["ti_le_tot_chuan"] * 100, r["ti_le_tot_noi"] * 100, r["mfe_tb_chuan"]))
    if "ly_do" in r:
        o.append("   " + r["ly_do"]); return o
    o.append("   AI dự đoán cây tốt: AUC %.2f (0.5 = đoán mò) trên %d cây chuẩn dữ liệu sau · dựa vào: %s" % (r["auc_thu"], r["n_thu"], ", ".join(r["quan_trong"]) or "-"))
    o.append("   Nhóm AI chọn (top %.0f%%): tốt %.0f%% (nền %.0f%%, gấp %.1f lần) · đi thêm TB %.1f giá (nền %.1f)" % (
        NG["ti_le_chon"] * 100, r["ti_le_tot_chon"] * 100, r["ti_le_tot_nen"] * 100, r["lift"], r["mfe_chon"], r["mfe_nen"]))
    ch = tieu_chi(r); ok = sum(1 for _, x in ch if x)
    o.append("   TIẾN ĐỘ BÀI 2: %d/%d tiêu chí %s" % (ok, len(ch), "🎓 HỌC XONG" if ok == len(ch) else ""))
    for tx, x in ch:
        o.append("     %s %s" % ("✅" if x else "⏳", tx))
    return o


def bai2_dat(data_dir):
    r = doc_kq(data_dir)
    if not r or "ly_do" in r or "auc_thu" not in r:
        return 0, 3
    ch = tieu_chi(r)
    return sum(1 for _, x in ch if x), len(ch)
