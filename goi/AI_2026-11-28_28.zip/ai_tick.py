# -*- coding: utf-8 -*-
"""GHI GIA TUNG GIAY (tick 1 giay tu FD14_PRICE cua MAG, chi doc) de HOC 'DAU NEN' (rau nen) - cach nen xanh tao rau duoi, dung lai ra sao.
data/tick/<MA>_<yyyymmdd>.csv = ts,bid . Giu 7 ngay."""
import os, time

_BUF = {}


def ghi(data_dir, ten, ts, bid):
    b = _BUF.setdefault((data_dir, ten), {"rows": [], "t": time.time()})
    b["rows"].append((ts, bid))
    if len(b["rows"]) >= 30 or time.time() - b["t"] > 20:
        xa(data_dir, ten)


def xa(data_dir, ten):
    b = _BUF.get((data_dir, ten))
    if not b or not b["rows"]:
        return
    d = os.path.join(data_dir, "tick")
    os.makedirs(d, exist_ok=True)
    byday = {}
    for ts, bid in b["rows"]:
        byday.setdefault(time.strftime("%Y%m%d", time.gmtime(ts)), []).append("%d,%.3f\n" % (ts, bid))
    for day, ls in byday.items():
        with open(os.path.join(d, "%s_%s.csv" % (ten, day)), "a", encoding="utf-8") as f:
            f.writelines(ls)
    b["rows"] = []; b["t"] = time.time()


def don_dep(data_dir, giu_ngay=7):
    d = os.path.join(data_dir, "tick")
    try:
        for f in os.listdir(d):
            p = os.path.join(d, f)
            if time.time() - os.path.getmtime(p) > giu_ngay * 86400:
                os.remove(p)
    except OSError:
        pass


def doc_het(data_dir, ten):
    """-> [(ts,bid)] tang dan theo ts (tat ca file con giu)."""
    d = os.path.join(data_dir, "tick"); out = []
    try:
        fs = sorted(f for f in os.listdir(d) if f.startswith(ten + "_"))
    except OSError:
        return out
    for f in fs:
        try:
            for ln in open(os.path.join(d, f), encoding="utf-8"):
                a = ln.strip().split(",")
                if len(a) == 2:
                    out.append((int(a[0]), float(a[1])))
        except (OSError, ValueError):
            pass
    out.sort()
    return out
