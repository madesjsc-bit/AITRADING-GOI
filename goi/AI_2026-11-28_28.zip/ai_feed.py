# -*- coding: utf-8 -*-
"""NGUON GIA: tu dung nen M1/M5/M15/H1 tu file gia MAG ghi moi giay (FD14_PRICE_XAU.txt = bid;ask;gmt_unix;...)
- CHI DOC qua ranh_gioi (khong dung MT5 rieng, khong dang nhap TK nao). Gia = BID cua san Exness MAG dang noi.
- Nen DONG ghi ra <feed>/XAU_<khung>.csv (time,open,high,low,close,tickvol) cho ai_bot doc."""
import os, json, time
import ranh_gioi
import ai_tick

KHUNG = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400}
TOI_DA = 400


def doc_gia(cfg, ten="XAU"):
    raw = ranh_gioi.doc(cfg, "FD14_PRICE_%s.txt" % ten)
    if not raw:
        return None
    try:
        p = raw.decode("utf-8", "ignore").strip().splitlines()[0].split(";")
        return float(p[0]), float(p[1]), int(p[2])
    except (ValueError, IndexError):
        return None


def them_gia(bars, ts, bid):
    """bars: {khung: [[t, o, h, l, c, n], ...]}. Tra ve danh sach khung vua co nen DONG."""
    dong = []
    for kh, sec in KHUNG.items():
        ls = bars.setdefault(kh, [])
        t = ts - ts % sec
        if ls and ls[-1][0] == t:
            b = ls[-1]
            b[2] = max(b[2], bid); b[3] = min(b[3], bid); b[4] = bid; b[5] += 1
        elif not ls or t > ls[-1][0]:
            ls.append([t, bid, bid, bid, bid, 1])
            if len(ls) > 1:
                dong.append(kh)
            del ls[:-TOI_DA]
    return dong


def ghi_csv(feed_dir, bars, ten="XAU", khung=None):
    os.makedirs(feed_dir, exist_ok=True)
    for kh in (khung or bars):
        ls = bars.get(kh, [])[:-1]  # bo nen dang chay
        if not ls:
            continue
        tmp = os.path.join(feed_dir, "%s_%s.tmp" % (ten, kh))
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            for b in ls:
                f.write("%d,%.3f,%.3f,%.3f,%.3f,%d\n" % tuple(b))
        os.replace(tmp, os.path.join(feed_dir, "%s_%s.csv" % (ten, kh)))


def nap(data_dir, ten="XAU"):
    try:
        with open(os.path.join(data_dir, "bars.json" if ten == "XAU" else "bars_%s.json" % ten), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def luu(data_dir, bars, ten="XAU"):
    fn = "bars.json" if ten == "XAU" else "bars_%s.json" % ten
    tmp = os.path.join(data_dir, fn + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(bars, f)
    os.replace(tmp, os.path.join(data_dir, fn))


def chay(cfg, data_dir, feed_dir, st, mem, ten="XAU"):
    """Goi moi ~2 giay. mem: dict giu trong RAM. Tra ve True neu co nen dong moi."""
    g = doc_gia(cfg, ten)
    if g is None:
        return False
    bid, _, ts = g
    if ts <= mem.get("ts", 0) or time.time() - ts > 45:  # trung hoac gia cu (thi truong dong)
        return False
    mem["ts"] = ts
    ai_tick.ghi(data_dir, ten, ts, bid)
    if "bars" not in mem:
        mem["bars"] = nap(data_dir, ten)
    dong = them_gia(mem["bars"], ts, bid)
    if dong:
        ghi_csv(feed_dir, mem["bars"], ten=ten, khung=dong)
        luu(data_dir, mem["bars"], ten)
        return True
    return False


def trang_thai(cfg, feed_dir, tens=("XAU",)):
    """Mo ta nguon gia (cho lenh ai_thu / /ai)."""
    goc = ranh_gioi.goc(cfg)
    o = ["nguon gia: %s (%s)" % (os.path.join(goc, "FullD"), "co" if os.path.isdir(os.path.join(goc, "FullD")) else "KHONG THAY thu muc")]
    o.append("file doc duoc: " + (", ".join(ranh_gioi.liet_ke(cfg)) or "(khong co)"))
    for ten in tens:
        g = doc_gia(cfg, ten)
        if g is None:
            o.append("%s: khong doc duoc FD14_PRICE_%s.txt" % (ten, ten))
        else:
            tuoi = int(time.time()) - g[2]
            o.append("%s gia cuoi: bid=%.2f cach day %d giay%s" % (ten, g[0], tuoi,
                     " -> THI TRUONG DONG / MAG khong ghi (AI chi chay khi gia moi < 45 giay)" if tuoi > 45 else " (dang cap nhat)"))
        for kh in KHUNG:
            p = os.path.join(feed_dir, "%s_%s.csv" % (ten, kh))
            n = len(open(p).read().splitlines()) if os.path.exists(p) else 0
            o.append("  %s %s: %d nen dong (can >= 13)" % (ten, kh, n))
    return "\n".join(o)
