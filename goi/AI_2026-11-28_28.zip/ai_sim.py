# -*- coding: utf-8 -*-
"""VAO LENH BONG (giả lập, KHÔNG giao dịch thật) theo nguyên tắc tác giả mô tả 28/11/2026 - bản v0, sẽ học/sửa dần:
VAO: sau khi A / P xác nhận KHÔNG vào ngay; đợi nến hồi xuống dưới giá mở cửa, khi 'đầu nến hồi xong' và giá đi lên tạo NẾN XANH → vào.
QUAN LY: SL đặt ngay; giá đi qua giá mở cửa → dời SL dương (không lỗ vốn); sau đó kéo SL thông minh (khó bị chạm, vẫn dương);
nguy cơ (nến đảo chiều mạnh) → cắt luôn để giữ lãi. Kết quả đo bằng 'giá' (G)."""
import os, csv

PS = {"cho_toi_da": 8, "theo_doi": 25, "sl_pad": 0.3, "be_pad": 0.1, "max_sl": 3.0}
KHUNG_S = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400}


def mo_phong(after, sg, G, P=None):
    """after: nen DONG sau nen tin hieu (cu→moi) [(t,o,h,l,c)]. -> dict ket qua."""
    P = P or PS
    # quy ve khung BUY (SELL: dao dau gia)
    a = [(b[0], sg * b[1], (b[2] if sg > 0 else -b[3]), (b[3] if sg > 0 else -b[2]), sg * b[4]) for b in after]
    if len(a) < 3:
        return {"vao": False, "ly_do": "thieu nen"}
    open_b = a[0][1]; dip = None; e = -1
    for i, b in enumerate(a[:P["cho_toi_da"]]):
        if b[3] < open_b:
            dip = b[3] if dip is None else min(dip, b[3])
        if dip is not None and b[4] > b[1]:          # da hoi xuong duoi gia mo cua + nen XANH
            e = i; break
    if e < 0:
        return {"vao": False, "ly_do": "khong co nhip hoi + nen xanh xac nhan"}
    entry = a[e][4]; sl = dip - P["sl_pad"] * G
    risk = entry - sl
    if risk <= 0:
        return {"vao": False, "ly_do": "SL khong hop le"}
    res = {"vao": True, "nen_vao": e, "entry": sg * entry, "sl0": sg * sl, "risk_g": risk / G, "sl_lon": risk > P["max_sl"] * G}
    be = False; mfe = 0.0; mae = 0.0; ex = None; tag = "het gio"
    rest = a[e + 1:e + 1 + P["theo_doi"]]
    for j, b in enumerate(rest):
        prev = rest[j - 1] if j > 0 else a[e]
        mfe = max(mfe, b[2] - entry); mae = min(mae, b[3] - entry)
        if b[3] <= sl:                                    # cham SL (truoc khi cap nhat theo nen nay)
            ex = sl; tag = "SL duong" if sl >= entry else "SL"; break
        if not be and b[2] >= open_b and b[2] > entry:   # gia di qua gia mo cua -> doi SL duong
            be = True; sl = max(sl, entry + P["be_pad"] * G)
        if be:
            two_low = min(b[3], prev[3]) - P["sl_pad"] * G   # keo SL duoi day 2 nen gan nhat (kho bi quet), khong lui, khong qua close
            sl = max(sl, min(two_low, b[4] - P["be_pad"] * G), entry + P["be_pad"] * G)
        if b[4] > entry and b[4] < b[1] and b[4] < prev[3]:   # nguy co: nen do dong duoi day nen truoc khi dang lai -> cat som
            ex = b[4]; tag = "cat som"; break
    if ex is None:
        ex = rest[-1][4] if rest else entry
    res.update(exit=sg * ex, sl_cuoi=sg * sl, pnl_g=(ex - entry) / G, mfe_g=mfe / G, mae_g=mae / G, ket_cuc=tag)
    return res


def cho_theo_doi(st, sid, ten, kh, sg, t_phat):
    st.setdefault("sim", []).append({"id": sid, "ten": ten, "kh": kh, "sg": sg, "t_close": t_phat + KHUNG_S[kh]})
    st["sim"] = st["sim"][-200:]


def cap_nhat(mem_feed, data_dir, st):
    """Moi vong: tin hieu nao da du ~30 nen sau do thi mo phong + ghi ai_ketqua.csv."""
    import ai_d1
    ds = st.get("sim") or []
    con = []
    for x in ds:
        bars = ((mem_feed.get(x["ten"]) or {}).get("bars") or {}).get(x["kh"]) or []
        after = [tuple(b[:5]) for b in bars[:-1] if b[0] >= x["t_close"]]
        if len(after) < PS["cho_toi_da"] + PS["theo_doi"] + 1:
            con.append(x); continue
        r = mo_phong(after, x["sg"], ai_d1.G_TAISAN.get(x["ten"], 1.0))
        try:
            os.makedirs(data_dir, exist_ok=True)
            with open(os.path.join(data_dir, "ai_ketqua.csv"), "a", encoding="utf-8", newline="") as f:
                csv.writer(f).writerow([x["t_close"], x["id"], x["ten"], x["kh"], x["sg"], int(r["vao"]), r.get("ket_cuc", r.get("ly_do", "")),
                                        round(r.get("pnl_g", 0), 2), round(r.get("mfe_g", 0), 2), round(r.get("mae_g", 0), 2), round(r.get("risk_g", 0), 2)])
        except OSError:
            pass
    st["sim"] = con
