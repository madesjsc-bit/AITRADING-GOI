# -*- coding: utf-8 -*-
"""HOC TU MAG: Đ1 - CAY A / SUYT A (port tu MQL5/Experts/FD14/D14.mqh: X14Tree, X14Run, X14Split, EvalD1 - ban 1.4).
Chi dung nen DA DONG. sg = chieu LENH (BUY=+1, SELL=-1); chuoi chay NGUOC chieu lenh.
Chi nhan biet + tinh SL/nhanh (CHUA cham diem TC1-TC8 - lam o buoc sau). Khong co phan giao dich."""

# Mac dinh = input MAG (Inputs.mqh): #20 #22 #23 #24 #25 #26 #38 #75-78 #86. G = 1 "gia": XAU 1 USD, BTC 30 USD.
PARAMS = {"ChainD1": 3, "MaxBuf": 2, "Depth": 2.0, "RevDist": 2.0, "SLPad": 0.3, "BlockTh": 2.0, "MaxSL": 3.0,
          "W3": 0.4, "W4": 0.6, "W5": 0.8, "A8": 1.5, "Leak": 0.1}
G_TAISAN = {"XAU": 1.0, "BTC": 30.0}
LE = 40  # le du lieu cuoi mang (MAG dung 320 cho EMA50; AI co ~400 nen)


class SR:
    """Chuoi nen KIEU MQL (chi so 0 = moi nhat). Chi so 0 = nen dang chay GIA LAP (open = close nen dong cuoi)."""
    def __init__(self, bars, G):
        # bars: [(t, o, h, l, c), ...] cu -> moi, toan nen DA DONG
        last = bars[-1][4]
        ser = [(bars[-1][0] + 60, last, last, last, last)] + list(reversed(bars))
        self.t = [b[0] for b in ser]; self.o = [b[1] for b in ser]
        self.h = [b[2] for b in ser]; self.l = [b[3] for b in ser]; self.c = [b[4] for b in ser]
        self.n = len(ser); self.G = G
        c = self.c
        self.lw = [None] * self.n
        for i in range(self.n - 8):
            self.lw[i] = sum((9 - q) * c[i + q] for q in range(9)) / 45.0
        chrono = list(reversed(c)); v = chrono[0]; out = []
        for x in chrono:
            v = v + (2.0 / 51.0) * (x - v); out.append(v)
        self.e = list(reversed(out))


def col(s, i):
    d = s.c[i] - s.o[i]
    return 1 if d > 0 else (-1 if d < 0 else 0)


def close_below(s, j, sg):
    return sg * (s.c[j] - s.lw[j]) <= 0


def dt(s, x, bd, m):
    if x < 0 or x + m + 1 >= s.n or s.lw[x + m] is None:
        return False
    return all(bd * (s.lw[x + k] - s.lw[x + k + 1]) > 0 for k in range(m))


def w(s, x, bd, m):
    return bd * (s.lw[x] - s.lw[x + m - 1])


def tree(s, x, sg):
    """1 = A, 2 = suyt A xanh, 3 = suyt A do, 0 = khong."""
    if x < 1 or x + 12 >= s.n or s.lw[x + 4] is None:
        return 0
    cl = col(s, x)
    c4 = sg * (s.c[x] - s.lw[x + 4]); c3 = sg * (s.c[x] - s.lw[x + 3])
    b_ok = sg * (s.o[x - 1] - s.lw[x + 3]) > 0
    if cl == sg and c4 >= 0:
        return 1
    if cl == sg and c3 > 0 and b_ok:
        return 2
    if cl == -sg and c4 >= 0 and b_ok:
        return 3
    return 0


def run(s, ce, cp, sg, P):
    cnt = 0; G = s.G
    for x in range(cp, ce - 1, -1):
        p = cnt + 1
        if p == 1:
            cnt = 1
            continue
        m = min(5, p + 1)
        thr = (P["W3"] if m == 3 else (P["W4"] if m == 4 else P["W5"])) * G
        if dt(s, x, -sg, m) and w(s, x, -sg, m) >= thr:
            cnt += 1
        else:
            cnt = 1
    return cnt


def split(s, a, sg, k, P):
    """-> (ly_do_loi_hoac_'', ce, cs, good, leak)"""
    G = s.G; good = 0; leak = -1
    for j in range(a + 1, a + k + 1):
        if j >= s.n - LE:
            return "thieu du lieu", -1, -1, 0, -1
        if tree(s, j, sg) != 0:
            return "nen dem %d da la cay A / suyt A" % (j - a), -1, -1, 0, -1
        if col(s, j) == sg:
            good += 1
    if k >= 2:
        b1 = a + k
        if sg * (s.c[b1] - s.lw[b1 + 2]) > 0:
            for x in range(b1 - 1, a, -1):
                if sg * (s.c[x] - s.o[b1]) < 0:
                    return "nen dem dong vuot open dem 1", -1, -1, 0, -1
    ce = a + k + 1
    if ce >= s.n - LE:
        return "thieu du lieu", -1, -1, 0, -1
    if not close_below(s, ce, sg):
        return "nen sat A khong phai nen chuoi", -1, -1, 0, -1
    x = ce + 1
    while x < s.n - LE and x - ce < 200:
        if close_below(s, x, sg):
            x += 1
            continue
        if leak < 0 and sg * (s.c[x] - s.lw[x]) <= P["Leak"] * G and x + 1 < s.n - LE and close_below(s, x + 1, sg):
            leak = x
            x += 1
            continue
        break
    cp = x - 1; lp = cp - ce + 1
    if lp < P["ChainD1"]:
        return "chuoi gia %d nen (can >= %d)" % (lp, P["ChainD1"]), -1, -1, 0, -1
    ln = run(s, ce, cp, sg, P); cs = ce + ln - 1
    if leak >= 0 and leak >= cs:
        if leak == cs:
            cs -= 1
        leak = -1
    ln = cs - ce + 1
    if ln < P["ChainD1"]:
        return "chuoi %d nen co dai hop le (can >= %d)" % (max(ln, 0), P["ChainD1"]), -1, -1, 0, -1
    w5 = w(s, ce, -sg, 5)
    if w5 < P["A8"] * G:
        return "A8: dai 5 duong cuoi chuoi %.2f (can >= %.2f)" % (w5 / G, P["A8"]), -1, -1, 0, -1
    depth = sg * (s.o[cs] - s.o[ce])
    if depth < P["Depth"] * G:
        return "do sau chuoi %.2f (can >= %.2f)" % (depth / G, P["Depth"]), -1, -1, 0, -1
    return "", ce, cs, good, leak


def eval_d1(s, a, sg, P=None):
    """-> dict ket qua (ok True/False + ly do). a = chi so nen A (1 = nen dong gan nhat)."""
    P = P or PARAMS; G = s.G
    r = {"ok": False, "sg": sg, "a": a}
    if a < 1 or a + 15 + LE >= s.n:
        r["why"] = "thieu du lieu"; return r
    typ = tree(s, a, sg)
    if typ == 0:
        r["why"] = "khong phai nen A / suyt A"; return r
    r["kind"] = {1: "A", 2: "suyt A", 3: "suyt A do"}[typ]
    tried = []; got = None
    for k in range(P["MaxBuf"] + 1):
        why, ce, cs, good, leak = split(s, a, sg, k, P)
        if why == "":
            got = (k, ce, cs, good, leak); break
        tried.append("%d dem: %s" % (k, why))
    if got is None:
        r["why"] = "chuoi/dem khong hop le - " + " | ".join(tried); return r
    nb, ce, cs, good, leak = got
    E = s.e[a]
    ext = min(s.lw[q] for q in range(a, min(cs + 4, s.n - 9) + 1)) if sg > 0 else max(s.lw[q] for q in range(a, min(cs + 4, s.n - 9) + 1))
    if sg * (s.o[a] - E) >= 0:
        br = "THUAN"; SL = ext - sg * P["SLPad"] * G
    elif sg * (s.c[a] - E) > 0:
        br = "CAT"; SL = E - sg * P["SLPad"] * G
    else:
        d = sg * (E - s.c[a])
        if d < P["RevDist"] * G:
            r["why"] = "nhanh nguoc: closeA cach E50 %.2f < %.2f" % (d / G, P["RevDist"]); return r
        br = "NGUOC"; SL = ext - sg * P["SLPad"] * G
    sld = sg * (s.c[a] - SL)
    if sld <= 0:
        r["why"] = "SL khong hop le"; return r
    r.update(ok=True, nb=nb, ce=ce, cs=cs, len=cs - ce + 1, leak=leak >= 0, nhanh=br, sl=SL, sld=sld,
             block=2 if sld >= P["BlockTh"] * G else 1, sl_lon=sld > P["MaxSL"] * G,
             a8=w(s, ce, -sg, 5) / G, depth=sg * (s.o[cs] - s.o[ce]) / G, t=s.t[a], gia=s.c[a])
    return r


def van_ban(ten, khung, r):
    huong = "BUY ⬆️" if r["sg"] > 0 else "SELL ⬇️"
    d = ["🤖 AI · %s %s · Đ1 CÂY %s %s" % (ten, khung, r["kind"].upper().replace("SUYT", "SUÝT"), huong),
         "Giá đóng nến A: %.2f · nhánh %s" % (r["gia"], {"THUAN": "THUẬN", "CAT": "CẮT", "NGUOC": "NGƯỢC"}[r["nhanh"]]),
         "Chuỗi %d nến (đệm %d%s) · độ sâu %.2f · dải 5 đường cuối chuỗi %.2f giá" % (r["len"], r["nb"], ", 1 nến lọt" if r["leak"] else "", r["depth"], r["a8"]),
         "SL gợi ý %.2f (cách %.2f giá)%s" % (r["sl"], r["sld"], " ⚠️ SL lớn → chỉ tham khảo" if r["sl_lon"] else "")]
    d.append("Cấp: CHỈ BÁO (AI không vào lệnh). Điểm TC1–TC8 chưa chấm (đang học từ MAG).")
    return "\n".join(d)
